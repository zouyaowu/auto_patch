DECLARE @ViewName varchar(200)
	DECLARE CUR_RefreshAllView CURSOR FOR 
	SELECT Name FROM sys.views     
OPEN CUR_RefreshAllView
FETCH NEXT FROM CUR_RefreshAllView INTO @ViewName
WHILE(@@FETCH_STATUS=0)
BEGIN
	    
	begin try

	exec sp_refreshview @ViewName

	end try
	begin catch
		PRINT '��ͼ' + @ViewName + '�쳣��' + ERROR_MESSAGE()   
	end catch
    
	FETCH NEXT FROM CUR_RefreshAllView INTO @ViewName
END
CLOSE CUR_RefreshAllView
DEALLOCATE CUR_RefreshAllView
go