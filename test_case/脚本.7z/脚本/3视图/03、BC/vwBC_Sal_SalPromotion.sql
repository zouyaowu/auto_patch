  IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwBC_Sal_SalPromotion]'))
DROP VIEW [dbo].[vwBC_Sal_SalPromotion]
GO
 


 
CREATE VIEW [dbo].[vwBC_Sal_SalPromotion]
AS
    SELECT  CASE WHEN BillStatus = 0
                      OR BillStatus = 1
                      OR BillStatus = 2
                      OR BillStatus = 3 THEN 1
                 WHEN BillStatus = 5 THEN 5
                 WHEN BillStatus = 6 THEN 6
                 WHEN CONVERT(VARCHAR(10), StartDate, 120) + ' '
                      + CONVERT(VARCHAR(8), StartTime, 114) > GETDATE() THEN 2
                 WHEN CONVERT(VARCHAR(10), EndDate, 120) + ' '
                      + CONVERT(VARCHAR(8), EndTime, 114) < GETDATE() THEN 4
                 WHEN dbo.F_IsDateConfine(StartDate, EndDate, StartTime,
                                          EndTime, GETDATE(), DateRule) = 1
                 THEN 3
                 ELSE 2
            END AS BillStatusa 
	  ,[CompanyID]
      ,[PromotionID]
      ,[PromotionCode]
      ,[PromotionName]
      ,[PromotionType]
      ,[DateRule]
      ,[StartDate]
      ,[EndDate]
      ,[SpecialDateRule]
      ,[SpecialDateRuleValue]
      ,[BillStatus]
      ,[Remark]
      ,[BasePriceMode]
      ,[IsJoinDouble]
      ,[IsJoinDoubleOnlyChooseMaxValue]
      ,[PayAmount]
      ,[IsIncludePostage]
      ,[PromotionGiftType]
      ,[Qty]
      ,[Rank]
      ,[Operator]
      ,[Checker]
      ,[CheckDate]
      ,[AllowUsed]
      ,[ModifyDTM]
      ,[UnChecker]
      ,[UnCheckDate]
      ,[BillTypeID]
      ,[BillDate]
      ,[Signature]
      ,[MaterialType]
      ,[StartTime]
      ,[EndTime]
	  ,[SpecialDateRuleValueRemark]
      ,IsJoinOnce,IsAddGift,PromotionGiftMode
  FROM [BC_Sal_SalPromotion]

GO


