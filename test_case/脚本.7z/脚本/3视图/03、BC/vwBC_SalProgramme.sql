--�ж���ͼ�Ƿ����
IF EXISTS(SELECT 1 FROM sys.views WHERE name='vwBC_SalProgramme')
DROP VIEW vwBC_SalProgramme
GO
--������ͼ
create view vwBC_SalProgramme
AS
SELECT a.CompanyID,a.BillNo,a.SalProgramCode,a.Signature,a.ProjectName,a.BillTypeID,a.BillDate,
a.BillStatus,
a.ExecutionState,
--case when getdate()<convert(varchar(100),a.StartDate,121) and getdate()<convert(varchar(100),a.EndDate,121) then 0 --δִ��
--	 when getdate()>=convert(varchar(100),a.StartDate,121) and getdate()<=convert(varchar(100),a.EndDate,121) and a.BillStatus=4 then 1--����ִ��
--	 else 2 end as ExecutionStatea,--�Զ�����
case when getdate()<a.StartDate and getdate()<a.EndDate then 0 --δִ��
	 when getdate()>=a.StartDate and getdate()<=a.EndDate and a.BillStatus=4 then 1--����ִ��
	 else 2 end as ExecutionStatea,--�Զ�����
a.Operator,a.StartDate,a.EndDate,a.Checker,a.CheckDate,a.UnChecker,a.UnCheckDate,a.ShopID,a.AddDTM,a.ModifyDTM,a.Remark
FROM BC_SalProgramme a