    IF EXISTS ( SELECT    *
              FROM      sys.views
              WHERE     object_id = OBJECT_ID(N'[dbo].[vwBC_Sal_OrderMaster]') ) 
    DROP VIEW [dbo].[vwBC_Sal_OrderMaster]
GO
 
CREATE VIEW [dbo].[vwBC_Sal_OrderMaster]
AS
    SELECT  m.[CompanyID] ,
            m.[BillNo] ,
            m.[BillTypeID] ,
            m.[BillDate] ,
            m.[BillStatus] ,
            m.[CheckDate] ,
            m.[Checker] ,
            m.[Operator] ,
            m.[Signature] ,
            m.[Remark] ,
            m.[ModifyDTM] ,
            m.[ShopID] ,
            m.[StockID] ,
            m.[ShopBillNo] ,
            m.[AlipayBillNo] ,
            m.[TurnoverDate] ,
            m.[BannerState] ,
            m.[OperStatus] ,
            m.[TranState] ,
            m.[TranType] ,
            m.[VendCustID] ,
            m.[OutBillNo] ,
            m.[ExpressBillNo] ,
            m.[ConsignmentDate] ,
            m.[Qty] ,
            m.[PayAmount] ,
            m.[ExpressAmount] ,
            m.[ZRAmount] ,
            m.[ExpressCost] ,
            m.[IsInvoice] ,
            m.[PreRemark] ,
            m.[SaleType] ,
            m.[Weight] ,
            m.[ParcelWeight] ,
            m.[PackageCost] ,
            m.[SourceType] ,
            m.[SourceRemark] ,
            m.[OrderType] ,
            m.[MergeSplitType] ,
            m.[MergeSourceBillNo] ,
            m.[IsPrintExpressBill] ,
            m.[IsPrintDistBill] ,
            m.[BuyerCode] ,
            m.[BuyerMobileTel] ,
            m.[BuyerTel] ,
            m.[BuyerRemark] ,
            m.[ConsigneeName] ,
            m.[Province] ,
            m.[City] ,
            m.[Area] ,
            m.[ZipCode] ,
            m.[Address] ,
            m.[SellRemark] ,
            m.[SellCode] ,
            m.[ExceptionStatus] ,
            m.[ExceptionNode] ,
            m.[PaymentDate] ,
            m.[IsHide] ,
            m.[PickStatus] ,
            m.[Paymenttype] ,
            m.[CodCharges] ,
            m.[ManualBillNo] ,
            m.[RecStatus] ,
            m.[OldOperator] ,
            m.[ExpressType] ,
            m.[invoice_name] ,
            m.[BuyerGetBonus] ,
            m.[BuyerUseBonus] ,
            m.[BuyerRealUseBonus] ,
            m.[PersonnelID] ,
            m.[SendContact_ID] ,
            m.[CancelContact_ID] ,
            m.[PromZRAmount] ,
            m.[PayAmountBakUp] ,
            ( CASE m.OrderCustomerID
                WHEN '' THEN '-1'
                ELSE ISNULL(m.[OrderCustomerID], '-1')
              END ) AS OrderCustomerID ,
            m.[IsAutoMerge] ,
            m.[IsReturnOrder] ,
            m.TotalBarginPrice ,
            ISNULL(p.IsPrintExpress, 0) AS IsPrintExpress ,
            ISNULL(p.IsPrintSendBill, 0) AS IsPrintSendBill ,
            p.PickBillNo ,
            p.PickStatusName ,
            p.ProjectNo ,
            ISNULL(m.IsConsultingOrder, 0) AS IsConsultingOrder ,
            r.ReturnsFreBillNo ,
            m.BuyerAlipayNo ,
            ISNULL(m.IsLock, 0) AS IsLock ,
            m.O2OShopID ,
            m.O2OCompanyID ,
            m.OldO2OShopID ,
            m.DischargeIntegral ,
            m.DischargeIntegralAmount ,
            m.ExchangeIntegral ,
            m.CardCode ,
            m.BuyerID ,
            edi.OpResultStatus ,
            ISNULL(edi.OpResultStatusName, '') AS OpResultStatusName ,
            m.RefundType ,
            m.WMS_OrderID ,
            s.WorkPropertyID ,
            i.InfoName AS WorkPropertyName ,
            m.RefundChangeType ,
            m.CardAmount ,
            m.CardsNo ,
            m.RptAmount ,
            ISNULL(m.IsBCVirOrder, 0) AS IsBCVirOrder ,
            ISNULL(m.PdAmount, 0) AS PdAmount ,
            m.ReturnItemStatus ,
            m.IsSendToEDI ,
            m.ReturnStockID ,
            ISNULL(m.IsSetStocked, 0) AS IsSetStocked ,
            m.IsInvoiceSend ,
            m.InvoiceNo ,
            m.NotAuditReason ,
            m.InvoiceHeader ,
            m.InvoiceType ,
            m.TaxNO ,
            m.Bank ,
            m.BankAccount ,
            m.InvoiceContent ,
            m.InvoiceMedium ,
            m.PersonnelShopID ,
            r.RecReturnDate ,
            m.LabelName ,
			ISNULL(m.SendEdiLock, 0) SendEdiLock,
			m.IsPresentGood,
			m.CompanyBalanceAmount,
			m.CompanyMemberCode
    FROM    BC_Sal_OrderMaster m
            OUTER APPLY ( SELECT TOP 1
                                    pm.ProjectNo ,
                                    pm.BillNo AS [PickBillNo] ,
                                    ISNULL(pd.IsPrintExpress, 0) AS IsPrintExpress ,
                                    ISNULL(pd.IsPrintSendBill, 0) AS IsPrintSendBill ,
                                    se.CNStateName AS [PickStatusName]
                     /*pm.PickStatus as SDPickStatus*/
                          FROM      SD_Inv_PickUpMaster pm
                                    INNER JOIN SD_Inv_PickUpDetail pd ON pm.CompanyID = pd.CompanyID
                                                              AND pm.BillNo = pd.BillNo
                                    LEFT JOIN Sys_State se ON se.StateFixFlag = 'PickStatus'
                                                              AND se.StateType = pm.PickStatus
                          WHERE     pd.SourceBillNo = m.BillNo
                                    AND pd.CompanyID = m.CompanyID
                          ORDER BY  pm.ModifyDTM DESC
                        ) p
            LEFT JOIN BC_Sal_Returninfo r ON m.CompanyID = r.CompanyID
                                             AND m.BillNo = r.BillNo
            OUTER APPLY ( SELECT TOP 1
                                    g.OpResultStatus ,
                                    g.OpResultStatusName
                          FROM      ( SELECT TOP 1
                                                t.OpResultStatus ,
                                                c.StateName AS OpResultStatusName
                                      FROM      HK_EDI_JobOrderTrace t
                                                JOIN dbo.SD_EDI_Stock b ON b.OSStockID = t.OSStockID
                                                JOIN dbo.HK_EDI_OrderState c ON c.CooperationSys = b.CooperationSys
                                                              AND t.OpResultStatus = c.StateType
                                      WHERE     t.BillTypeID = 'BC_NetSalOrder'
                                                AND t.CompanyID = m.CompanyID
                                                AND t.NoticeBillNo = m.BillNo
												ORDER BY t.CreateDate desc
                                    ) g
                        ) edi
            LEFT JOIN dbo.Bas_Shop s ON s.CompanyID = m.CompanyID
                                        AND s.ShopID = m.ShopID
                                        AND s.Lan = 0
            LEFT JOIN SD_Bas_ShopAndCustBaseInfo i ON /*AND*/ s.WorkPropertyID = i.InfoID
                                                      AND i.Lan = 0





GO
 

