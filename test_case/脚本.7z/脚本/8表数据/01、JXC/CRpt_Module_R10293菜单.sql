﻿Begin
Delete Sys_Module Where ModuleCode = 'CRpt_Module_R10293'
Insert Into [Sys_Module] ([ModuleCode],[Sequence],[FacClass],[ModuleName],[CNModuleName],[TWModuleName],[ENModuleName],[JPModuleName],[KRModuleName],[RightTypeCode],[RightTypeName],[RightTypeCodeOfAccount],[FuncType],[SubSystemCode],[SubModuleCode],[ParentMenu],[CNParentMenu],[TWParentMenu],[ENParentMenu],[JPParentMenu],[KRParentMenu],[AuditType],[ClassName],[SubClassName],[PrgmName],[TableName],[Param],[ListSeparator],[IsShowModule],[IsNeedFuncLimit],[IsNeedDataLimit],[IsNeedAudit],[IsBloc],[IsCompany],[ModifyDTM],[IsAllowDownLoad],[IsAllowUpLoad],[SyncDataType],[AllowUsed],[InSubsystem],[RightTypeCodeOfMenu],[IsJoiningTrader],[IsCustomMade]) Values ('CRpt_Module_R10293',21210200014,NULL,N'成本进销存报表（不含调拨）',N'成本进销存报表（不含调拨）',N'成本進銷存報表（不含調撥）',N'',N'',N'','0019',N'报表查询','0012','1','CRPT','CRPTModule',N'报表查询|成本报表',N'报表查询|成本报表',N'報表查詢|成本報表',N'Report|Cost',N'报表查询|成本报表',N'tìm kiếm báo biểu|báo biểu giá thành','','','','FrmCRpt','','c38566e8-df36-4dde-bffe-eb65529d75e4','0','1','1','1','0','0','1','12  1 2017  1:08PM',0,0,NULL,1,NULL,'0019',NULL,NULL)
End
Go
Begin
Delete Sys_Module_CompanyAccount  Where ModuleCode In(Select ModuleCode From Sys_Module Where ModuleCode = 'CRpt_Module_R10293')
End
Go
Begin
Delete Sys_Module_Func  Where ModuleCode In(Select ModuleCode From Sys_Module Where ModuleCode = 'CRpt_Module_R10293')
Insert Into [Sys_Module_Func] ([ModuleCode],[FuncItemID],[AllowUsed],[ModifyDTM]) Values ('CRpt_Module_R10293','Browse',1,'11 10 2017  9:37AM')
Insert Into [Sys_Module_Func] ([ModuleCode],[FuncItemID],[AllowUsed],[ModifyDTM]) Values ('CRpt_Module_R10293','Delete',1,'11 10 2017  9:37AM')
Insert Into [Sys_Module_Func] ([ModuleCode],[FuncItemID],[AllowUsed],[ModifyDTM]) Values ('CRpt_Module_R10293','Edit',1,'11 10 2017  9:37AM')
Insert Into [Sys_Module_Func] ([ModuleCode],[FuncItemID],[AllowUsed],[ModifyDTM]) Values ('CRpt_Module_R10293','Excel',1,'11 10 2017  9:37AM')
Insert Into [Sys_Module_Func] ([ModuleCode],[FuncItemID],[AllowUsed],[ModifyDTM]) Values ('CRpt_Module_R10293','Print',1,'11 10 2017  9:37AM')
End
Go
IF OBJECT_ID('tempdb.dbo.[#Sys_Module_FuncCo]') IS NOT NULL Drop Table [#Sys_Module_FuncCo]
Select * Into [#Sys_Module_FuncCo] From [Sys_Module_FuncCo] Where 1 = 2
Begin
Insert Into [#Sys_Module_FuncCo] ([CompanyID],[RightTypeCode],[ModuleCode],[FuncItemID],[RightTypeCodeOfAccount],[IsUsed],[StartUsingDate]) Values ('HK',N'0019',N'CRpt_Module_R10293','Browse',N'0012',1,'11 30 2017  5:16PM')
Insert Into [#Sys_Module_FuncCo] ([CompanyID],[RightTypeCode],[ModuleCode],[FuncItemID],[RightTypeCodeOfAccount],[IsUsed],[StartUsingDate]) Values ('HK',N'0019',N'CRpt_Module_R10293','Delete',N'0012',1,'11 30 2017  5:16PM')
Insert Into [#Sys_Module_FuncCo] ([CompanyID],[RightTypeCode],[ModuleCode],[FuncItemID],[RightTypeCodeOfAccount],[IsUsed],[StartUsingDate]) Values ('HK',N'0019',N'CRpt_Module_R10293','Edit',N'0012',1,'11 30 2017  5:16PM')
Insert Into [#Sys_Module_FuncCo] ([CompanyID],[RightTypeCode],[ModuleCode],[FuncItemID],[RightTypeCodeOfAccount],[IsUsed],[StartUsingDate]) Values ('HK',N'0019',N'CRpt_Module_R10293','Excel',N'0012',1,'11 30 2017  5:16PM')
Insert Into [#Sys_Module_FuncCo] ([CompanyID],[RightTypeCode],[ModuleCode],[FuncItemID],[RightTypeCodeOfAccount],[IsUsed],[StartUsingDate]) Values ('HK',N'0019',N'CRpt_Module_R10293','Print',N'0012',1,'11 30 2017  5:16PM')
End
Go
 Insert Into [Sys_Module_FuncCo]  
  Select b.[CompanyID],a.[RightTypeCode],a.[ModuleCode],a.[FuncItemID],a.[RightTypeCodeOfAccount],a.[IsUsed],Getdate() As [StartUsingDate] From [#Sys_Module_FuncCo] As A  
  cross join   
   (Select distinct CompanyID   
    From Bas_Company   
    Where CompanyID <> '00000000' And IsAccount=1 
    and CompanyID in (select Distinct CompanyID from Sys_Module_FuncCo where RightTypeCode in (Select Distinct RightTypeCode From [#Sys_Module_FuncCo]))
    ) b  
  Left Outer Join [Sys_Module_FuncCo] As C On b.CompanyID = C.CompanyID And A.ModuleCode = C.ModuleCode  and a.funcitemid=c.funcitemid
  Where C.ModuleCode Is null  And (Exists(Select Top 1 1 From Bas_SubSysInitAccperiodMonth As BS WHere B.CompanyID = BS.CompanyID And A.RightTypeCodeOfAccount = BS.RightTypeCode And BS.AllowUsed = 1) Or A.RightTypeCodeOfAccount In ('0000','0001','0002','0019'))
  Drop Table [#Sys_Module_FuncCo]   
  Go 
