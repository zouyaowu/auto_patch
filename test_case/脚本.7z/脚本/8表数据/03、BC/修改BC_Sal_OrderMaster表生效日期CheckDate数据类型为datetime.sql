--USE [HK_ERP]
--GO
--BC_Sal_OrderMaster
ALTER TABLE dbo.BC_Sal_OrderMaster
ALTER COLUMN CheckDate DATETIME NULL