Delete Sys_BillMasterField WHERE ModuleCode = 'BC_NetSalOrder' AND FieldName = 'CompanyBalanceAmount'
Delete Sys_BillMasterField WHERE ModuleCode = 'BC_NetSalOrder' AND FieldName = 'CompanyMemberCode'
 Go
INSERT INTO dbo.Sys_BillMasterField
        ( CompanyCode ,ModuleCode ,ShowSequence ,FieldName ,ShowTitle ,CNFieldTitle ,
          TWFieldTitle ,ENFieldTitle ,JPFieldTitle ,KRFieldTitle ,defaultValue ,
          OtherKeyFlag ,OtherKeyField ,OtherTableName ,OtherTableAlias ,OtherFixedWhere,ControlType ,
          LookUpModule ,LookUpShowField ,LookUpShowFieldWidth ,LookUpValueMember ,
          LookUpDisplayMember ,LookUpTreeType ,LookUpIsOnlyDetail ,FieldType ,
          DisplayFormat ,FooterType ,ShowFlag ,BillFieldFlag ,SelectFieldFlag ,
          SelectShow ,SelectSequence ,SelectWidth ,SelectReadFlag ,ReadFlag ,
          GridColName ,ControlWidth ,PopedomItem ,FindShowFlag ,AuditShowFlag ,MaxLength ,
          PrintFlag, ExcelFlag , AllowUserModify)
VALUES  ( 'HK' , -- CompanyCode - varchar(5)
          'BC_NetSalOrder' , -- ModuleCode - varchar(50)
          2156 , -- ShowSequence - int
          'CompanyBalanceAmount' , -- FieldName - varchar(50)
          N'�������' , -- ShowTitle - nvarchar(50)
          N'�������' , -- CNFieldTitle - nvarchar(50)
          N'ُ�����~' , -- TWFieldTitle - nvarchar(50)
          N'�������' , -- ENFieldTitle - nvarchar(50)
          N'�������' , -- JPFieldTitle - nvarchar(50)
          N'�������' , -- KRFieldTitle - nvarchar(50)
          '' , -- defaultValue - varchar(50)
          '0' , -- OtherKeyFlag - char(1)
          '' , -- OtherKeyField - varchar(50)
          '' , -- OtherTableName - varchar(50)
          '' , -- OtherTableAlias - varchar(10)
          '' , -- OtherFixedWhere - varchar(400)
          'text' , -- ControlType - varchar(10)
          '' , -- LookUpModule - varchar(50)
          '' , -- LookUpShowField - varchar(100)
          '' , -- LookUpShowFieldWidth - varchar(50)
          '' , -- LookUpValueMember - varchar(50)
          '' , -- LookUpDisplayMember - varchar(50)
          '0' , -- LookUpTreeType - char(1)
          '1' , -- LookUpIsOnlyDetail - char(1)
          'numeric' , -- FieldType - varchar(20)
          '{0:n2}' , -- DisplayFormat - varchar(30)
          '' , -- FooterType - varchar(10)
          '1' , -- ShowFlag - char(1)
          '1' , -- BillFieldFlag - char(1)
          '1' , -- SelectFieldFlag - char(1)
          '0' , -- SelectShow - char(1)
          2156 , -- SelectSequence - int
          100 , -- SelectWidth - int
          '1' , -- SelectReadFlag - char(1)
          '1' , -- ReadFlag - char(1)
          '' , -- GridColName - varchar(50)
          120 , -- ControlWidth - int
          '' , -- PopedomItem - varchar(30)
          '0' , -- FindShowFlag - char(1)
          '1' , -- AuditShowFlag - char(1)
          1 , -- MaxLength - int
          1 , -- PrintFlag - int
          1  -- ExcelFlag - int
          , 1  -- AllowUserModify - char(1)
        )

INSERT INTO dbo.Sys_BillMasterField
        ( CompanyCode ,ModuleCode ,ShowSequence ,FieldName ,ShowTitle ,CNFieldTitle ,
          TWFieldTitle ,ENFieldTitle ,JPFieldTitle ,KRFieldTitle ,defaultValue ,
          OtherKeyFlag ,OtherKeyField ,OtherTableName ,OtherTableAlias ,OtherFixedWhere,ControlType ,
          LookUpModule ,LookUpShowField ,LookUpShowFieldWidth ,LookUpValueMember ,
          LookUpDisplayMember ,LookUpTreeType ,LookUpIsOnlyDetail ,FieldType ,
          DisplayFormat ,FooterType ,ShowFlag ,BillFieldFlag ,SelectFieldFlag ,
          SelectShow ,SelectSequence ,SelectWidth ,SelectReadFlag ,ReadFlag ,
          GridColName ,ControlWidth ,PopedomItem ,FindShowFlag ,AuditShowFlag ,MaxLength ,
          PrintFlag, ExcelFlag , AllowUserModify)
VALUES  ( 'HK' , -- CompanyCode - varchar(5)
          'BC_NetSalOrder' , -- ModuleCode - varchar(50)
          2161 , -- ShowSequence - int
          'CompanyMemberCode' , -- FieldName - varchar(50)
          N'��ҵ�ͻ�����' , -- ShowTitle - nvarchar(50)
          N'��ҵ�ͻ�����' , -- CNFieldTitle - nvarchar(50)
          N'��I�͑����a' , -- TWFieldTitle - nvarchar(50)
          N'��ҵ�ͻ�����' , -- ENFieldTitle - nvarchar(50)
          N'��ҵ�ͻ�����' , -- JPFieldTitle - nvarchar(50)
          N'��ҵ�ͻ�����' , -- KRFieldTitle - nvarchar(50)
          '' , -- defaultValue - varchar(50)
          '0' , -- OtherKeyFlag - char(1)
          '' , -- OtherKeyField - varchar(50)
          '' , -- OtherTableName - varchar(50)
          '' , -- OtherTableAlias - varchar(10)
          '' , -- OtherFixedWhere - varchar(400)
          'text' , -- ControlType - varchar(10)
          '' , -- LookUpModule - varchar(50)
          '' , -- LookUpShowField - varchar(100)
          '' , -- LookUpShowFieldWidth - varchar(50)
          '' , -- LookUpValueMember - varchar(50)
          '' , -- LookUpDisplayMember - varchar(50)
          '0' , -- LookUpTreeType - char(1)
          '1' , -- LookUpIsOnlyDetail - char(1)
          'nvarchar' , -- FieldType - varchar(20)
          '' , -- DisplayFormat - varchar(30)
          '' , -- FooterType - varchar(10)
          '1' , -- ShowFlag - char(1)
          '1' , -- BillFieldFlag - char(1)
          '1' , -- SelectFieldFlag - char(1)
          '0' , -- SelectShow - char(1)
          2161 , -- SelectSequence - int
          100 , -- SelectWidth - int
          '1' , -- SelectReadFlag - char(1)
          '1' , -- ReadFlag - char(1)
          '' , -- GridColName - varchar(50)
          120 , -- ControlWidth - int
          '' , -- PopedomItem - varchar(30)
          '0' , -- FindShowFlag - char(1)
          '1' , -- AuditShowFlag - char(1)
          1 , -- MaxLength - int
          1 , -- PrintFlag - int
          1  -- ExcelFlag - int
          , 1  -- AllowUserModify - char(1)
        )
 Go