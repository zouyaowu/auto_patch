﻿Begin
Delete Sys_ParameterItem where SysParaCode='BC090'
Insert Into [Sys_ParameterItem] ([SysParaID],[SysParaCode],[ItemIndex],[SysParaName],[SysParaNameTW],[SysParaNameEN],[SysParaNameJP],[SysParaNameKR],[SysParaType],[SysParaKind],[RightTypeCode],[ModuleID],[Remark],[RemarkTW],[RemarkEN],[RemarkJP],[RemarkKR],[DefaultValue],[ValueList],[ValueListTW],[ValueListEN],[ValueListJP],[ValueListKR],[ValueType],[GroupCode],[GroupName],[GroupNameTW],[GroupNameEN],[GroupNameJP],[GroupNameKR],[ComponetFlag],[ModifyTimes],[AllowEmpty],[IsNeedCheck],[SaveDoBusiness]) Values ('BC090',N'BC090',1,N'是否启用电商会员积分',N'是否啓用電商會員積分',N'是否启用电商会员积分',N'是否启用电商会员积分',N'是否启用电商会员积分',1,1,N'0021','',N'是否启用电商会员积分',N'是否啓用電商會員積分',N'是否启用电商会员积分',N'是否启用电商会员积分',N'是否启用电商会员积分',N'0',N'0,1;否,是',N'0,1;否,是',N'0,1;否,是',N'0,1;否,是',N'0,1;không, phải',1,N'',N'',N'是否啓用電商會員積分',N'',N'',N'',3,NULL,1,0,0)
End
Go
Begin
Delete Sys_ParameterCustomTextBox Where SysParaID In(Select SysParaID From Sys_ParameterItem where SysParaCode='BC090')
End
Go
Begin
Delete Sys_ParameterCustomLookUp Where SysParaID In(Select SysParaID From Sys_ParameterItem where SysParaCode='BC090')
End
Go
Select * Into [#Sys_ParameterDetail] From [Sys_ParameterDetail] Where 1 = 2
Begin
Insert Into [#Sys_ParameterDetail] ([CompanyID],[SysParaID],[SysParaCode],[RightTypeCode],[ModuleID],[ItemIndex],[SysParaName],[SysParaNameTW],[SysParaNameEN],[SysParaNameJP],[SysParaNameKR],[SysParaValue],[ShowValue],[ShowValueTW],[ShowValueEN],[ShowValueJP],[ShowValueKR],[ModifyFlag],[ControlFlag],[ModifyDTM],[ModifyTimes]) Values ('HK','BC090',N'BC090',N'0021','',1,N'是否启用电商会员积分',N'是否啓用電商會員積分',N'是否启用电商会员积分',N'是否启用电商会员积分',N'是否启用电商会员积分',N'1',N'是',N'是',N'是',N'是',N'是',1,0,'12  4 2017 11:21AM',NULL)
End
Go
--补充公司系统参数
		DECLARE @RightTypeCode VARCHAR(4)
		DECLARE @SysParaKind INT = 1
		SELECT @RightTypeCode = RightTypeCode, @SysParaKind = SysParaKind FROM Sys_ParameterItem where SysParaCode='BC090'
		;With AimData( SysParaID, CompanyID, RightTypeCode, ModuleID, SysParaCode, ItemIndex, SysParaName, SysParaValue, ShowValue,
		 ModifyFlag, ModifyDTM, SysParaNameTW, SysParaNameEN, SysParaNameJP, SysParaNameKR, ShowValueTW, ShowValueEN, ShowValueJP, 
		 ShowValueKR)
		 As (
			Select spi.SysParaID, spd.CompanyID, spi.RightTypeCode, spi.ModuleID, spi.SysParaCode, spi.ItemIndex, spi.SysParaName,
			DefaultValue As SysParaValue,
			dbo.GetParamValue(ValueList, DefaultValue) As ShowValue,
			1  As ModifyFlag, GetDate() As ModifyDTM, 
			spi.SysParaNameTW, spi.SysParaNameEN, spi.SysParaNameJP, spi.SysParaNameKR,
			dbo.GetParamValue(ValueListTW,DefaultValue) As ShowValueTW,
			dbo.GetParamValue(ValueListEN,DefaultValue) As ShowValueEN,
			dbo.GetParamValue(ValueListJP,DefaultValue) As ShowValueJP,
			dbo.GetParamValue(ValueListKR,DefaultValue) As ShowValueKR 
			From dbo.Sys_ParameterItem spi 
			inner join [#Sys_ParameterDetail] spd on spi.SysParaID = spd.SysParaID and spi.SysParaCode = spd.SysParaCode
			Where Isnull(spi.RightTypeCode, '') <> '' And Len(Isnull(spi.RightTypeCode, '')) = 4
		   )
		Insert Into  dbo.Sys_ParameterDetail( 
			 SysParaID, CompanyID, RightTypeCode, ModuleID, SysParaCode, ItemIndex, SysParaName, SysParaValue, ShowValue, ModifyFlag, 
			 ModifyDTM, SysParaNameTW, SysParaNameEN, SysParaNameJP, SysParaNameKR, ShowValueTW, ShowValueEN, ShowValueJP, ShowValueKR) 
		Select A.SysParaID, B.CompanyID, A.RightTypeCode, A.ModuleID, A.SysParaCode, A.ItemIndex, A.SysParaName, A.SysParaValue, 
		A.ShowValue, A.ModifyFlag, GetDate() As ModifyDTM, A.SysParaNameTW, A.SysParaNameEN, A.SysParaNameJP, A.SysParaNameKR, 
		A.ShowValueTW, A.ShowValueEN, A.ShowValueJP, A.ShowValueKR
		From AimData As A 
		CROSS JOIN 
			(Select Distinct CompanyID From Bas_Company 
			 WHERE (@RightTypeCode In ('0000', '0001', '0002') AND
			 (@SysParaKind IN (1, -1) AND CompanyID <> '00000000') OR 
			 (@SysParaKind IN (3, -3)) OR (@SysParaKind IN (0, -2) AND CompanyID =  '00000000')) 
			 OR (@RightTypeCode Not In ('0000', '0001', '0002') AND
			 (@SysParaKind IN (1, -1) AND CompanyID <> '00000000' AND IsAccount = 1)      
			 OR (@SysParaKind IN (3, -3) AND (CompanyID =  '00000000' OR IsAccount = 1))  
			 OR (@SysParaKind IN (0, -2) AND CompanyID =  '00000000'))                    
			 AND CompanyID IN(Select Distinct CompanyID From Bas_SubSysInitAccperiodMonth WHERE RightTypeCode in 
				(Select Distinct RightTypeCode From AimData))) b
		INNER JOIN [#Sys_ParameterDetail] As D ON A.CompanyID = D.CompanyID AND A.SysParaID = D.SysParaID
		LEFT OUTER JOIN [Sys_ParameterDetail] As C ON b.CompanyID = C.CompanyID AND A.SysParaID = C.SysParaID
		WHERE C.SysParaCode Is null
		Drop Table [#Sys_ParameterDetail]
		Go
