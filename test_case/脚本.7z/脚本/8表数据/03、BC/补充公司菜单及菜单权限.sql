﻿BEGIN
    DELETE  Sys_Module
    WHERE   ModuleCode = 'BC_OrderFullLink';
    INSERT  INTO [Sys_Module]
            ( [ModuleCode] ,
              [Sequence] ,
              [FacClass] ,
              [ModuleName] ,
              [CNModuleName] ,
              [TWModuleName] ,
              [ENModuleName] ,
              [JPModuleName] ,
              [KRModuleName] ,
              [RightTypeCode] ,
              [RightTypeName] ,
              [RightTypeCodeOfAccount] ,
              [FuncType] ,
              [SubSystemCode] ,
              [SubModuleCode] ,
              [ParentMenu] ,
              [CNParentMenu] ,
              [TWParentMenu] ,
              [ENParentMenu] ,
              [JPParentMenu] ,
              [KRParentMenu] ,
              [AuditType] ,
              [ClassName] ,
              [SubClassName] ,
              [PrgmName] ,
              [TableName] ,
              [Param] ,
              [ListSeparator] ,
              [IsShowModule] ,
              [IsNeedFuncLimit] ,
              [IsNeedDataLimit] ,
              [IsNeedAudit] ,
              [IsBloc] ,
              [IsCompany] ,
              [ModifyDTM] ,
              [IsAllowDownLoad] ,
              [IsAllowUpLoad] ,
              [SyncDataType] ,
              [AllowUsed] ,
              [InSubsystem] ,
              [RightTypeCodeOfMenu] ,
              [IsJoiningTrader] ,
              [IsCustomMade]
            )
    VALUES  ( 'BC_OrderFullLink' ,
              70030000100 ,
              NULL ,
              N'订单全链路' ,
              N'订单全链路' ,
              N'訂單全鏈路' ,
              N'OrderFullLink' ,
              N'订单全链路' ,
              N'订单全链路' ,
              '0021' ,
              N'电商管理' ,
              '0021' ,
              '3' ,
              'BC' ,
              'SYCustomer' ,
              N'电商管理|订单管理' ,
              N'电商管理|订单管理' ,
              N'電商管理|訂單管理' ,
              N'E-Commerce|Order' ,
              N'电商管理|订单管理' ,
              N'Quản lý cửa hàng điện/quản lý đơn hàng' ,
              '' ,
              'FrmBC.Sal.FrmBC_OrderFullLink' ,
              '' ,
              'FrmBC' ,
              '' ,
              'BC_OrderFullLink' ,
              '0' ,
              '1' ,
              '1' ,
              '1' ,
              '0' ,
              '0' ,
              '1' ,
              '11 27 2017  3:39PM' ,
              0 ,
              0 ,
              NULL ,
              1 ,
              '3,12' ,
              '0021' ,
              1 ,
              NULL
            );
END;
GO
BEGIN
    DELETE  Sys_Module_CompanyAccount
    WHERE   ModuleCode IN ( SELECT  ModuleCode
                            FROM    Sys_Module
                            WHERE   ModuleCode = 'BC_OrderFullLink' );
END;
GO
BEGIN
    DELETE  Sys_Module_Func
    WHERE   ModuleCode IN ( SELECT  ModuleCode
                            FROM    Sys_Module
                            WHERE   ModuleCode = 'BC_OrderFullLink' );
    INSERT  INTO [Sys_Module_Func]
            ( [ModuleCode] ,
              [FuncItemID] ,
              [AllowUsed] ,
              [ModifyDTM]
            )
    VALUES  ( 'BC_OrderFullLink' ,
              'Audit' ,
              1 ,
              '11 28 2017  6:08PM'
            );
    INSERT  INTO [Sys_Module_Func]
            ( [ModuleCode] ,
              [FuncItemID] ,
              [AllowUsed] ,
              [ModifyDTM]
            )
    VALUES  ( 'BC_OrderFullLink' ,
              'BackAudit' ,
              1 ,
              '11 28 2017  6:08PM'
            );
    INSERT  INTO [Sys_Module_Func]
            ( [ModuleCode] ,
              [FuncItemID] ,
              [AllowUsed] ,
              [ModifyDTM]
            )
    VALUES  ( 'BC_OrderFullLink' ,
              'Browse' ,
              1 ,
              '11 28 2017  6:08PM'
            );
    INSERT  INTO [Sys_Module_Func]
            ( [ModuleCode] ,
              [FuncItemID] ,
              [AllowUsed] ,
              [ModifyDTM]
            )
    VALUES  ( 'BC_OrderFullLink' ,
              'CustomSetGrid' ,
              1 ,
              '11 28 2017  6:08PM'
            );
    INSERT  INTO [Sys_Module_Func]
            ( [ModuleCode] ,
              [FuncItemID] ,
              [AllowUsed] ,
              [ModifyDTM]
            )
    VALUES  ( 'BC_OrderFullLink' ,
              'CustomSetUserGrid' ,
              1 ,
              '11 28 2017  6:08PM'
            );
    INSERT  INTO [Sys_Module_Func]
            ( [ModuleCode] ,
              [FuncItemID] ,
              [AllowUsed] ,
              [ModifyDTM]
            )
    VALUES  ( 'BC_OrderFullLink' ,
              'Delete' ,
              1 ,
              '11 28 2017  6:08PM'
            );
    INSERT  INTO [Sys_Module_Func]
            ( [ModuleCode] ,
              [FuncItemID] ,
              [AllowUsed] ,
              [ModifyDTM]
            )
    VALUES  ( 'BC_OrderFullLink' ,
              'Edit' ,
              1 ,
              '11 28 2017  6:08PM'
            );
    INSERT  INTO [Sys_Module_Func]
            ( [ModuleCode] ,
              [FuncItemID] ,
              [AllowUsed] ,
              [ModifyDTM]
            )
    VALUES  ( 'BC_OrderFullLink' ,
              'Insert' ,
              1 ,
              '11 28 2017  6:08PM'
            );
END;
GO
IF OBJECT_ID('tempdb.dbo.[#Sys_Module_FuncCo]') IS NOT NULL
    DROP TABLE [#Sys_Module_FuncCo];
SELECT  *
INTO    [#Sys_Module_FuncCo]
FROM    [Sys_Module_FuncCo]
WHERE   1 = 2;
BEGIN
    INSERT  INTO [#Sys_Module_FuncCo]
            ( [CompanyID] ,
              [RightTypeCode] ,
              [ModuleCode] ,
              [FuncItemID] ,
              [RightTypeCodeOfAccount] ,
              [IsUsed] ,
              [StartUsingDate]
            )
    VALUES  ( 'HK' ,
              N'0021' ,
              N'BC_OrderFullLink' ,
              'Audit' ,
              N'0021' ,
              1 ,
              '11 28 2017  6:13PM'
            );
    INSERT  INTO [#Sys_Module_FuncCo]
            ( [CompanyID] ,
              [RightTypeCode] ,
              [ModuleCode] ,
              [FuncItemID] ,
              [RightTypeCodeOfAccount] ,
              [IsUsed] ,
              [StartUsingDate]
            )
    VALUES  ( 'HK' ,
              N'0021' ,
              N'BC_OrderFullLink' ,
              'BackAudit' ,
              N'0021' ,
              1 ,
              '11 28 2017  6:13PM'
            );
    INSERT  INTO [#Sys_Module_FuncCo]
            ( [CompanyID] ,
              [RightTypeCode] ,
              [ModuleCode] ,
              [FuncItemID] ,
              [RightTypeCodeOfAccount] ,
              [IsUsed] ,
              [StartUsingDate]
            )
    VALUES  ( 'HK' ,
              N'0021' ,
              N'BC_OrderFullLink' ,
              'Browse' ,
              N'0021' ,
              1 ,
              '11 28 2017  6:13PM'
            );
    INSERT  INTO [#Sys_Module_FuncCo]
            ( [CompanyID] ,
              [RightTypeCode] ,
              [ModuleCode] ,
              [FuncItemID] ,
              [RightTypeCodeOfAccount] ,
              [IsUsed] ,
              [StartUsingDate]
            )
    VALUES  ( 'HK' ,
              N'0021' ,
              N'BC_OrderFullLink' ,
              'CustomSetGrid' ,
              N'0021' ,
              1 ,
              '11 28 2017  6:13PM'
            );
    INSERT  INTO [#Sys_Module_FuncCo]
            ( [CompanyID] ,
              [RightTypeCode] ,
              [ModuleCode] ,
              [FuncItemID] ,
              [RightTypeCodeOfAccount] ,
              [IsUsed] ,
              [StartUsingDate]
            )
    VALUES  ( 'HK' ,
              N'0021' ,
              N'BC_OrderFullLink' ,
              'CustomSetUserGrid' ,
              N'0021' ,
              1 ,
              '11 28 2017  6:13PM'
            );
    INSERT  INTO [#Sys_Module_FuncCo]
            ( [CompanyID] ,
              [RightTypeCode] ,
              [ModuleCode] ,
              [FuncItemID] ,
              [RightTypeCodeOfAccount] ,
              [IsUsed] ,
              [StartUsingDate]
            )
    VALUES  ( 'HK' ,
              N'0021' ,
              N'BC_OrderFullLink' ,
              'Delete' ,
              N'0021' ,
              1 ,
              '11 28 2017  6:13PM'
            );
    INSERT  INTO [#Sys_Module_FuncCo]
            ( [CompanyID] ,
              [RightTypeCode] ,
              [ModuleCode] ,
              [FuncItemID] ,
              [RightTypeCodeOfAccount] ,
              [IsUsed] ,
              [StartUsingDate]
            )
    VALUES  ( 'HK' ,
              N'0021' ,
              N'BC_OrderFullLink' ,
              'Edit' ,
              N'0021' ,
              1 ,
              '11 28 2017  6:13PM'
            );
    INSERT  INTO [#Sys_Module_FuncCo]
            ( [CompanyID] ,
              [RightTypeCode] ,
              [ModuleCode] ,
              [FuncItemID] ,
              [RightTypeCodeOfAccount] ,
              [IsUsed] ,
              [StartUsingDate]
            )
    VALUES  ( 'HK' ,
              N'0021' ,
              N'BC_OrderFullLink' ,
              'Insert' ,
              N'0021' ,
              1 ,
              '11 28 2017  6:13PM'
            );
END;
GO
INSERT  INTO [Sys_Module_FuncCo]
        SELECT  b.[CompanyID] ,
                A.[RightTypeCode] ,
                A.[ModuleCode] ,
                A.[FuncItemID] ,
                A.[RightTypeCodeOfAccount] ,
                A.[IsUsed] ,
                GETDATE() AS [StartUsingDate]
        FROM    [#Sys_Module_FuncCo] AS A
                CROSS JOIN ( SELECT DISTINCT
                                    CompanyID
                             FROM   Bas_Company
                             WHERE  CompanyID <> '00000000'
                                    AND IsAccount = 1
                                    AND CompanyID IN (
                                    SELECT DISTINCT
                                            CompanyID
                                    FROM    Sys_Module_FuncCo
                                    WHERE   RightTypeCode IN (
                                            SELECT DISTINCT
                                                    RightTypeCode
                                            FROM    [#Sys_Module_FuncCo] ) )
                           ) b
                LEFT OUTER JOIN [Sys_Module_FuncCo] AS C ON b.CompanyID = C.CompanyID
                                                            AND A.ModuleCode = C.ModuleCode
                                                            AND A.FuncItemID = C.FuncItemID
        WHERE   C.ModuleCode IS NULL
                AND ( EXISTS ( SELECT TOP 1
                                        1
                               FROM     Bas_SubSysInitAccperiodMonth AS BS
                               WHERE    b.CompanyID = BS.CompanyID
                                        AND A.RightTypeCodeOfAccount = BS.RightTypeCode
                                        AND BS.AllowUsed = 1 )
                      OR A.RightTypeCodeOfAccount IN ( '0000', '0001', '0002',
                                                       '0019' )
                    );
DROP TABLE [#Sys_Module_FuncCo];   
  GO 
