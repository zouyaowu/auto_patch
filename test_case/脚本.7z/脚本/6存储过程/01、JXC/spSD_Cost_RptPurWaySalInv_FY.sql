if exists(select * from sysobjects where id = object_id(N'spSD_Cost_RptPurWaySalInv_FY') )
drop procedure spSD_Cost_RptPurWaySalInv_FY
/****** Object:  StoredProcedure [dbo].[spSD_Cost_RptPurWaySalInv]    Script Date: 2017/12/1 11:37:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 

/*---------------------------------------------------------------------------------------------------------------------
����:[spSD_Cost_RptPurWaySalInv_FY]   
����:�ɱ������汨��(����)
modify by: OYH 2012-11-06  ���Ӳֿ�Ȩ�޹ܿ�
modify by: OYH 2014-01-26  �޸�Ϊ�������ѯ
exec spSD_Cost_RptPurWaySalInv @CompanyID=N'200',@StartY=N'2015',@StartM=N'9',@EndY=N'2015',@EndM=N'9',@MatCnd=N'',
@StkCode=N'',@Flag=0,@IsDetail=N'0',@ModuleCode=N'CRpt_Module_R200',
@MaterialFlag=0,@userid=N'0000000000000018',@SearchType=NULL,@GuidID=NULL
---------------------------------------------------------------------------------------------------------------------*/---------------------------------------------------------------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[spSD_Cost_RptPurWaySalInv_FY] 
   @CompanyID     varchar(20),
   @StartY        Varchar(4),
   @StartM        Varchar(2),
   @EndY          Varchar(4),
   @EndM          Varchar(2),
   @MatCnd        Varchar(max),
   @StkCode       Varchar(max),
   @Flag          Varchar(1),   --�Ƿ�ʹ��˰��ϵ����FOB������㣬'0����ʹ�ó�˰��ϵ����FOB����1����ʹ�ú�˰��ϵ����FOB  
   @IsDetail      Varchar(1),   --1 �ɱ���;����ϸ 
   @ModuleCode    Varchar(60),
   @MaterialFlag  varchar(2),
   @userid        varchar(40) ,
   @SearchType    varchar(10) = '0', --0:������ѯ  1�����ֲɹ�����������ѯ  2�������ɹ�����������ѯ
   @GuidID        varchar(100) --����    
AS
SET NOCOUNT ON
if @CompanyID='UR'
begin
    exec spSD_Cost_RptPurWaySalInv_UR @CompanyID,@StartY,@StartM,@EndY,@EndM,@MatCnd,@StkCode,@Flag,@IsDetail,@ModuleCode,
    @MaterialFlag,@userid,@SearchType,@GuidID
end
else
begin
   if ISNULL(@StartY,'')=''
      set @StartY=YEAR(GETDATE())
   if ISNULL(@StartM,'')=''
      set @StartM=Month(GETDATE())
   if ISNULL(@EndY,'')=''
      set @EndY=YEAR(GETDATE())
   if ISNULL(@EndM,'')=''
      set @EndM=Month(GETDATE())
   Declare @StartYM varchar(6),@EndYM varchar(6)
   set @StartYM=CONVERT(varchar(4),@StartY)+case when @StartM<10 THEN '0'+CONVERT(varchar(1),convert(int,@StartM)) ELSE CONVERT(varchar(2),@StartM) end
   set @EndYM=CONVERT(varchar(4),@EndY)+case when @EndM<10 THEN '0'+CONVERT(varchar(1),convert(int,@EndM)) ELSE CONVERT(varchar(2),@EndM) end
   --���ڶ���ڼ䣬����ڼ��ñ��洢
   Select AccperiodSchemeID,AccperiodID,AccperiodMonthID,PeriodYear,PeriodMonth,
   CONVERT(varchar(4),PeriodYear)+case when PeriodMonth<10 THEN '0'+CONVERT(varchar(1),PeriodMonth) ELSE CONVERT(varchar(2),PeriodMonth) end as YM,
   CONVERT(varchar(4),PeriodYear)+case when PeriodMonth<10 THEN '0'+CONVERT(varchar(1),PeriodMonth) ELSE CONVERT(varchar(2),PeriodMonth) end as PreYM  --�������£�Ϊ�˻�ȡ�ɱ���
   into #Period
   From Bas_AccperiodMonth 
   where CONVERT(varchar(4),PeriodYear)+case when PeriodMonth<10 THEN '0'+CONVERT(varchar(1),PeriodMonth) ELSE CONVERT(varchar(2),PeriodMonth) end >= @StartYM
   and CONVERT(varchar(4),PeriodYear)+case when PeriodMonth<10 THEN '0'+CONVERT(varchar(1),PeriodMonth) ELSE CONVERT(varchar(2),PeriodMonth) end <= @EndYM
   and AccperiodSchemeID in (Select AccperiodSchemeID From Bas_Company Where CompanyID = @CompanyID)
   update #Period set PreYM=CONVERT(varchar(4),PeriodYear-1)+'12' where PeriodMonth=1
   update #Period set PreYM=CONVERT(varchar(4),PeriodYear)+case when PeriodMonth-1<10 THEN '0'+CONVERT(varchar(1),PeriodMonth-1) ELSE CONVERT(varchar(2),PeriodMonth-1) end
   where PeriodMonth>1
   Declare @WhereSql Varchar(max),
           @ExcSql Varchar(max),
           @PreYM Varchar(6),
           @sYM Varchar(6) 
   Declare @Precision  Int    ---�ɱ����С��λ����    
   Declare @PreStr  varchar(2)    
   if exists (select 1 from Sys_ParameterDetail Where CompanyID = @CompanyID And SysParacode = 'C1007')   ---todo by xhl 2006-6-8     ��ֹ���û�����ô˲���ʱ,������ȷΪ@ExcSql��ֵ�����    
     Select @Precision = Isnull(SysParaValue,'4') from Sys_ParameterDetail Where CompanyID = @CompanyID And SysParacode  = 'C1007'   
   else    
	 Set @Precision=2    
   Declare @AMTPrecision  Int    ---�����㷽ʽС��λ
   select @AMTPrecision=isnull(max(PriceDecimalDigits),0) from  SD_Bas_AmtCalcMode
   if @AMTPrecision>=@Precision  --����ȡ�ϴ�ֵ
      Set @PreStr = Ltrim(str(@AMTPrecision))  
   else
      Set @PreStr = Ltrim(str(@Precision)) 
   Create table #tmp( YM varchar(10),Code int,StockID Varchar(20),MaterialID Varchar(20),Qty int Default(0),Amount money Default(0),PurRejDiffAmount decimal(24,6) )   
   Create table #tmp2( YM varchar(10),Code int,StockID Varchar(20),MaterialID Varchar(20),Qty int Default(0),Amount money Default(0) )   
   Create table #Jxc( YM varchar(10),StockID Varchar(20),MaterialID Varchar(20),
                      BegPathQty int Default(0),BegPathAmount money Default(0),--�ڳ���;
                      BeginQty int Default(0),BeginAmount money Default(0),--�ڳ��ڲ�
                      PurQty int Default(0),PurAmount money Default(0),--�ɹ���
                      RejQty int Default(0),RejAmount money Default(0),--�ɹ��� 
                      PurRejDiffAmount money Default(0),--�ɹ��˻��ɱ�����
                      DiffAmount money Default(0),ManuDiffAmount money Default(0),--�ɱ�����
                      MinQty int Default(0),MInAmount   money  Default(0), --������
                      MOutQty int Default(0),MOutAmount money Default(0),  --������
                      MLossQty Int Default(0),MLossAmount money Default(0),
                      RtlQty int Default(0),RtlAmount money Default(0),----��������
                      WhlQty int Default(0),WhlAmount money Default(0),--��������
                      WhlRejQty int Default(0),WhlRejAmount money Default(0),--�����˻�
                      ChkInQty int Default(0),ChkinAmount money Default(0),
                      ChkOutQty int Default(0),ChkOutAmount money Default(0),
                      OthInQty int Default(0),OthinAmount money Default(0),
                      OthOutQty int Default(0),OthOutAmount money Default(0), 
					  TotalInQty int Default(0),TotalInAmount money Default(0), 
					  TotalOutQty int Default(0),TotalOutAmount money Default(0),
                      LossQty int Default(0),LossAmount money Default(0),
                      PrsQty int Default(0),PrsAmount money Default(0),
                      ShopBuyQty int Default(0),ShopBuyAmount money Default(0), 
                      -------------------------------------------------
                      MoveCurOutQty int Default(0),MoveCurOutAmount money Default(0),--���µ�������δ����
                      MoveCurOutInQty int Default(0),MoveCurOutInAmount money Default(0),--���µ������µ���
                      MoveHisOutOtherCurInQty int Default(0),MoveHisOutOtherCurInAmount money Default(0),--ǰ���{�����¶Է�����
                      MoveAdjustSSQty int Default(0),MoveAdjustSSAmount money Default(0),--ǰ�µ�����ʧ����
                      MoveCurInOtherHisOutQty int Default(0),MoveCurInOtherHisOutAmount money Default(0),--ǰ�����������µ���
                      MoveCurInOutQty int Default(0),MoveCurInOutAmount money Default(0),--���µ������µ���
                      ------------------------------------------------- 
                      EndPathQty int Default(0),EndPathAmount money Default(0), --��ĩ��;
                      EndInQty int Default(0),EndInAmount money Default(0), --��ĩ�ڲ�
					  EndInCostAmount money Default(0), --��ĩ�ڲֳɱ�������*�ɱ�������ĩ�ڲֽ��������
                      ---------------------------------------------------
                      EndQty int Default(0),EndAmount money Default(0),--��ĩ�ϼ�
		              EndDiffAmount money Default(0),CloseAmount money Default(0) ) 
   	Declare @ExecSQL varchar(max)
	Set @ExecSQL = ''
	Create Table #Material (MaterialID Varchar(20))
	Set @ExecSQL = 'Insert Into #Material Select MaterialID From vwSD_Material Where CompanyID = ''' + @CompanyID +''' ' + ISNULL(@MatCnd,'')
	Exec (@ExecSQL)
	Create Table #Stock (StockID Varchar(20))
	--���Ӳֿ�����Ȩ�޹ܿ�
    if ISNULL(@StkCode, '')=''
    begin
      INSERT  INTO #Stock(StockID) --�ֿ�
      EXEC spSys_GetDataRight @CompanyID,@ModuleCode, @UserID, 'Stock'
    end
    else
	  insert into #Stock Select Distinct Class From dbo.fnSys_SplitClass(Replace(@StkCode,'''',''),',')
    --��Ʒ����
    If  ISNULL(@MatCnd,'')<>''     
        Set @WhereSql=@WhereSql+' and exists(Select top 1 * From #Material Where MaterialID=a.MaterialID) '
    Set @WhereSql=@WhereSql+' and exists(Select top 1 * From #Stock Where StockID=a.StockID)'
    alter table #Period add  MaterialCarryNo varchar(20),PreMaterialCarryNo varchar(40)
  --�����½��
  update a set a.MaterialCarryNo=CarryNo
  from #Period a inner join Sys_Carry_MonCarrySubSystem b
  on CompanyID=@CompanyID And SubSystemID='0003'  
  and a.AccperiodSchemeID=b.AccperiodSchemeID And a.AccperiodID=b.AccperiodID And a.AccperiodMonthID=b.AccperiodMonthID
  And IsCarry=1
  --�����½�ȡ�ٽ�������½��
  update a set a.PreMaterialCarryNo=
  (select Max(CarryNo) from Sys_Carry_MonCarrySubSystem where CompanyID=@CompanyID And SubSystemID='0003'  
  and AccperiodSchemeID=a.AccperiodSchemeID And IsCarry=1)
  from #Period a 
  where isnull(MaterialCarryNo,'')=''
  update a set a.PreMaterialCarryNo=
  (select Max(CarryNo) from Sys_Carry_MonCarrySubSystem where CompanyID=@CompanyID And SubSystemID='0003'  
  and AccperiodSchemeID=a.AccperiodSchemeID And IsCarry=1 and CarryNo<MaterialCarryNo)
  from #Period a 
  where isnull(MaterialCarryNo,'')<>''
	----�ڳ���;����
    Create Table #tmpInPath      --�ڳ���;
		(YM varchar(6),CostYM varchar(6),StockID varchar(20),MaterialID varchar(20),PathQty int default(0))  
	Create Table #tmpInPathEnd   --��ĩ��;
		(YM varchar(6),CostYM varchar(6),StockID varchar(20),MaterialID varchar(20),PathQty int default(0))
	Create Table #tmpSD_Inv_MoveMaster
		(YM varchar(6),CompanyID Varchar(20),BillNo Varchar(40),CostYM varchar(6))
	Create Table #tmpSD_Inv_MoveMaster2
		(YM varchar(6),CompanyID Varchar(20),BillNo Varchar(40),CostYM varchar(6))
	Create Table #tmp_StockPopedom
		(StockID Varchar(20))
	Create Table #tmpStockbegin
		(YM varchar(6),StockID varchar(20),MaterialID varchar(20),PathQty int default(0) )	
	Declare @Stosql varchar(max)
	Truncate Table #tmp_StockPopedom
	IF ISNULL(@StkCode,'')<>''
		Set @Stosql='insert into #tmp_StockPopedom select StockID from #Stock '
	ELSE
	    Set @Stosql='insert into #tmp_StockPopedom select StockID from Bas_Stock where CompanyID = ''' + @CompanyID + ''''
	exec(@stosql)
	--�³�ʱ��
	alter table #Period add  DateBegin varchar(50),DateEnd datetime
	update #Period set DateBegin=CONVERT(varchar(4),PeriodYear)+'-'+
	case when PeriodMonth<10 THEN '0'+CONVERT(varchar(1),PeriodMonth) ELSE CONVERT(varchar(2),PeriodMonth) end+'-01'
	--��ĩʱ���
	update #Period set DateEnd=DATEadd(day,-1,CONVERT(varchar(4),PeriodYear+1)+'-01-01')
	where PeriodMonth=12
	update #Period set DateEnd=DATEadd(day,-1,CONVERT(varchar(4),PeriodYear)+'-'+
	case when PeriodMonth+1<10 THEN '0'+CONVERT(varchar(1),PeriodMonth+1) ELSE CONVERT(varchar(2),PeriodMonth+1) end+'-01')
	where PeriodMonth<12
	update #Period set DateEnd=convert(varchar(10),DateEnd,120)+' 23:59:59.997'
	--�ڳ�����ĩ����;ͨ�����������ܣ���û��ȡ�������Ľ����Ŀ����Ҫ���ݵ����������·ݹ����ɱ���
	--1��ͨ���α�ͳ��ÿ���¶�Ӧ�� �ڳ� ��;����
	declare @YM varchar(20),@DateBegin varchar(50),@DateEnd varchar(50)
	DECLARE objectid_Cursor CURSOR FOR select YM, DateBegin from #Period  ORDER BY YM
	open objectid_Cursor
	FETCH NEXT FROM objectid_Cursor Into @YM,@DateBegin
	WHILE @@FETCH_STATUS = 0
	BEGIN
	  INSERT INTO #tmpSD_Inv_MoveMaster(YM,CompanyID,BillNo,CostYM)
	  SELECT DISTINCT @YM,B.CompanyID,B.BillNo,
	  CONVERT(varchar(4),year(OutCheckDate))+case when Month(OutCheckDate)<10 THEN '0'+CONVERT(varchar(1),Month(OutCheckDate)) ELSE CONVERT(varchar(2),Month(OutCheckDate)) end
	  FROM SD_Inv_MoveMaster b 
	  Inner Join SD_Inv_MoveDetail a On a.CompanyID = b.CompanyID And a.BillNo = b.BillNo 
	  Inner Join #Material m on a.MaterialID=m.MaterialID
	  where b.CompanyID=@CompanyID
	  and 
	  (
	   (b.InBillStatus <> '4' and b.OutBillStatus = '4' and Convert(varchar(10),OutCheckDate,120)<@DateBegin)
	   OR 
	   (b.InBillStatus = '4' and Convert(varchar(10),OutCheckDate,120)<@DateBegin AND Convert(varchar(10),InCheckDate,120)>=@DateBegin ) --��ֹ23:59:59�ĵ��ݣ�ת�ɳ��������ַ����ж�
       )
	  FETCH NEXT FROM objectid_Cursor Into @YM,@DateBegin
	END
	CLOSE objectid_Cursor
    DEALLOCATE objectid_Cursor
	If Exists (Select * from Sys_ParameterDetail Where SysParaCode='H0017' and CompanyID =@companyID and SysParaValue=0)--������;����������
	Begin	--ȡ��������;
		Insert InTo #tmpInPath(YM,CostYM,StockID, MaterialID, PathQty) 
		SELECT c.YM,CostYM,a.OutStockID, b.MaterialID,SUM(b.OutQty) AS PathQty 
		FROM dbo.SD_Inv_MoveMaster a
		Inner Join #tmp_StockPopedom Fn On a.OutStockID = fn.StockID
		INNER JOIN dbo.SD_Inv_MoveDetail b ON a.CompanyID = b.CompanyID AND a.BillNo = b.BillNo 
		Inner Join #tmpSD_Inv_MoveMaster c On a.CompanyID = c.CompanyID And a.BillNo = c.BillNo
		Where a.CompanyID = @CompanyID 
		GROUP BY YM,CostYM,a.OutStockID, b.MaterialID 
	End
	Else
		BEGIN	--ȡ�������;
			Insert InTo #tmpInPath(YM,CostYM,StockID, MaterialID, PathQty) 
			SELECT YM,CostYM,a.InStockID,b.MaterialID, SUM(b.OutQty) AS PathQty 
			FROM dbo.SD_Inv_MoveMaster a 
			Inner Join #tmp_StockPopedom Fn On a.InStockID = fn.StockID
			INNER JOIN dbo.SD_Inv_MoveDetail b ON a.CompanyID = b.CompanyID AND a.BillNo = b.BillNo 
			Inner Join #tmpSD_Inv_MoveMaster c On a.CompanyID = c.CompanyID And a.BillNo = c.BillNo 
			Where a.CompanyID = @CompanyID
			GROUP BY YM,CostYM,a.InStockID, b.MaterialID
		End
    CREATE INDEX tmpInPath ON #tmpInPath(YM,StockID,MaterialID)
    --2��ͨ���α�ͳ��ÿ���¶�Ӧ�� ��ĩ ��;����
	Set @YM=''
	DECLARE objectid_Cursor2 CURSOR FOR select YM,convert(varchar(30),DateEnd,121) from #Period  ORDER BY YM
	open objectid_Cursor2
	FETCH NEXT FROM objectid_Cursor2 Into @YM,@DateEnd
	WHILE @@FETCH_STATUS = 0
	BEGIN
	  INSERT INTO #tmpSD_Inv_MoveMaster2(YM,CompanyID,BillNo,CostYM)
	  SELECT DISTINCT @YM,B.CompanyID,B.BillNo,
	  CONVERT(varchar(4),year(OutCheckDate))+case when Month(OutCheckDate)<10 THEN '0'+CONVERT(varchar(1),Month(OutCheckDate)) ELSE CONVERT(varchar(2),Month(OutCheckDate)) end
	  FROM SD_Inv_MoveMaster b 
	  Inner Join SD_Inv_MoveDetail a On a.CompanyID = b.CompanyID And a.BillNo = b.BillNo 
	  Inner Join #Material m on a.MaterialID=m.MaterialID
	  where b.CompanyID=@CompanyID
	  and 
	  (
	   (b.InBillStatus <> '4' and b.OutBillStatus = '4' and OutCheckDate<=@DateEnd)
	   OR 
	   (b.InBillStatus = '4' and OutCheckDate<=@DateEnd AND Convert(varchar(10),InCheckDate,120)>convert(varchar(10),@DateEnd)) --��ֹ23:59:59�ĵ��ݣ�ת�ɳ��������ַ����ж�
       ) 
	  FETCH NEXT FROM objectid_Cursor2 Into @YM,@DateEnd
	END
	CLOSE objectid_Cursor2
    DEALLOCATE objectid_Cursor2
	If Exists (Select * from Sys_ParameterDetail Where SysParaCode='H0017' and CompanyID =@companyID and SysParaValue=0)--������;����������
	Begin	--ȡ��������;
		Insert InTo #tmpInPathEnd(YM,CostYM,StockID, MaterialID, PathQty) 
		SELECT c.YM,CostYM,a.OutStockID, b.MaterialID,SUM(b.OutQty) AS PathQty 
		FROM dbo.SD_Inv_MoveMaster a
		Inner Join #tmp_StockPopedom Fn On a.OutStockID = fn.StockID
		INNER JOIN dbo.SD_Inv_MoveDetail b ON a.CompanyID = b.CompanyID AND a.BillNo = b.BillNo 
		Inner Join #tmpSD_Inv_MoveMaster2 c On a.CompanyID = c.CompanyID And a.BillNo = c.BillNo
		Where a.CompanyID = @CompanyID 
		GROUP BY YM,CostYM,a.OutStockID, b.MaterialID 
	End
	Else
		BEGIN	--ȡ�������;
			Insert InTo #tmpInPathEnd(YM,CostYM,StockID, MaterialID, PathQty)  
			SELECT YM,CostYM,a.InStockID,b.MaterialID, SUM(b.OutQty) AS PathQty 
			FROM dbo.SD_Inv_MoveMaster a 
			Inner Join #tmp_StockPopedom Fn On a.InStockID = fn.StockID
			INNER JOIN dbo.SD_Inv_MoveDetail b ON a.CompanyID = b.CompanyID AND a.BillNo = b.BillNo 
			Inner Join #tmpSD_Inv_MoveMaster2 c On a.CompanyID = c.CompanyID And a.BillNo = c.BillNo 
			Where a.CompanyID = @CompanyID
			GROUP BY YM,CostYM,a.InStockID, b.MaterialID
		End
    CREATE INDEX tmpInPathEnd ON #tmpInPathEnd(YM,StockID,MaterialID) 
	select a.* into #SD_Inv_MoveMaster1 
	from SD_Inv_MoveMaster a inner join #Stock b on a.CompanyID=@CompanyID and a.outStockID=b.StockID
	where a.OutCheckDate>=(select min(DateBegin) from #Period) 
	and a.OutCheckDate<=(select max(DateEnd) from #Period) 
	select a.* into #SD_Inv_MoveMaster2 
	from SD_Inv_MoveMaster a inner join #Stock b on a.CompanyID=@CompanyID and a.inStockID=b.StockID
	where a.InCheckDate>=(select min(DateBegin) from #Period) 
	and a.InCheckDate<=(select max(DateEnd) from #Period) 
   --�ɱ���
   Declare @FOBStr varchar(50),@TaxRate Varchar(50),@FieldStr varchar(50)
   If @Flag='0' 
   BEGIN
		Set @FOBStr = 'FactFOB'
		Set @FieldStr = ''
   END
   Else
   BEGIN
		Set @FOBStr = 'TaxFOB'
		Set @FieldStr = ',b.TaxQuotiety'
   END
   --�Ƿ���������ɱ�
   declare @MaterialFactStr varchar(100)
   If @MaterialFlag=1
	  Set @MaterialFactStr = 'ISNULL(b.MaterialFactFOB,0))'
   Else
	  Set @MaterialFactStr = '0)'
   --�ɱ���,ע���·�:�������������·�\��ѯ�½��Լ�ǰһ�¾�����
   select (Cast(b.PeriodYear as Varchar(10))+Case When Len(b.PeriodMonth)=1 then '0' + 
           Cast(b.PeriodMonth as varchar(10)) else Cast(b.PeriodMonth as varchar(10)) End) as YM,
		  a.*,ISNULL(c.MaterialFactFOB,0) MaterialFactFOB
   into #CostPrice
   from FICA_Bas_HisCostPrice a 
   Left Join
   (Select CompanyID,AccperiodSchemeID,AccperiodID,AccperiodMonthID,MaterialID,Sum(ISNULL(FactFOB,0)) MaterialFactFOB 
   From FICA_Bas_HisCostPriceDetail 
   Group By CompanyID,AccperiodSchemeID,AccperiodID,AccperiodMonthID,MaterialID) c
   on a.CompanyID = c.CompanyID And a.AccperiodSchemeID = c.AccperiodSchemeID And a.AccperiodID = c.AccperiodID 
   And a.AccperiodMonthID = c.AccperiodMonthID And a.MaterialID = c.MaterialID 
   inner join #Material m on a.MaterialID=m.MaterialID
   Inner Join Bas_AccperiodMonth b On a.AccperiodSchemeID = b.AccperiodSchemeID 
   And a.AccperiodID = b.AccperiodID And a.AccperiodMonthID = b.AccperiodMonthID 
   where a.CompanyID=@CompanyID
   and (
   (Cast(b.PeriodYear as Varchar(10))+Case When Len(b.PeriodMonth)=1 then '0' + 
               Cast(b.PeriodMonth as varchar(10)) else Cast(b.PeriodMonth as varchar(10)) End)
		in 
		(select distinct convert(varchar(6),OutCheckDate,112) 
		from #tmpSD_Inv_MoveMaster a
		inner join SD_Inv_MoveMaster b on a.companyID = b.CompanyID and a.Billno = b.billNO
		) 
	or
    (Cast(b.PeriodYear as Varchar(10))+Case When Len(b.PeriodMonth)=1 then '0' + 
               Cast(b.PeriodMonth as varchar(10)) else Cast(b.PeriodMonth as varchar(10)) End)
		in 
		(select distinct convert(varchar(6),OutCheckDate,112) 
		from #tmpSD_Inv_MoveMaster2 a
		inner join SD_Inv_MoveMaster b on a.companyID = b.CompanyID and a.Billno = b.billNO
		) --�����������·�,ע���1����2��Ҫ������Ϊ��ȡ�����ɱ���
    or    
	(Cast(b.PeriodYear as Varchar(10))+Case When Len(b.PeriodMonth)=1 then '0' + 
               Cast(b.PeriodMonth as varchar(10)) else Cast(b.PeriodMonth as varchar(10)) End)
		in (select distinct YM from #Period)                     --����������·�
	or 	
	(Cast(b.PeriodYear as Varchar(10))+Case When Len(b.PeriodMonth)=1 then '0' + 
            Cast(b.PeriodMonth as varchar(10)) else Cast(b.PeriodMonth as varchar(10)) End)
	in (select distinct PreYM from #Period)                      --���������·ݵ���һ���� 
	)
   CREATE INDEX CostMaterialID ON #CostPrice(YM,MaterialID) 
    --�������䣬Ϊ��ȡ�ɱ��۹����·�:����������·�+�ϸ��£��ڳ��ĳɱ���ȡ���µģ�+�����������½ἴ��
    --����λ����ͳ��
	--1���ڳ���; #tmp2  code=1
    Set @ExcSql=' Insert Into #tmp2(YM,Code,StockID,MaterialID,Qty,Amount )'
               +' Select a.YM,1,a.StockID,a.MaterialID,Sum(isnull(a.PathQty,0)),Sum(Round(isnull(a.PathQty,0)*(isnull(b.'+@FOBStr+',0)+ '+@MaterialFactStr+','+@PreStr+')) '
               +' From #tmpInPath a Left Join #CostPrice b 
                  On (a.CostYM=b.YM and a.MaterialID=b.MaterialID)'   --�ڳ���;,ȡ�����·ݶ�Ӧ�ĳɱ��� a.CostYM=b.YM
               +' Where 1=1'              
    If  ISNULL(@MatCnd,'')<>''     
        Set @ExcSql=@ExcSql+' and exists(Select top 1 * From #Material Where MaterialID=a.MaterialID) '
    Set @ExcSql=@ExcSql+'  and exists(Select top 1 * From #Stock Where StockID=a.StockID) '
    Set @ExcSql=@ExcSql+' Group By a.YM,a.StockID,a.MaterialID'
    Exec(@ExcSql)
	--1����ĩ��; #tmp2  code=2
    Set @ExcSql=' Insert Into #tmp2(YM,Code,StockID,MaterialID,Qty,Amount )'
               +' Select a.YM,2,a.StockID,a.MaterialID,Sum(isnull(a.PathQty,0)),Sum(Round(isnull(a.PathQty,0)*(isnull(b.'+@FOBStr+',0)+ '+@MaterialFactStr+','+@PreStr+')) '
               +' From #tmpInPathEnd a Left Join #CostPrice b 
                  On (a.CostYM=b.YM and a.MaterialID=b.MaterialID)'   --�ڳ���;,ȡ�����·ݶ�Ӧ�ĳɱ��� a.CostYM=b.YM
               +' Where 1=1'              
    If  ISNULL(@MatCnd,'')<>''     
        Set @ExcSql=@ExcSql+' and exists(Select top 1 * From #Material Where MaterialID=a.MaterialID) '
    Set @ExcSql=@ExcSql+'  and exists(Select top 1 * From #Stock Where StockID=a.StockID) '
    Set @ExcSql=@ExcSql+' Group By a.YM,a.StockID,a.MaterialID'
	print @ExcSql
    Exec(@ExcSql)
	--3���ڳ��ڲ֣��ɵķ�ʽ�Ǳ��������½���ܲ�ɱ������棬����ֱ��ȡ���½��棬���޸�Ϊȡ����ģ���Ч�ʻ��½���
	Create Table #tmpStock(YM varchar(10),StockID varchar(20),MaterialID varchar(20),InvQty int,PathQty int)
	declare @StockTable	IDLTable,@MaterialTable	IDLTable
	DECLARE @IsAllMat int,@CalcDateTime VARCHAR(30)
	delete @StockTable
    insert into @StockTable select stockid from #Stock
	IF EXISTS ( SELECT  1 FROM  #Material ) 
	BEGIN
		delete @Materialtable  
		insert into @Materialtable select distinct Materialid from #Material
		set @IsAllMat =0
	END
    else
	   set @IsAllMat=1
    set @YM=''
	--��ѯ�����,��Ҫ�α����¼������,����DateBegin
	DECLARE objectid_Cursor3 CURSOR FOR select YM,DateBegin from #Period  ORDER BY YM
	open objectid_Cursor3
	FETCH NEXT FROM objectid_Cursor3 Into @YM,@CalcDateTime
	WHILE @@FETCH_STATUS = 0
	BEGIN
	   INSERT  INTO #tmpStock(StockID ,MaterialID ,InvQty ,PathQty)
	   EXEC spPub_CalcStockTable @CompanyID,@stocktable, @Materialtable,@IsAllMat,@CalcDateTime, 0,0
	   update #tmpStock set YM=@YM where ISNULL(YM,'')=''
	   set @YM=''
	   FETCH NEXT FROM objectid_Cursor3 Into @YM,@CalcDateTime
	END
	CLOSE objectid_Cursor3
    DEALLOCATE objectid_Cursor3
	 --�ڳ��ڲ�   #tmp ,code=1
	 Set @ExcSql=' Insert Into #tmp(YM,Code,StockID,MaterialID,Qty,Amount )'
               +' Select a.YM,1,a.StockID,a.MaterialID,Sum(isnull(a.InvQty,0)),Sum(Round(isnull(a.InvQty,0)*(isnull(b.'+@FOBStr+',0)+ '+@MaterialFactStr+','+@PreStr+')) '
               +' From #tmpStock a inner join #Period c on a.YM =c.YM  Left Join #CostPrice b On (c.PreYM=b.YM and a.MaterialID=b.MaterialID)'
               +' Where 1=1 '  
    If  ISNULL(@MatCnd,'')<>''     
        Set @ExcSql=@ExcSql+' and exists(Select top 1 * From #Material Where MaterialID=a.MaterialID) '
    Set @ExcSql=@ExcSql+'  and exists(Select top 1 * From #Stock Where StockID=a.StockID) '
    Set @ExcSql=@ExcSql+' Group By a.YM,a.StockID,a.MaterialID'
    Exec(@ExcSql)
	--�ɹ�     #tmp ,code=2 (ȡ�ɹ����ĳɱ���,δ���Ǹ����ɱ�)
    Set @ExcSql=' Insert Into #tmp(YM,Code,StockID,MaterialID,Qty,Amount )'
               +' Select a.YM,2,a.StockID,a.MaterialID,Sum(a.Qty),Sum(a.Amount) '
               +' From  (
						Select  Cast(DATEPART(YEAR,a.CheckDate) as Varchar(20))+Cast((Case  When Datepart(month,a.CheckDate)<=9 then ''0''
						+Convert(Varchar(2),Datepart(month,a.CheckDate)) else  Convert(Varchar(2),Datepart(month,a.CheckDate)) End) 
						as Varchar(20)) as YM,a.CompanyID, a.VendCustID,a.StockID,a.CheckDate,a.Billno,
						b.MaterialID,SUM(ISNULL(b.Qty,0)) Qty,Sum(ISNULL(b.Qty,0)*IsNull(Round(b.CostPrice,'+@PreStr+'),0)) as Amount'+@FieldStr+'  
						From SD_Inv_TransMaster a
						Inner Join SD_Inv_TransDetail b On a.CompanyID = b.CompanyID And a.BillNo = b.BillNo
						Where a.CompanyID = '''+@CompanyID+''' And a.BillTypeID = ''Inv_Cgrk''  And a.BillStatus = ''4''
						Group By a.CompanyID, a.VendCustID,a.StockID,a.CheckDate,a.Billno,b.MaterialID
                        ) a inner join #Period b on a.YM=b.YM Where 1=1'
	  If  ISNULL(@MatCnd,'')<>''     
          Set @ExcSql=@ExcSql+' and exists(Select top 1 * From #Material Where MaterialID=a.MaterialID) '
      Set @ExcSql=@ExcSql+'  and exists(Select top 1 * From #Stock Where StockID=a.StockID) '
      Set @ExcSql=@ExcSql+' Group By a.YM,a.StockID,a.MaterialID'	  
      Exec(@ExcSql) 
	  --�ɹ��˻�(δ���Ǹ����ɱ�) #tmp ,code=3
	   Declare @IsPurReject char(1) --�ɹ��˻�������ɱ����㣿
	   Declare @PurIndex int
	   set @IsPurReject = '0'  --0 ���������� 1 ���������
	   Select @PurIndex=CHARINDEX('PurRejectCostAmount',CostExpressions) From FICA_Bas_CostExpressions Where CompanyID=@CompanyID
	   If @PurIndex = 0
	   BEGIN
			Set @IsPurReject = '1'
	   END
	   Else
	   BEGIN
			Set @IsPurReject = '0'
	   END
      if @IsPurReject = '1' --�ɹ��˻���ȡ  ����*�ɱ��� �ɹ��˻��ɱ�����=�ɹ��˻����-�ɹ��˻�����*���³ɱ����� (��ʤ���� BY641) a.YM=b.YM �ĳ� c.PreYM=b.YM��a.CostAmount �ĳ� a.BalaAmount
      begin
		   Set @ExcSql=' Insert Into #tmp(YM,Code,StockID,MaterialID,Qty,Amount,PurRejDiffAmount )'
				+' Select a.YM,3,a.StockID,a.MaterialID,Sum(a.Qty),Sum(a.Qty*Round((isnull(b.'+@FOBStr+',0)+ 0) ,'+@PreStr+')),
				Sum(a.TaxBalaAmount)-Sum(a.Qty*Round((isnull(b.'+@FOBStr+',0)+ 0) ,'+@PreStr+'))'
				+' From (
					Select  Cast(DATEPART(YEAR,a.CheckDate) as Varchar(20))+
					Cast((Case  When Datepart(month,a.CheckDate)<=9 then ''0''
					+Convert(Varchar(2),Datepart(month,a.CheckDate)) else  Convert(Varchar(2),Datepart(month,a.CheckDate)) 
						End) as Varchar(20)) as YM,a.CompanyID, a.VendCustID,a.StockID,a.CheckDate,a.Billno,
						b.MaterialID,SUM(ISNULL(b.Qty,0)) Qty,Sum(ISNULL(b.Qty,0)*IsNull(Round(b.CostPrice,'+@PreStr+'),0)) CostAmount,
						Sum(b.PayAmount) BalaAmount,Sum(b.PayAmount/(1+b.TaxRate)) TaxBalaAmount
					From SD_Inv_TransMaster a
					Inner Join SD_Inv_TransDetail b On a.CompanyID = b.CompanyID And a.BillNo = b.BillNo
					Where a.BillTypeID = ''Inv_Thck''  And a.BillStatus = ''4''
					Group By a.CompanyID, a.VendCustID,a.StockID,a.CheckDate,a.Billno,b.MaterialID
				) a 
				inner join #Period c on a.YM=c.YM 
				Left Outer Join #CostPrice b On (c.PreYM=b.YM and a.MaterialID=b.MaterialID)  
				where 1=1'
			If  ISNULL(@MatCnd,'')<>''     
                Set @ExcSql=@ExcSql+' and exists(Select top 1 * From #Material Where MaterialID=a.MaterialID) '
            Set @ExcSql=@ExcSql+'  and exists(Select top 1 * From #Stock Where StockID=a.StockID) '
            Set @ExcSql=@ExcSql+' Group By a.YM,a.StockID,a.MaterialID'
      end 
	  else
      begin   --�ɹ��˻���ȡ ���ݽ��
			Set @ExcSql=' Insert Into #tmp(YM,Code,StockID,MaterialID,Qty,Amount,PurRejDiffAmount)'
			+' Select a.YM,3,a.StockID,a.MaterialID,Sum(a.Qty),Sum(a.Amount),
			   Sum(a.TaxBalaAmount)-Sum(a.Qty*Round((isnull(b.'+@FOBStr+',0)+ 0) ,'+@PreStr+')) '
			+' From (
				Select  Cast(DATEPART(YEAR,a.CheckDate) as Varchar(20))+
				Cast((Case  When Datepart(month,a.CheckDate)<=9 then ''0''
				+Convert(Varchar(2),Datepart(month,a.CheckDate)) else  Convert(Varchar(2),Datepart(month,a.CheckDate)) 
				End) as Varchar(20)) as YM,a.CompanyID, a.VendCustID,a.StockID,a.CheckDate,a.Billno,
				b.MaterialID,SUM(ISNULL(b.Qty,0)) Qty,Sum(ISNULL(b.Qty,0)*IsNull(Round(b.CostPrice,'+@PreStr+'),0)) as Amount,
				Sum(b.PayAmount) BalaAmount,Sum(b.PayAmount/(1+b.TaxRate)) TaxBalaAmount
				From SD_Inv_TransMaster a
				Inner Join SD_Inv_TransDetail b On a.CompanyID = b.CompanyID And a.BillNo = b.BillNo
				Where a.BillTypeID = ''Inv_Thck''  And a.BillStatus = ''4''
				Group By a.CompanyID, a.VendCustID,a.StockID,a.CheckDate,a.Billno,b.MaterialID
			) a 					  
			inner join #Period c on a.YM=c.YM
			Left Outer Join #CostPrice b On (c.PreYM=b.YM and a.MaterialID=b.MaterialID) 
			where 1=1'
			If  ISNULL(@MatCnd,'')<>''     
                Set @ExcSql=@ExcSql+' and exists(Select top 1 * From #Material Where MaterialID=a.MaterialID) '
            Set @ExcSql=@ExcSql+'  and exists(Select top 1 * From #Stock Where StockID=a.StockID) '
            Set @ExcSql=@ExcSql+' Group By a.YM,a.StockID,a.MaterialID'
       end	   
       Exec(@ExcSql)
      --��������  #tmp ,code=4
	  select a.* into #vwSD_Pos_SaleMaster from vwSD_Pos_SaleMaster a 
	  inner join #Stock b on a.CompanyID=@CompanyID and a.StockID=b.StockID
	  and a.BillDate>=(select min(DateBegin) from #Period) 
	  and a.BillDate<=(select max(DateEnd) from #Period) 
	  where a.ispresale=0
      Set @ExcSql=' Insert Into #tmp(YM,Code,StockID,MaterialID,Qty,Amount )'
               +' Select a.YM,4,a.StockID,a.MaterialID,Sum(a.Qty),Sum(Round(a.Qty*(isnull(b.'+@FOBStr+',0)+ '+@MaterialFactStr+','+@PreStr+')) '
               +' From (
						Select Cast(DATEPART(YEAR,a.BillDate) as Varchar(20))+
						Cast((Case  When Datepart(month,a.BillDate)<=9 then ''0''
						+Convert(Varchar(2),Datepart(month,a.BillDate)) else  Convert(Varchar(2),Datepart(month,a.BillDate))
						End) as Varchar(20)) as YM,a.CompanyID,a.StockID,a.BillDate,b.SaleType,a.BillNo,b.MaterialID,b.Qty 
						From #vwSD_Pos_SaleMaster a 
						Inner Join vwSD_Pos_SaleDetail b On a.CompanyID = b.CompanyID And a.BillNo = b.BillNo
                        )  a 
						inner join #Period c on a.YM=c.YM 
						Left Outer Join #CostPrice b
						On (a.YM=b.YM and a.MaterialID=b.MaterialID)'
               +' Where 1=1'
		If  ISNULL(@MatCnd,'')<>''     
            Set @ExcSql=@ExcSql+' and exists(Select top 1 * From #Material Where MaterialID=a.MaterialID) '
        Set @ExcSql=@ExcSql+'  and exists(Select top 1 * From #Stock Where StockID=a.StockID) '
        Set @ExcSql=@ExcSql+' Group By a.YM,a.StockID,a.MaterialID'
        Exec(@ExcSql)
	    drop table #vwSD_Pos_SaleMaster
		--��������  #tmp ,code=5
		Set @ExcSql=' Insert Into #tmp(YM,Code,StockID,MaterialID,Qty,Amount )'
				   +' Select a.YM,5,a.StockID,a.MaterialID,Sum(a.Qty),'
				   +' Sum (Round(a.Qty*(isnull(b.'+@FOBStr+',0)+ '+@MaterialFactStr+','+@PreStr+')) '
				   +' From (
							Select Cast(DATEPART(YEAR,a.CheckDate) as Varchar(20))+
								Cast((Case  When Datepart(month,a.CheckDate)<=9 then ''0''
								+Convert(Varchar(2),Datepart(month,a.CheckDate)) else  Convert(Varchar(2),Datepart(month,a.CheckDate))
									End) as Varchar(20)) as YM,a.CompanyID,a.StockID,a.VendCustID,a.CheckDate,a.BillNo,b.MaterialID,b.Qty 
							From SD_Inv_TransMaster a 
							Inner Join SD_Inv_TransDetail b On a.CompanyID = b.CompanyID And a.BillNo = b.BillNo
							Where a.BillTypeID = ''Inv_Ssck'' And a.BillStatus = ''4''
							)  a 
						inner join #Period c on a.YM=c.YM 
						Left Outer Join #CostPrice b
						On (a.YM=b.YM and a.MaterialID=b.MaterialID)'
               +' Where 1=1'
		If  ISNULL(@MatCnd,'')<>''     
            Set @ExcSql=@ExcSql+' and exists(Select top 1 * From #Material Where MaterialID=a.MaterialID) '
        Set @ExcSql=@ExcSql+'  and exists(Select top 1 * From #Stock Where StockID=a.StockID) '
        Set @ExcSql=@ExcSql+' Group By a.YM,a.StockID,a.MaterialID'
        Exec(@ExcSql)
	    --���������˻� #tmp ,code=6
        Set @ExcSql=' Insert Into #tmp(YM,Code,StockID,MaterialID,Qty,Amount )'
                  +' Select a.YM,6,a.StockID,a.MaterialID,Sum(a.Qty),'
                  +' Sum(Round(a.Qty*(isnull(b.'+@FOBStr+',0)+ '+@MaterialFactStr+','+@PreStr+')) '
                  +' From (
				 			Select Cast(DATEPART(YEAR,a.CheckDate) as Varchar(20))+
								Cast((Case  When Datepart(month,a.CheckDate)<=9 then ''0''
								+Convert(Varchar(2),Datepart(month,a.CheckDate)) else  Convert(Varchar(2),Datepart(month,a.CheckDate))
									End) as Varchar(20)) as YM,a.CompanyID,a.StockID,a.VendCustID,a.CheckDate,a.BillNo,b.MaterialID,b.Qty 
							From SD_Inv_TransMaster a 
							Inner Join SD_Inv_TransDetail b On a.CompanyID = b.CompanyID And a.BillNo = b.BillNo
							Where a.BillTypeID = ''Inv_Thrk'' And a.BillStatus = ''4''
                           ) a inner join #Period c on a.YM=c.YM 
						       Left Outer Join #CostPrice b
						On (a.YM=b.YM and a.MaterialID=b.MaterialID)'
               +' Where 1=1'
		If  ISNULL(@MatCnd,'')<>''     
            Set @ExcSql=@ExcSql+' and exists(Select top 1 * From #Material Where MaterialID=a.MaterialID) '
        Set @ExcSql=@ExcSql+'  and exists(Select top 1 * From #Stock Where StockID=a.StockID) '
        Set @ExcSql=@ExcSql+' Group By a.YM,a.StockID,a.MaterialID'
	    Exec(@ExcSql)
		--��ӯ  #tmp ,code=7
		Set @ExcSql=' Insert Into #tmp(YM,Code,StockID,MaterialID,Qty,Amount )'
				   +' Select a.YM,7,a.StockID,a.MaterialID,Sum(a.Qty),Sum(Round(a.Qty*(isnull(b.'+@FOBStr+',0)+ '+@MaterialFactStr+','+@PreStr+')) '
				   +' From (
							Select Cast(DATEPART(YEAR,a.CheckDate) as Varchar(20))+
								Cast((Case  When Datepart(month,a.CheckDate)<=9 then ''0''
								+Convert(Varchar(2),Datepart(month,a.CheckDate)) else  Convert(Varchar(2),Datepart(month,a.CheckDate))
									End) as Varchar(20)) as YM,a.CompanyID,a.StockID,a.VendCustID,a.CheckDate,a.BillNo,b.MaterialID,b.Qty 
							From SD_Inv_TransMaster a 
							Inner Join SD_Inv_TransDetail b On a.CompanyID = b.CompanyID And a.BillNo = b.BillNo
							Where a.BillTypeID = ''Inv_Pyrk'' And a.BillStatus = ''4''
							) a 
							inner join #Period c on a.YM=c.YM 
						    Left Outer Join #CostPrice b
						On (a.YM=b.YM and a.MaterialID=b.MaterialID)'
                   +' Where 1=1'
		If  ISNULL(@MatCnd,'')<>''     
            Set @ExcSql=@ExcSql+' and exists(Select top 1 * From #Material Where MaterialID=a.MaterialID) '
        Set @ExcSql=@ExcSql+'  and exists(Select top 1 * From #Stock Where StockID=a.StockID) '
        Set @ExcSql=@ExcSql+' Group By a.YM,a.StockID,a.MaterialID'
	    Exec(@ExcSql)
		--�̿� #tmp ,code=8
		Set @ExcSql=' Insert Into #tmp(YM,Code,StockID,MaterialID,Qty,Amount )'
				   +' Select a.YM,8,a.StockID,a.MaterialID,Sum(a.Qty),Sum(Round(a.Qty*(isnull(b.'+@FOBStr+',0)+ '+@MaterialFactStr+','+@PreStr+')) '
				   +' From (
							Select Cast(DATEPART(YEAR,a.CheckDate) as Varchar(20))+
							Cast((Case  When Datepart(month,a.CheckDate)<=9 then ''0''
							+Convert(Varchar(2),Datepart(month,a.CheckDate)) else  Convert(Varchar(2),Datepart(month,a.CheckDate))
							End) as Varchar(20)) as YM,a.CompanyID,a.StockID,a.VendCustID,a.CheckDate,a.BillNo,b.MaterialID,b.Qty 
							From SD_Inv_TransMaster a 
							Inner Join SD_Inv_TransDetail b On a.CompanyID = b.CompanyID And a.BillNo = b.BillNo
							Where a.BillTypeID = ''Inv_Pkck'' And a.BillStatus = ''4''
							) a 
							inner join #Period c on a.YM=c.YM 
						    Left Outer Join #CostPrice b
						On (a.YM=b.YM and a.MaterialID=b.MaterialID)'
                   +' Where 1=1'
		If  ISNULL(@MatCnd,'')<>''     
            Set @ExcSql=@ExcSql+' and exists(Select top 1 * From #Material Where MaterialID=a.MaterialID) '
        Set @ExcSql=@ExcSql+'  and exists(Select top 1 * From #Stock Where StockID=a.StockID) '
        Set @ExcSql=@ExcSql+' Group By a.YM,a.StockID,a.MaterialID'
	    Exec(@ExcSql)
		--������� #tmp ,code=9
		Set @ExcSql=' Insert Into #tmp(YM,Code,StockID,MaterialID,Qty,Amount )'
				   +' Select a.YM,9,a.StockID,a.MaterialID,Sum(a.Qty),Sum(Round(a.Qty*(isnull(b.'+@FOBStr+',0)+ '+@MaterialFactStr+','+@PreStr+')) '
				   +' From (
							Select Cast(DATEPART(YEAR,a.CheckDate) as Varchar(20))+
							Cast((Case  When Datepart(month,a.CheckDate)<=9 then ''0''
							+Convert(Varchar(2),Datepart(month,a.CheckDate)) else  Convert(Varchar(2),Datepart(month,a.CheckDate))
							End) as Varchar(20)) as YM,a.CompanyID,a.StockID,a.VendCustID,a.CheckDate,a.BillNo,b.MaterialID,b.Qty 
							From SD_Inv_TransMaster a 
							Inner Join SD_Inv_TransDetail b On a.CompanyID = b.CompanyID And a.BillNo = b.BillNo
							Where a.BillTypeID = ''Inv_Qtrk'' And a.BillStatus = ''4''
							) a 
							inner join #Period c on a.YM=c.YM 
						    Left Outer Join #CostPrice b
						On (a.YM=b.YM and a.MaterialID=b.MaterialID)'
                   +' Where 1=1'
		If  ISNULL(@MatCnd,'')<>''     
            Set @ExcSql=@ExcSql+' and exists(Select top 1 * From #Material Where MaterialID=a.MaterialID) '
        Set @ExcSql=@ExcSql+'  and exists(Select top 1 * From #Stock Where StockID=a.StockID) '
        Set @ExcSql=@ExcSql+' Group By a.YM,a.StockID,a.MaterialID'
	    Exec(@ExcSql)
		--�������� #tmp ,code=10
		Set @ExcSql=' Insert Into #tmp(YM,Code,StockID,MaterialID,Qty,Amount )'
				   +' Select a.YM,10,a.StockID,a.MaterialID,Sum(a.Qty),Sum(Round(a.Qty*(isnull(b.'+@FOBStr+',0)+ '+@MaterialFactStr+','+@PreStr+')) '
				   +' From (
							Select Cast(DATEPART(YEAR,a.CheckDate) as Varchar(20))+
							Cast((Case  When Datepart(month,a.CheckDate)<=9 then ''0''
							+Convert(Varchar(2),Datepart(month,a.CheckDate)) else  Convert(Varchar(2),Datepart(month,a.CheckDate))
							End) as Varchar(20)) as YM,a.CompanyID,a.StockID,a.VendCustID,a.CheckDate,a.BillNo,b.MaterialID,b.Qty 
							From SD_Inv_TransMaster a 
							Inner Join SD_Inv_TransDetail b On a.CompanyID = b.CompanyID And a.BillNo = b.BillNo
							Where a.BillTypeID = ''Inv_Qtck'' And a.BillStatus = ''4''
							) a 
							inner join #Period c on a.YM=c.YM 
						    Left Outer Join #CostPrice b
						On (a.YM=b.YM and a.MaterialID=b.MaterialID)'
                   +' Where 1=1'
		If  ISNULL(@MatCnd,'')<>''     
            Set @ExcSql=@ExcSql+' and exists(Select top 1 * From #Material Where MaterialID=a.MaterialID) '
        Set @ExcSql=@ExcSql+'  and exists(Select top 1 * From #Stock Where StockID=a.StockID) '
        Set @ExcSql=@ExcSql+' Group By a.YM,a.StockID,a.MaterialID'
	    Exec(@ExcSql)
		--������� #tmp ,code=11
		Set @ExcSql=' Insert Into #tmp(YM,Code,StockID,MaterialID,Qty,Amount )'
				   +' Select a.YM,11,a.StockID,a.MaterialID,Sum(a.Qty),Sum(Round(a.Qty*(isnull(b.'+@FOBStr+',0)+ '+@MaterialFactStr+','+@PreStr+')) '
				   +' From (
							Select Cast(DATEPART(YEAR,a.CheckDate) as Varchar(20))+
							Cast((Case  When Datepart(month,a.CheckDate)<=9 then ''0''
							+Convert(Varchar(2),Datepart(month,a.CheckDate)) else  Convert(Varchar(2),Datepart(month,a.CheckDate))
							End) as Varchar(20)) as YM,a.CompanyID,a.StockID,a.VendCustID,a.CheckDate,a.BillNo,b.MaterialID,b.Qty 
							From SD_Inv_TransMaster a 
							Inner Join SD_Inv_TransDetail b On a.CompanyID = b.CompanyID And a.BillNo = b.BillNo
							Where a.BillTypeID = ''Inv_Bsck'' And a.BillStatus = ''4''
							)  a 
							inner join #Period c on a.YM=c.YM 
						    Left Outer Join #CostPrice b
						On (a.YM=b.YM and a.MaterialID=b.MaterialID)'
                   +' Where 1=1'
		If  ISNULL(@MatCnd,'')<>''     
            Set @ExcSql=@ExcSql+' and exists(Select top 1 * From #Material Where MaterialID=a.MaterialID) '
        Set @ExcSql=@ExcSql+'  and exists(Select top 1 * From #Stock Where StockID=a.StockID) '
        Set @ExcSql=@ExcSql+' Group By a.YM,a.StockID,a.MaterialID'
	    Exec(@ExcSql)
		--�������� #tmp ,code=12
		Set @ExcSql=' Insert Into #tmp(YM,Code,StockID,MaterialID,Qty,Amount )'
				   +' Select a.YM,12,a.StockID,a.MaterialID,Sum(a.Qty),Sum(Round(a.Qty*(isnull(b.'+@FOBStr+',0)+ '+@MaterialFactStr+','+@PreStr+')) '
				   +' From (
									Select Cast(DATEPART(YEAR,a.CheckDate) as Varchar(20))+
										Cast((Case  When Datepart(month,a.CheckDate)<=9 then ''0''
										+Convert(Varchar(2),Datepart(month,a.CheckDate)) else  Convert(Varchar(2),Datepart(month,a.CheckDate))
										 End) as Varchar(20)) as YM,a.CompanyID,a.StockID,a.VendCustID,a.CheckDate,a.BillNo,b.MaterialID,b.Qty 
									From SD_Inv_TransMaster a 
									Inner Join SD_Inv_TransDetail b On a.CompanyID = b.CompanyID And a.BillNo = b.BillNo
									Where a.BillTypeID = ''Inv_Yzck'' And a.BillStatus = ''4''
							   )  a 
							inner join #Period c on a.YM=c.YM 
						    Left Outer Join #CostPrice b
						On (a.YM=b.YM and a.MaterialID=b.MaterialID)'
                   +' Where 1=1'
		If  ISNULL(@MatCnd,'')<>''     
            Set @ExcSql=@ExcSql+' and exists(Select top 1 * From #Material Where MaterialID=a.MaterialID) '
        Set @ExcSql=@ExcSql+'  and exists(Select top 1 * From #Stock Where StockID=a.StockID) '
        Set @ExcSql=@ExcSql+' Group By a.YM,a.StockID,a.MaterialID'
	    Exec(@ExcSql)
		--�չ�������� #tmp ,code=30
		Set @ExcSql=' Insert Into #tmp(YM,Code,StockID,MaterialID,Qty,Amount )'
				   +' Select a.YM,30,a.StockID,a.MaterialID,Sum(a.Qty),Sum(a.Amount) '
				   +' From (
							Select  Cast(DATEPART(YEAR,a.CheckDate) as Varchar(20))+
								Cast((Case  When Datepart(month,a.CheckDate)<=9 then ''0''
								+Convert(Varchar(2),Datepart(month,a.CheckDate)) else  Convert(Varchar(2),Datepart(month,a.CheckDate)) 
									End) as Varchar(20)) as YM,a.CompanyID, a.VendCustID,a.StockID,a.CheckDate,a.Billno,
									b.MaterialID,SUM(ISNULL(b.Qty,0)) Qty,Sum(ISNULL(b.Qty,0)*IsNull(Round(b.CostPrice,'+@PreStr+'),0)) as Amount  
							From SD_Inv_TransMaster a
							Inner Join SD_Inv_TransDetail b On a.CompanyID = b.CompanyID And a.BillNo = b.BillNo
							Where a.CompanyID = '''+@CompanyID+''' And a.BillTypeID = ''Inv_ShopBuyIn''  And a.BillStatus = ''4''
							Group By a.CompanyID, a.VendCustID,a.StockID,a.CheckDate,a.Billno,b.MaterialID
						   ) a 							
						   inner join #Period c on a.YM=c.YM '
                   +' Where 1=1'
		If  ISNULL(@MatCnd,'')<>''     
            Set @ExcSql=@ExcSql+' and exists(Select top 1 * From #Material Where MaterialID=a.MaterialID) '
        Set @ExcSql=@ExcSql+'  and exists(Select top 1 * From #Stock Where StockID=a.StockID) '
        Set @ExcSql=@ExcSql+' Group By a.YM,a.StockID,a.MaterialID'
	    Exec(@ExcSql)
		--����  #tmp ,code=19 (������=���������·ݵĳɱ���*����)
		Set @ExcSql=' Insert Into #tmp(YM,Code,StockID,MaterialID,Qty,Amount )'  
					+' Select a.YM,19,a.StockID,a.MaterialID,Sum(a.Qty),Sum(Round(a.Qty*(isnull(b.'+@FOBStr+',0)+ '+@MaterialFactStr+','+@PreStr+')) '  
					+' From (
					   Select Cast(DATEPART(YEAR,a.InCheckDate) as Varchar(20))+
					   Cast((Case  When Datepart(month,a.InCheckDate)<=9 then ''0''
					   +Convert(Varchar(2),Datepart(month,a.InCheckDate)) else  Convert(Varchar(2),Datepart(month,a.InCheckDate))
					   End) as Varchar(20)) as YM,Cast(DATEPART(YEAR,a.OutCheckDate) as Varchar(20))+Cast((Case  When Datepart(month,a.OutCheckDate)<=9 then ''0''
					   +Convert(Varchar(2),Datepart(month,a.OutCheckDate)) else  Convert(Varchar(2),Datepart(month,a.OutCheckDate))
					   End) as Varchar(20)) as OutYM,a.CompanyID,a.InStockID as StockID,a.MoveType,a.InCheckDate,a.BillNo,b.MaterialID,b.InQty as Qty
					   From #SD_Inv_MoveMaster2 a 
					   Inner Join SD_Inv_MoveDetail b On a.CompanyID = b.CompanyID And a.BillNo = b.BillNo
					   Where a.InBillStatus = ''4''  								
					) a 							
					inner join #Period c on a.YM=c.YM 
					Left Outer Join #CostPrice b
					On (a.YM=b.YM and a.MaterialID=b.MaterialID)'
                   +' Where 1=1'
		If  ISNULL(@MatCnd,'')<>''     
            Set @ExcSql=@ExcSql+' and exists(Select top 1 * From #Material Where MaterialID=a.MaterialID) '
        Set @ExcSql=@ExcSql+'  and exists(Select top 1 * From #Stock Where StockID=a.StockID) '
        Set @ExcSql=@ExcSql+' Group By a.YM,a.StockID,a.MaterialID'
		print @ExcSql
		Exec (@ExcSql)  
		--����  #tmp ,code=20
		Set @ExcSql=' Insert Into #tmp(YM,Code,StockID,MaterialID,Qty,Amount )'   
					+' Select a.YM,20,a.StockID,a.MaterialID,Sum(a.Qty),Sum(Round(a.Qty*(isnull(b.'+@FOBStr+',0)+ '+@MaterialFactStr+','+@PreStr+')) '  
					+'  From  (
						Select Cast(DATEPART(YEAR,a.OutCheckDate) as Varchar(20))+
						Cast((Case  When Datepart(month,a.OutCheckDate)<=9 then ''0''
						+Convert(Varchar(2),Datepart(month,a.OutCheckDate)) else  Convert(Varchar(2),Datepart(month,a.OutCheckDate))
						End) as Varchar(20)) as YM,a.CompanyID,a.OutStockID as StockID,a.MoveType,a.OutCheckDate,
						a.BillNo,b.MaterialID,b.OutQty as Qty
						From #SD_Inv_MoveMaster1 a 
						Inner Join SD_Inv_MoveDetail b On a.CompanyID = b.CompanyID And a.BillNo = b.BillNo
						Where a.OutBillStatus = ''4''
					) a 
					inner join #Period c on a.YM=c.YM 
					Left Outer Join #CostPrice b
					On (a.YM=b.YM and a.MaterialID=b.MaterialID)'
                   +' Where 1=1'
		If  ISNULL(@MatCnd,'')<>''     
            Set @ExcSql=@ExcSql+' and exists(Select top 1 * From #Material Where MaterialID=a.MaterialID) '
        Set @ExcSql=@ExcSql+'  and exists(Select top 1 * From #Stock Where StockID=a.StockID) '
        Set @ExcSql=@ExcSql+' Group By a.YM,a.StockID,a.MaterialID'
		print @ExcSql
		Exec (@ExcSql)
		DROP TABLE #SD_Inv_MoveMaster1
		DROP TABLE #SD_Inv_MoveMaster2
		--�ֶ��������� #tmp ,code=21
		Set @ExcSql=' Insert Into #tmp(YM,Code,StockID,MaterialID,Qty,Amount )'   
					+' Select a.YM,21,a.StockID,a.MaterialID,0,Sum(Round(ISNULL(a.Amount,0),'+@PreStr+')) '  
						+'  From  (
							Select Cast(DATEPART(YEAR,a.setCheckDate) as Varchar(20))+
							Cast((Case  When Datepart(month,a.setCheckDate)<=9 then ''0''
							+Convert(Varchar(2),Datepart(month,a.setCheckDate)) else  Convert(Varchar(2),Datepart(month,a.setCheckDate))
							End) as Varchar(20)) as YM,a.CompanyID,a.StockID,b.MaterialID,Sum(ISNULL(b.Amount,0)) as Amount 
							From SD_Inv_PurInAdjustMaster a Inner Join SD_Inv_PurInAdjustDetail b On a.CompanyID = b.CompanyID And a.BillNo = b.BillNo
							Where a.CompanyID = '''+@CompanyID+''' And a.BillStatus = ''4''
							Group By Cast(DATEPART(YEAR,a.setCheckDate) as Varchar(20))+
							Cast((Case  When Datepart(month,a.setCheckDate)<=9 then ''0''
							+Convert(Varchar(2),Datepart(month,a.setCheckDate)) else  Convert(Varchar(2),Datepart(month,a.setCheckDate))
								End) as Varchar(20)),a.CompanyID,b.MaterialID,a.StockID
						) a 
					inner join #Period c on a.YM=c.YM 
					Left Outer Join #CostPrice b
					On (a.YM=b.YM and a.MaterialID=b.MaterialID)'
                   +' Where 1=1'
		If  ISNULL(@MatCnd,'')<>''     
            Set @ExcSql=@ExcSql+' and exists(Select top 1 * From #Material Where MaterialID=a.MaterialID) '
        Set @ExcSql=@ExcSql+'  and exists(Select top 1 * From #Stock Where StockID=a.StockID) '
        Set @ExcSql=@ExcSql+' Group By a.YM,a.StockID,a.MaterialID'
		Exec (@ExcSql)
	   --��ʼ����ʱ��
	   Insert Into #Jxc(YM,StockID,MaterialID)   
	   Select  YM,StockID,MaterialID  
	   From #tmp  
	   Group By YM,StockID,MaterialID 
	   --�������
	   --�ڳ���;---�޸���;����
	   Update  #Jxc  Set BegPathQty=b.Qty,BegPathAmount=Isnull(b.Amount,0)
	   From #Jxc a,(Select YM,StockID,MaterialID,Qty,Amount From #tmp2  where Code=1) b
	   Where a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID
	   insert into #Jxc(YM,StockID,MaterialID,BegPathQty,BegPathAmount)
	   select a.YM,a.StockID,a.MaterialID,a.Qty,a.Amount
	   from #tmp2 a left join #Jxc b on a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID 
	   where Code=1 and b.MaterialID is null
	   --�ڳ��ڲ�
	   Update  #Jxc  Set BeginQty=b.Qty,BeginAmount=Isnull(b.Amount,0)
	   From #Jxc a,(Select YM,StockID,MaterialID,Qty,Amount From #tmp  where Code=1) b
	   Where a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID
	   --�ɹ�
	   Update  #Jxc  Set PurQty=b.Qty,PurAmount=Isnull(b.Amount ,0 )
	   From #Jxc a,(Select YM,StockID,MaterialID,Qty,Amount From #tmp  where Code=2) b
	   Where a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID
	   --�˻�
	   Update  #Jxc  Set RejQty=b.Qty,RejAmount=Isnull(b.Amount  ,0)
	   From #Jxc a,(Select YM,StockID,MaterialID,Qty,Amount From #tmp  where Code=3) b
	   Where a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID
	   --�ɹ��˻��ɱ�����
	   Update  #Jxc  Set PurRejDiffAmount=Isnull(b.PurRejDiffAmount,0)
	   From #Jxc a,(Select YM,StockID,MaterialID,PurRejDiffAmount From #tmp  where Code=3) b
	   Where a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID
		Update  #Jxc  Set DiffAmount=EndInQty * (ISNULL(b.FactFOB,0)+ 0) - EndInQty * ISNULL(b.CalcFOB,0)
		From #Jxc a,#CostPrice b  
		Where A.YM=B.YM AND a.MaterialID=b.MaterialID  
	   --��������
	   Update  #Jxc  Set RtlQty=b.Qty,RtlAmount=Isnull(b.Amount ,0)
	   From #Jxc a,(Select YM,StockID,MaterialID,Qty,Amount From #tmp  where Code=4) b
	   Where a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID
	   --��������
	   Update  #Jxc  Set WhlQty=b.Qty,WhlAmount=Isnull(b.Amount ,0)
	   From #Jxc a,(Select YM,StockID,MaterialID,Qty,Amount From #tmp  where Code=5) b
	   Where a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID
	   --���������˻�
	   Update  #Jxc  Set WhlRejQty=b.Qty,WhlRejAmount=Isnull(b.Amount ,0)
	   From #Jxc a,(Select YM,StockID,MaterialID,Qty,Amount From #tmp  where Code=6) b
	   Where a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID
	   --��ӯ
	   Update  #Jxc  Set ChkInQty=b.Qty,ChkInAmount=Isnull(b.Amount,0)  
	   From #Jxc a,(Select YM,StockID,MaterialID,Qty,Amount From #tmp  where Code=7) b
	   Where a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID
	   --�̿�
	   Update  #Jxc  Set ChkOutQty=b.Qty,ChkOutAmount=Isnull(b.Amount ,0)
	   From #Jxc a,(Select YM,StockID,MaterialID,Qty,Amount From #tmp  where Code=8) b
	   Where a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID
	   --�������
	   Update  #Jxc  Set OthInQty=b.Qty,OthInAmount=Isnull(b.Amount,0)
	   From #Jxc a,(Select YM,StockID,MaterialID,Qty,Amount From #tmp  where Code=9) b
	   Where a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID
	   --��������
	   Update  #Jxc  Set OthOutQty=b.Qty,OthOutAmount=Isnull(b.Amount,0)
	   From #Jxc a,(Select YM,StockID,MaterialID,Qty,Amount From #tmp  where Code=10) b
	   Where a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID
	   --�������
	   Update  #Jxc  Set LossQty=b.Qty,LossAmount=Isnull(b.Amount ,0)
	   From #Jxc a,(Select YM,StockID,MaterialID,Qty,Amount From #tmp  where Code=11) b
	   Where a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID
	   --��������
	   Update  #Jxc  Set PrsQty=b.Qty,PrsAmount=Isnull(b.Amount,0)
	   From #Jxc a,(Select YM,StockID,MaterialID,Qty,Amount From #tmp  where Code=12) b
	   Where a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID
	   --�����չ����
	   Update  #Jxc  Set ShopBuyQty=b.Qty,ShopBuyAmount=Isnull(b.Amount,0)
	   From #Jxc a,(Select YM,StockID,MaterialID,Qty,Amount From #tmp  where Code=30) b
	   Where a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID
	   --����  
	   Update  #Jxc  Set MinQty=b.Qty,MinAmount=Isnull(b.Amount ,0)  
	   From #Jxc a,(Select YM,StockID,MaterialID,Qty,Amount From #tmp  where Code=19) b  
	   Where a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID
	   --����  
	   Update  #Jxc  Set MOutQty=b.Qty,MOutAmount=Isnull(b.Amount  ,0)  
	   From #Jxc a,(Select YM,StockID,MaterialID,Qty,Amount From #tmp  where Code=20) b  
	   Where a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID
	   --�ֶ���������
	   Update  #Jxc  Set ManuDiffAmount=Isnull(b.Amount,0)
	   From #Jxc a,(Select YM,StockID,MaterialID,Qty,Amount From #tmp  where Code=21) b
	   Where a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID
	   --��ĩ��; = �ڳ���; + ������; - ǰ���{�����¶Է�����
	   Update  #Jxc  
	   Set EndPathQty=Isnull(b.Qty,0),EndPathAmount=Isnull(b.Amount,0)
	   From #Jxc a,(Select YM,StockID,MaterialID,Qty,Amount From #tmp2  where Code=2) b
	   Where a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID
	   insert into #Jxc(YM,StockID,MaterialID,EndPathQty,EndPathAmount)
	   select a.YM,a.StockID,a.MaterialID,a.Qty,a.Amount
	   from #tmp2 a left join #Jxc b on a.YM=b.YM and a.StockID=b.StockID and a.MaterialID=b.MaterialID 
	   where Code=2 and b.MaterialID is null
	   --��ĩ�ڲ� = �ڳ��ڲ� + �ɹ� -���� - �������� - �������� + ���������˻� + ��ӯ - �̿� 
	   --+ ������ - ������ - ���� - ���� + ���� - ���� + �չ��������
	   Update #Jxc 
	   Set EndInQty=BeginQty+PurQty-RejQty-RtlQty-WhlQty+WhlRejQty+chkinQty-chkOutQty
				   +OthInQty-othOutQty-LossQty-PrsQty +MinQty-MOutQty+ ShopBuyQty
	   if @IsPurReject = '1'  --��ĩ�ڲֽ��:���㹫ʽ�Ƿ����'�ɹ��˻��ɱ�����' (��ʤ���� BY641)
	   begin
		   Update #Jxc
		   Set EndInAmount= BeginAmount+PurAmount-RejAmount+DiffAmount+ManuDiffAmount-RtlAmount-WhlAmount+WhlRejAmount
		   +chkinAmount-chkOutAmount+OthInAmount-othOutAmount-LossAmount-PrsAmount +MinAmount-MOutAmount + ShopBuyAmount
		   -PurRejDiffAmount
	   end
	   else --�����ͻ�
	   begin
		   Update #Jxc
		   Set EndInAmount= BeginAmount+PurAmount-RejAmount+DiffAmount+ManuDiffAmount-RtlAmount-WhlAmount+WhlRejAmount
		   +chkinAmount-chkOutAmount+OthInAmount-othOutAmount-LossAmount-PrsAmount +MinAmount-MOutAmount + ShopBuyAmount 
	   end
	   Update #Jxc Set 
	   TotalInQty=PurQty+WhlRejQty+chkinQty+OthInQty+MinQty+ShopBuyQty,
	   TotalInAmount=PurAmount+WhlRejAmount+chkinAmount+OthInAmount+MinAmount+ShopBuyAmount,    
	   TotalOutQty=RejQty+RtlQty+WhlQty+chkOutQty+othOutQty+LossQty+PrsQty+MOutQty,
	   TotalOutAmount=RejAmount+RtlAmount+WhlAmount+chkOutAmount+othOutAmount+LossAmount+PrsAmount+MOutAmount
	   --�ϼ�����
	   Update #Jxc Set EndQty = EndPathQty + EndInQty
	   --��ĩʵ�ʽ��
	   Update #Jxc Set EndAmount=BegPathAmount + BeginAmount+PurAmount-RejAmount+ManuDiffAmount-RtlAmount-WhlAmount+WhlRejAmount+ChkInAmount-ChkOutAmount
	   --��ĩ�ڲֳɱ����
       Set @ExcSql=' Update #Jxc Set EndInCostAmount=Round(a.EndInQty*(Isnull(b.FactFOB,0)+'+ @MaterialFactStr+','+@PreStr+') '
       +' From #Jxc a,#CostPrice b'
       +' Where a.YM=b.YM and a.MaterialID=b.MaterialID' 
	   Exec (@ExcSql)
	   If @Flag='0'
		   Set @ExcSql=' Update #Jxc Set CloseAmount=Round((a.EndInQty+a.EndPathQty)*(Isnull(b.FactFOB,0)+'+ @MaterialFactStr+','+@PreStr+') '
        		+' From #Jxc a,#CostPrice b'
        		+' Where a.YM=b.YM and a.MaterialID=b.MaterialID'
       else
		   Set @ExcSql=' Update #Jxc Set CloseAmount=Round((a.EndInQty+a.EndPathQty)*(Isnull(b.TaxFOB,0)+'+ @MaterialFactStr+','+@PreStr+') '
          		+' From #Jxc a,#CostPrice b'
        		+' Where a.YM=b.YM and a.MaterialID=b.MaterialID'
       Exec (@ExcSql)
	   --���β�� 
	   /* ԭ��ʽ  =�ɱ��ϼ�-��ĩ���ϼ� CloseAmount -EndAmount
	   ��ʤ���� BY641 ���β��=��ĩ�������*���³ɱ�����(����ĩ�ڲֳɱ����)-��ĩ�ڲֽ��
	   */
	   --if @MaterialFlag=1 --�Ƿ���������ɱ�
	   --begin
		  -- Update a Set a.EndDiffAmount=(a.EndInQty*(ISNULL(b.FactFOB,0)+ISNULL(b.MaterialFactFOB,0)))-a.EndInAmount
		  -- from  #Jxc a
		  -- Left Outer join #CostPrice b On (a.MaterialID=b.MaterialID) And b.YM = a.YM
	   --end
	   --else
	   --begin
		  -- Update a Set a.EndDiffAmount=(a.EndInQty*ISNULL(b.FactFOB,0))-a.EndInAmount
		  -- from  #Jxc a
		  -- Left Outer join #CostPrice b On (a.MaterialID=b.MaterialID) And b.YM = a.YM
	   --end
	   UPDATE #Jxc SET EndDiffAmount=CloseAmount -EndAmount
	   if (@SearchType = '1')
	   begin
			Select  a.StockID,a.MaterialID,b.MaterialCode,b.MaterialShortName,a.EndDiffAmount
			From #Jxc a
			Left join SD_Mat_Material b ON a.MaterialID = b.MaterialID
			Where a.EndDiffAmount <> 0 	     
			return 
	   end
	   Else if (@SearchType = '2')
	   begin
	        Insert into FICA_Pur_AdjustDiffAmount(GuidID, StockID, MaterialID, DiffAmount)
			Select  @GuidID,a.StockID,a.MaterialID,a.EndDiffAmount
			From #Jxc a
			Where a.EndDiffAmount <> 0 	     
			return 	     
	   end 
	   If @Flag='0'
	   begin	
		   Select  a.YM,dd.OperationAreaName,c.StockName,d.CardName,d.KindName,a.MaterialID,d.MaterialCode,d.RetailPrice,ISNULL(b.FactFOB,0.000000) as FactFOB,d.yearno,d.SeasonName,d.modelName,d.SeriesName,
			a.BegPathQty,a.BegPathAmount,a.BeginQty,a.BeginAmount,a.PurQty,a.PurAmount,a.RejQty,a.RejAmount,a.DiffAmount,a.PurRejDiffAmount,a.ManuDiffAmount,
			a.RtlQty,a.RtlAmount,a.WhlQty,a.WhlAmount,a.WhlRejQty,a.WhlRejAmount,a.ChkInQty,a.ChkInAmount,a.chkOutQty,a.ChkOutAmount,
			a.OthInQty,a.OthInAmount,a.OthOutQty,a.OthOutAmount,a.LossQty,a.LossAmount,a.PrsQty,a.PrsAmount,a.ShopBuyQty,a.ShopBuyAmount,
			a.TotalInQty,a.TotalInAmount,a.TotalOutQty,a.TotalOutAmount,
			a.MOutQty,a.MOutAmount,a.MinQty,a.MinAmount,a.MLossQty,a.MLossAmount,
			a.MoveCurOutQty,a.MoveCurOutAmount,a.MoveCurOutInQty,a.MoveCurOutInAmount,a.MoveHisOutOtherCurInQty,a.MoveHisOutOtherCurInAmount,
			a.MoveAdjustSSQty,a.MoveAdjustSSAmount,a.MoveCurInOtherHisOutQty,a.MoveCurInOtherHisOutAmount,a.MoveCurInOutQty,a.MoveCurInOutAmount,
			a.EndPathQty,a.EndPathAmount,a.EndInQty,a.EndInAmount,a.EndInCostAmount,a.EndQty,a.EndAmount,a.EndDiffAmount,a.CloseAmount,d.SaleDate,
			d.StyleCode,d.StuffName,Style.SubTypeName,Ma.AccreditName,Mcc.CommodityLevelName,Style.DesignNo,Style.CollarTypeName,
			Style.Thicknessname,Style.SleeveTypeName,Style.SleeveLenName,Style.ClothesLenName,Style.ElementName
			,Style.OrderAttribName,Style.CommodityProfileName,Style.DesiGnername,Style.ClothesVersionName,d.ItemName,D.MaterialShortName,d.MaterialProperty
			,CASE WHEN IsEntrustedSale=0 THEN '��' ELSE '��' END IsEntrustedSale,d.MatTypeName,xx.VendCustName
		    From #Jxc a Left Outer join #CostPrice b 
			On (a.MaterialID=b.MaterialID) And b.YM = a.YM Left Outer join vwSD_StockByArea c 
			On (a.StockID=c.StockID) And c.CompanyID = @CompanyID
			Left Outer join  vwSD_Material d On (a.MaterialID=d.MaterialID) ANd d.CompanyID = @CompanyID
			left join SD_Mat_Accredit ma on d.accreditID = ma.accreditID
			left join SD_Mat_CommodityLevel Mcc on d.commoditylevelID = mcc.commoditylevelID
			left join vwPM_Bas_Style Style on d.styleID = Style.StyleID
		    inner join Bas_Stock st on a.StockID=st.StockID 
		    left join Bas_OperationArea dd on st.OperationAreaID=dd.OperationAreaID	
			LEFT JOIN Bas_InterCompany xx ON xx.CompanyID=d.CompanyID AND xx.VendCustID=d.VendCustID	 
		    Where  a.StockID=c.StockID and a.MaterialID=d.MaterialID
		    Order By a.YM,c.StockName,d.CardName,d.KindName,a.MaterialID,d.MaterialCode,d.RetailPrice,b.FactFOB,d.yearno,d.SeasonName,d.modelName,d.SeriesName
	  end
	  else
		   Select  a.YM,dd.OperationAreaName,c.StockName,d.CardName,d.KindName,a.MaterialID,d.MaterialCode,d.RetailPrice,
		   ISNULL(b.TaxFOB,0.000000) as FactFOB,d.yearno,d.SeasonName,d.modelName,d.SeriesName,
			a.BegPathQty,a.BegPathAmount,a.BeginQty,a.BeginAmount,a.PurQty,a.PurAmount,a.RejQty,a.RejAmount,a.DiffAmount,a.PurRejDiffAmount,a.ManuDiffAmount,
			a.RtlQty,a.RtlAmount,a.WhlQty,a.WhlAmount,a.WhlRejQty,a.WhlRejAmount,a.ChkInQty,a.ChkInAmount,a.chkOutQty,a.ChkOutAmount,
			a.OthInQty,a.OthInAmount,a.OthOutQty,a.OthOutAmount,a.LossQty,a.LossAmount,a.PrsQty,a.PrsAmount,a.ShopBuyQty,a.ShopBuyAmount,
			a.TotalInQty,a.TotalInAmount,a.TotalOutQty,a.TotalOutAmount,
			a.MOutQty,a.MOutAmount,a.MinQty,a.MinAmount,a.MLossQty,a.MLossAmount,
			a.MoveCurOutQty,a.MoveCurOutAmount,a.MoveCurOutInQty,a.MoveCurOutInAmount,a.MoveHisOutOtherCurInQty,a.MoveHisOutOtherCurInAmount,
			a.MoveAdjustSSQty,a.MoveAdjustSSAmount,a.MoveCurInOtherHisOutQty,a.MoveCurInOtherHisOutAmount,a.MoveCurInOutQty,a.MoveCurInOutAmount,
			a.EndPathQty,a.EndPathAmount,a.EndInQty,a.EndInAmount,a.EndInCostAmount,a.EndQty,a.EndAmount,a.EndDiffAmount,a.CloseAmount ,d.SaleDate,
			d.StyleCode,d.StuffName,Style.SubTypeName,Ma.AccreditName,Mcc.CommodityLevelName,Style.DesignNo,Style.CollarTypeName,
			Style.Thicknessname,Style.SleeveTypeName,Style.SleeveLenName,Style.ClothesLenName,Style.ElementName
			,Style.OrderAttribName,Style.CommodityProfileName,Style.DesiGnername,Style.ClothesVersionName,d.ItemName,D.MaterialShortName,d.MaterialProperty
			,CASE WHEN IsEntrustedSale=0 THEN '��' ELSE '��' END IsEntrustedSale,d.MatTypeName,xx.VendCustName
		   From #Jxc a Left Outer join  #CostPrice b 
		   On (a.MaterialID=b.MaterialID) And b.YM = a.YM
		   Left Outer join vwSD_StockByArea c 
		   On (a.StockID=c.StockID) And c.CompanyID = @CompanyID
		   Left Outer join  vwSD_Material d
		   On (a.MaterialID=d.MaterialID) And d.CompanyID = @CompanyID
		   left join SD_Mat_Accredit ma on d.accreditID = ma.accreditID
		   left join SD_Mat_CommodityLevel Mcc on d.commoditylevelID = mcc.commoditylevelID
		   left join vwPM_Bas_Style Style on d.styleID = Style.StyleID
		   inner join Bas_Stock st on a.StockID=st.StockID 
		   left join Bas_OperationArea dd on st.OperationAreaID=dd.OperationAreaID	
		   LEFT JOIN Bas_InterCompany xx ON xx.CompanyID=d.CompanyID AND xx.VendCustID=d.VendCustID	 
		   where  a.StockID=c.StockID and a.MaterialID=d.MaterialID
		   Order By a.YM,c.StockName,d.CardName,d.KindName,a.MaterialID,d.RetailPrice,b.TaxFOB,d.yearno,d.SeasonName,d.modelName,d.SeriesName
	   Drop table #tmp
	   Drop table #tmp2                             
	   Drop table #Jxc 
	   Drop table #Period    
	   Drop table #Material
	   Drop table #Stock
	   Set NoCount Off
	   Return
end