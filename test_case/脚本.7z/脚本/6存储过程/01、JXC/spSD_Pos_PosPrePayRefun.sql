
IF Exists(select 1 from sys.procedures WHERE name='spSD_Pos_PosPrePayRefun')
BEGIN 
	DROP PROCEDURE spSD_Pos_PosPrePayRefun
END 

GO



CREATE PROC [dbo].[spSD_Pos_PosPrePayRefun]
(
   @CompanyID T_ID,       --��˾ID
   @BillNo VARCHAR(40),   --��Ҫ�˿�POS���𵥵�
   @Sql NVARCHAR(max)     --������ϸ��ʱ��SQL
)
AS
--POS���𵥵���
DECLARE @PosPreNo T_BillNo_L
--ӪҵԱCode
DECLARE @UserCode VARCHAR(50)
BEGIN
    BEGIN TRANSACTION   
	BEGIN 
	   BEGIN Try
		--����POS֧����ϸ��ʱ��
		SELECT * INTO #TmpReceiptDetail FROM SD_Pos_SaleReceiptDetail WHERE 1=2
		EXEC(@Sql)
		IF NOT EXISTS(SELECT TOP 1 1 FROM #TmpReceiptDetail)
		BEGIN
				SELECT '-1' AS RtnVal,'��ʱ����#ReceiptDetail�����������쳣' AS Cause
				ROLLBACK TRANSACTION
				RETURN
		END	
		-- ������POS���𵥵���
		SELECT @UserCode = PersonnelCode FROM dbo.Bas_Personnel WHERE PersonnelID = (SELECT TOP 1 PersonnelID FROM SD_POS_PrePayMaster WHERE CompanyID = @CompanyID AND BillNo = @BillNo)		
		Exec spSys_GetMaxBillNo @CompanyID,'SD_POS_PrePayMaster','BillNo','PPOS',@UserCode,@PosPreNo OUTPUT	
		/**===============================����POS��������================================**/
		INSERT INTO SD_POS_PrePayMaster
		(
			CompanyID,BillNo,ShopID,StockID,BillDate,BillTime,VipID,VipCard,CustomerName,MobileTel,OrderType,
			JointVIPID,CashierID,PersonnelID,PayAmount,PrePayAmount,CashAmount,BankCardAmount,ChangeAmount,VIPIntegral,SmallTicketNo,
			SourceBillNo,BillStatus,POSStatus,POSBillNo,Checker,PrintDegree,Remark,RoundStyle,RoundDigitNum,InterDigitNum,CounterID,ModifyDTM
		)
		SELECT @CompanyID AS CompanyID,
			   @PosPreNo AS BillNo,
			   ShopID,
			   StockID,
			   GETDATE() AS BillDate,
			   GETDATE() AS BillTime,
			   VipID,
			   VipCard,
			   CustomerName, 
			   MobileTel,      
			   1,
			   JointVIPID,
			   CashierID,
			   PersonnelID,
			   PayAmount,
			   PrePayAmount, 
			   CashAmount,
			   BankCardAmount,
			   ChangeAmount,
			   VIPIntegral,
			   SmallTicketNo,
			   BillNo,
			   4,
			   2,
			   POSBillNo,
			   '' AS Checker,
			   PrintDegree,
			   '��POS��:'+BillNo+' �˿���������POS����' AS Remark,
			   RoundStyle,
			   RoundDigitNum,
			   InterDigitNum,
			   CounterID,
			   GETDATE() AS ModifyDTM
		FROM SD_POS_PrePayMaster WHERE CompanyID = @CompanyID AND BillNo = @BillNo
		/**===============================����POS�����ӱ�================================**/
		INSERT INTO SD_POS_PrePayDetail
		(
		   CompanyID,BillNo,Sequence,ShopID,StockID,PersonnelID,MaterialID,
		   MaterialCode,MaterialShortName,SizeID,BarCode,SaleType,Price,BalaPrice,
		   CostPrice,Discount,VIPDiscount,Qty,PayAmount,PromotionID,IsVIPIntegral,VIPIntegralRatio,
		   VIPIntegral,PresendSeq,VIPPrice,JointVIPDiscount,THQDiscount,NPBillNo,NPPrice,NPVIPRule,NPVIPDiscount,
		   Remark,PromotionID2,PromotionID3,IntegralRateType,TaxRate
		)
		SELECT  @CompanyID AS CompanyID,
		        @PosPreNo AS BillNo,
				Sequence,
				ShopID,
				StockID,
				PersonnelID,
				MaterialID,
				MaterialCode,
				MaterialShortName,
				SizeID,
				BarCode,
				SaleType,
				Price,
				BalaPrice,
				CostPrice,
				Discount,
				VIPDiscount,
				Qty,
				PayAmount,
				PromotionID,
				IsVIPIntegral,
				VIPIntegralRatio,
				VIPIntegral,
				PresendSeq,
				VIPPrice,
				JointVIPDiscount,
				THQDiscount,
				NPBillNo,
				NPPrice,
				NPVIPRule,
				NPVIPDiscount,
				'��POS����'+BillNo +' �˿�����POS����',
				PromotionID2,
				PromotionID3,
				IntegralRateType,
				TaxRate
		FROM SD_POS_PrePayDetail WHERE CompanyID= @CompanyID AND BillNo = @BillNo				
		/**===============================����POS��������Ϣ��================================**/
		INSERT INTO SD_POS_PrePayReceiptDetail
		(
		   CompanyID,
		   BillNo,
		   Sequence,
		   ReceiptTypeID,
		   Amount,
		   BalanceNumber,
		   Remark,
		   DischargeIntegral,
		   IsCalcVIPIntegral,
		   IsJoinPayAmountCalc,
		   out_trade_no,
		   transaction_id,
		   out_refund_no,
		   refund_id
		)
		SELECT @CompanyID AS CompanyID,
		       @PosPreNo AS BillNo,
			   Sequence,
			   ReceiptTypeID,
			   -Amount,        --���为
			   BalanceNumber,
			   '��POS����'+BillNo +' �˿�����POS����',
			   DischargeIntegral,
			   IsCalcVIPIntegral,
			   IsJoinPayAmountCalc,
			   out_trade_no,
			   transaction_id,
			   out_refund_no,
			   refund_id
		FROM #TmpReceiptDetail
		/**===============================��дPOS���Ľ���״̬================================**/
		update SD_POS_PrePayMaster set POSStatus = '3',ModifyDTM = getdate(),Remark+='�˿����ɵ�POS����:'+@PosPreNo where CompanyID = @CompanyID and BillNo = @BillNo
		IF exists (select * from tempdb.dbo.sysobjects where id = object_id(N'tempdb..#TmpReceiptDetail') and type='U')
				DROP TABLE #TmpReceiptDetail
		IF(@@ERROR<>0)
		BEGIN 
		    SELECT '-1' AS RtnVal,'�ύ�����쳣' AS Cause
		    ROLLBACK TRANSACTION
		END
		ELSE
        BEGIN
			SELECT '0' AS RtnVal,'�ɹ�' AS Cause
			COMMIT TRANSACTION	
        END 
		END TRY		
		BEGIN CATCH
		    SELECT '-2' AS RtnVal,'�ύ�����쳣' AS Cause
		    ROLLBACK TRANSACTION
		END CATCH
	END 
END 
GO 