-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[spBC_SalProCheckShopIsJoinProgramme]
	 @companyid VARCHAR(40),--��˾ID
	 @shopids VARCHAR(max),--����ID
	 @materials VARCHAR(max),--����ID
	 @startdate DATETIME,--��ʼʱ��
	 @enddate DATETIME,--����ʱ��
	 @currentBillNoID VARCHAR(40)--������
	 AS
BEGIN

	SELECT  colid,CONVERT(VARCHAR(40), colname) AS ShopID INTO #shops FROM [dbo].[fnSplitStr](@shopids,',')--��ȡ����
	SELECT  colid,CONVERT(VARCHAR(40), colname) AS MaterialID INTO #materials FROM [dbo].[fnSplitStr](@materials,',')--��ȡ����
	SELECT distinct p.BillNo,p.SalProgramCode, p.StartDate,p.EndDate,
	p.StartDate AS BeginDateVar,
	p.EndDate AS EndDateVar,
	s.ShopID,a.MaterialID
	INTO #x1
	FROM [dbo].[BC_SalProgramme] p 
	INNER JOIN [dbo].[BC_SalProgrammeShop] s 
	ON p.CompanyID = s.CompanyID
	AND p.BillNo = s.BillNo
	inner join BC_SalProgrammeGoodsNumber a
	on p.CompanyID = a.CompanyID
	AND p.billno = a.billno
	WHERE p.CompanyID=@companyid  
	AND p.BillStatus IN (0,1,2,3,4,7,8)
	and s.ShopID IN (SELECT s.ShopID FROM #shops s)
	AND a.MaterialID IN (SELECT k.MaterialID FROM #materials k)
	AND (
	p.StartDate BETWEEN @startdate AND @enddate
	OR p.EndDate BETWEEN @startdate AND @enddate
	OR @startdate BETWEEN p.StartDate AND p.EndDate
	OR @enddate BETWEEN p.StartDate AND p.EndDate
	)
	AND p.BillNo NOT IN (@currentBillNoID)
	
	DECLARE @BeginDateVar DATETIME,@EndDateVar DATETIME
    set @BeginDateVar = @startdate
	set @EndDateVar = @enddate
	--��ʾ�õ��̴��ڳ�ͻ�ķ�����
	SELECT DISTINCT 
	--x.BillNo,x.SalProgramCode,--(���ڴ����ظ������ݣ����Բ���ѯ���ݺ�)
	x.BeginDateVar,x.EndDateVar,x.ShopID,s.ShopName,x.MaterialID FROM #x1 x 
	LEFT JOIN dbo.Bas_Shop s ON x.ShopID = s.ShopID AND s.Lan=0
	WHERE 
	x.BeginDateVar BETWEEN @BeginDateVar AND @EndDateVar
	OR 
	x.EndDateVar BETWEEN @BeginDateVar AND @EndDateVar
	OR @BeginDateVar BETWEEN x.BeginDateVar AND x.EndDateVar
	OR @EndDateVar BETWEEN x.BeginDateVar AND x.EndDateVar


DROP TABLE #x1
DROP TABLE #shops
DROP TABLE #materials
END