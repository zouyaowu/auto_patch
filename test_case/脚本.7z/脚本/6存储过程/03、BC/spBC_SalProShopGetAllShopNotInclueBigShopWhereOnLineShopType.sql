-- ============================================= 
-- Author:		������	 
-- Create date: 2017-10-26
-- Description:	���̴������۷�������ȡ��������Ϊ���꣬��������Ϊ��������صĵ��̡� 
-- ============================================= 
CREATE PROCEDURE [dbo].[spBC_SalProShopGetAllShopNotInclueBigShopWhereOnLineShopType] 
	@companyid VARCHAR(40)= 'hk' , 
    @modulecode VARCHAR(100)= 'BC_SalProgramme' , 
    @UserID VARCHAR(100)= 'HK00000002' 
AS 
BEGIN 
        SELECT a.CompanyID , 
                    a.ShopID , 
                    a.ShopCode , 
                    a.ShopName , 
                    a.OperationAreaID , 
                    a.StockID , 
					a.OnlineType, 
					s.CNStateName AS OnlineTypeName, 
                    s.AllowUsed , 
                    ( SELECT    m.CardName + ',' 
                      FROM      SD_Bas_ShopCard s 
                                INNER JOIN SD_Mat_Card m ON s.CardID = m.CardID 
                      WHERE     ShopID = A.ShopID 
                    FOR 
                      XML PATH('') 
                    ) AS CardList 
          FROM      Bas_Shop A 
		  inner JOIN Sys_State s ON s.StateFixFlag='OnlineType' AND s.StateId = a.OnlineType AND s.StateId=99
		  inner JOIN Sys_State ss ON ss.StateFixFlag='ShopType' AND ss.StateId = a.ShopType AND ss.StateId=1
          WHERE     a.CompanyID = @companyid AND a.Lan=0 AND a.ShopType=1 AND a.AllowUsed=1 
   AND a.IsSDShop = 1  

END 