IF EXISTS ( SELECT  1
            FROM    sys.procedures
            WHERE   name = 'spBC_InsertIntoBC_Sal_OrderDownd' )
    BEGIN 
        DROP PROCEDURE spBC_InsertIntoBC_Sal_OrderDownd;
    END; 
GO

-- =============================================
-- Author:		����ΰ
-- Create date: <Create Date,,>
-- Description:	������ȫ��·�������ر��������
-- =============================================
CREATE PROCEDURE [dbo].[spBC_InsertIntoBC_Sal_OrderDownd]
	 
AS
BEGIN 
Insert Into BC_Sal_OrderDownd (CompanyID,
ShopBillNo,
ShopID,
TranState,
PaymentDate,
BillDate,
ModifyDTM
)
SELECT s.CompanyID,
s.ShopBillNo,
s.ShopID,
s.TranState,
s.PaymentDate,
s.BillDate,
s.ModifyDTM FROM #BC_Sal_OrderDownd s LEFT JOIN BC_Sal_OrderDownd o 
ON s.CompanyID=o.CompanyID AND s.ShopBillNo=o.ShopBillNo 
WHERE o.CompanyID IS NULL;
DECLARE @inserSum int =@@ROWCOUNT

--UPDATE o
--SET o.TranState=s.TranState,o.ModifyDTM=s.ModifyDTM
--FROM #BC_Sal_OrderDownd s,
--	 BC_Sal_OrderDownd o 
--	 WHERE 
--	 s.CompanyID=o.CompanyID
--	  AND s.ShopBillNo=o.ShopBillNo
--	  AND s.TranState<>o.TranState;
--	  DECLARE @updateSum int =@@ROWCOUNT

	SELECT @inserSum AS	N'inserSum' --,@updateSum AS N'updateSum'
END
	
	

