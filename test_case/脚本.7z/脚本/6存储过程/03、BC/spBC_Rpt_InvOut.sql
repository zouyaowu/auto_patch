  if exists(select * from sysobjects where id = object_id(N'spBC_Rpt_InvOut') )
drop procedure spBC_Rpt_InvOut
GO
/****** Object:  StoredProcedure [dbo].[spBC_Rpt_InvOut]    Script Date: 2017/11/22 13:26:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		����Ӫ
-- Create date: <Create Date,,>
-- Description:	���̳������ܱ�
-- =============================================
Create PROCEDURE [dbo].[spBC_Rpt_InvOut]
	-- Add the parameters for the stored procedure here
    @CompanyID       varchar(20) ,
    @ModuleCode	     varchar(60)='' ,
    @UserID		     varchar(20)='' ,
    @FormLang        nVarchar(30) = '',--�ͻ���ѡ������	
    @PickUser        varchar(max)='' ,
    @BegDate         varchar(20)='1900-1-1' ,
    @EndDate         varchar(20)='2079-6-1' ,
	@Shoplist        varchar(max) = '' ,
    @Stocklist       varchar(max) = '' ,
    @PickStatus      varchar(max)='',--���״̬
    @MaterialCon     varchar(max) = ''   --��Ʒ����	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    Declare @Sql varchar(max)
	Create Table #Material(MaterialID varchar(20))    
	Create Table #ShopStr (ShopID Varchar(20))
	Create Table #StockStr (StockID Varchar(20))	
	Create Table #PersonnelStr (PersonnelID Varchar(20))	
	Create Table #PersonnelStr2 (PersonnelID Varchar(20))
	create table #PickStatusStr(PickStatus varchar(100))
	if IsNull(@BegDate,'') = ''
	begin
	  Set @BegDate = '1900-1-1'
	end
	else
	begin
	  Set @BegDate = Convert(varchar(10),Cast(@BegDate as Datetime),120)
	end
	if IsNull(@EndDate,'') = ''
	begin
	  Set @EndDate = '2079-6-1'
	end
	else
	begin
	  Set @EndDate = CONVERT(VARCHAR(20), CONVERT(VARCHAR(10),CONVERT(DATETIME,@EndDate,120),120)+' 23:59:59')--  CONVERT(VARCHAR(20),Convert(varchar(10),Cast(@EndDate as Datetime),120)+'23:59:59')
	end	
	--����
	if IsNull(@MaterialCon,'') <> ''
	begin
		Set @Sql = ' Insert Into  #Material(MaterialID ) '
				 + ' Select MaterialId From vwSD_Material Where CompanyId = '''+@CompanyId+''' '
				 + IsNull(@MaterialCon,'');
		Exec(@Sql);
	end
    if @Stocklist <> ''
    begin
		insert into #StockStr(StockID) Select * From dbo.fnSys_SplitString(@Stocklist,',')
    end
    else
    begin
        Set @Stocklist = NULL
        declare  @stocktemp table (StockID varchar(max))
		Insert Into @stocktemp(StockID)  
		Exec spSys_GetDataRight @CompanyID,@ModuleCode,@UserID,'Stock' 
		--��������ʧ�� 
	insert into #StockStr 
	select stockid from bas_stock s where 
		s.stockcode <>'OOSS' and
		s.stockid in( select stockid from @stocktemp)
    end 
    if @Shoplist <> ''
    begin
		insert into #ShopStr(ShopID) Select * From dbo.fnSys_SplitString(@Shoplist,',')
    end
    else
    begin
        Set @Shoplist = NULL
		Insert Into #ShopStr(ShopID)  
		Exec spSys_GetDataRight @CompanyID,@ModuleCode,@UserID,'Shop'
    end     
    if @PickUser <> ''
    begin
		insert into #PersonnelStr(PersonnelID) Select * From dbo.fnSys_SplitString(@PickUser,',')
    end
    else
    begin
		Insert Into #PersonnelStr2(PersonnelID)  
		Exec spSys_GetDataRight @CompanyID,@ModuleCode,@UserID,'Personnel'			
		Insert Into #PersonnelStr(PersonnelID)
		Select a.PersonnelID
		From #PersonnelStr2 a
		Inner Join Bas_Personnel b On a.PersonnelID = b.PersonnelID
		Where b.CompanyID = @CompanyID and b.IsPicker = 1		
    end     
	Drop Table 	#PersonnelStr2   
	if isnull(@PickStatus,'')<>''
	begin
	insert into #PickStatusStr select * from dbo.fnSys_SplitString(@PickStatus,',')
	end
	else
	begin
	insert into #PickStatusStr select * from dbo.fnSys_SplitString('0,1,2,7,12',',')
	END
	SELECT m.BillNo,m.companyid,m.PickDate,m.StockID, m.ExpressBillNo,m.Chooser,m.PickStatus  
	INTO #temp_SD_Inv_PickUpMaster
	FROM 
	SD_Inv_PickUpMaster m where m.CompanyID = @CompanyID 
		 and m.Chooser in (Select PersonnelID From #PersonnelStr)          
		 and (m.PickDate between @BegDate and @EndDate)
		 and m.PickStatus in(select PickStatus from #PickStatusStr)
		 SELECT om.companyid, om.BillNo,om.ZipCode,om.Province,om.City,om.Address,om.Area,om.ConsigneeName,om.ShopBillNo,om.ExpressCost,om.ShopID,om.VendCustID ,om.StockID   ,om.ExpressAmount
		  INTO #temp_BC_Sal_OrderMaster
		 FROM BC_Sal_OrderMaster om
		 WHERE om.CompanyID = @CompanyID  and om.BillTypeID = 'BC_NetSalOrder'and (
		 om.ShopID in (Select ShopID From #ShopStr))      
		 and (om.StockID in (Select StockID From #StockStr))      	
CREATE TABLE #result(
	[seq] [BIGINT] NULL,
	[BillNo] [VARCHAR](40) NOT NULL,
	[MaterialID] [VARCHAR](40) NULL,
	[MaterialCode] [VARCHAR](40) NULL,
	[MaterialShortName] [VARCHAR](40) NULL,
	[ShopID] [VARCHAR](20) NULL,
	[ShopName] [VARCHAR](60) NULL,
	[ShopCode] [NVARCHAR](20) NULL,
	[PickDate] [DATETIME] NULL,
	[BCBillNo] [VARCHAR](40) NOT NULL,
	[ZipCode] [VARCHAR](30) NULL,
	[Province] [NVARCHAR](60) NULL,
	[City] [NVARCHAR](60) NULL,
	[Address] [NVARCHAR](250) NULL,
	[Area] [NVARCHAR](60) NULL,
	[ConsigneeName] [NVARCHAR](60) NULL,
	[OutBillNo] [VARCHAR](40) NULL,
	[Sequence] [VARCHAR](5) NOT NULL,
	[PickStatus] [NVARCHAR](100) NULL,
	[ShopBillNo] [VARCHAR](40) NULL,
	[SubOrderNo] [VARCHAR](40) NULL,
	[ColorID] [VARCHAR](40) NULL,
	[ColorCode] [VARCHAR](20) NULL,
	[ColorName] [VARCHAR](40) NULL,
	[ExpressName] [VARCHAR](60) NULL,
	[ExpressCost] [NUMERIC](24, 6) NULL,
	[ExpressBillNo] [NVARCHAR](40) NULL,
	[OnlineType] [INT] NULL,
	[Chooser] [NVARCHAR](20) NULL,
	[PersonnelName] [NVARCHAR](40) NULL,
	[SizeID] [VARCHAR](40) NOT NULL,
	[BillQty] [INT] NULL,
	[PickQty] [INT] NULL,
	[SizeName] [VARCHAR](40) NULL,
	[PayAmount] [NUMERIC](24, 6) NULL,
	[ExpressAmount] [NUMERIC](24, 6) NULL,
	[StockID] [VARCHAR](20) NOT NULL,
	[StockName] [VARCHAR](80) NULL,
	[Barcode] [VARCHAR](40) NULL,
	[CardName] [VARCHAR](40) NULL,
	[KindName] [VARCHAR](40) NULL,
	[omBillNo] [VARCHAR](40) NULL,
	pssequence [VARCHAR](5)  NULL,
	pssizeid  VARCHAR(20)
) ON [PRIMARY]
	if IsNull(@MaterialCon,'') <> ''
	begin		 
	INSERT  INTO #result(seq,BillNo,MaterialID,MaterialCode,MaterialShortName,ShopID,ShopName,ShopCode,PickDate,
		 BCBillNo ,ZipCode,Province,City,Address,Area,ConsigneeName,OutBillNo
		 ,Sequence,PickStatus ,ShopBillNo,SubOrderNo,ColorID,ColorCode,ColorName,
		  ExpressName,ExpressCost, ExpressBillNo,OnlineType,Chooser,PersonnelName,SizeID,BillQty, PickQty,SizeName,PayAmount,ExpressAmount
		 ,StockID,StockName,Barcode,CardName,KindName,omBillNo,pssequence,pssizeid)
		select ROW_NUMBER()OVER(ORDER BY m.BillNo) seq,
		m.BillNo,pd.MaterialID,pd.MaterialCode,pd.MaterialShortName,s.ShopID,s.ShopName,s.ShopCode,m.PickDate,
		 om.BillNo as BCBillNo ,om.ZipCode,om.Province,om.City,om.Address,om.Area,om.ConsigneeName,od.OutBillNo
		 ,pd.Sequence,ss.CNStateName as PickStatus,CASE  ISNULL(od.ShopBillNo,'') WHEN '' THEN om.ShopBillNo ELSE od.ShopBillNo END  AS ShopBillNo,od.SubOrderNo,od.ColorID,sm.ColorCode,sm.ColorName,
		 ic.ShortName ExpressName,om.ExpressCost, m.ExpressBillNo,s.OnlineType,m.Chooser,p.PersonnelName,ps.SizeID,ps.BillQty,convert(int,isnull( ps.Qty,0)) as PickQty,sm.SizeName,od.PayAmount,om.ExpressAmount
		 ,m.StockID,sk.StockName,sm.Barcode,sm.CardName,sm.KindName,om.BillNo omBillNo,od.sequence pssequence, ps.sizeid pssizeid
		 from #temp_SD_Inv_PickUpMaster m 
		 inner join SD_Inv_PickUpDetail pd  
		 on m.CompanyID = pd.CompanyID and m.BillNo = pd.BillNo
		 inner join SD_Inv_PickUpSize ps on ps.CompanyID = pd.CompanyID and ps.BillNo = pd.BillNo and ps.Sequence = pd.Sequence
		 inner join #temp_BC_Sal_OrderMaster om
		 on om.CompanyID = m.CompanyID and om.BillNo = pd.SourceBillNo
		 inner join BC_Sal_OrderDetail od on od.CompanyID = om.CompanyID and od.BillNo= om.BillNo
		 and pd.SourceBillNo = od.BillNo and pd.SourceBillSequence= od.Sequence
		 Inner Join #Material q On od.MaterialID = q.MaterialID
		 left join Bas_Shop s
		 on s.CompanyID= om.CompanyID and s.ShopID = om.ShopID
		  left join Bas_InterCompany ic on ic.VendCustID= om.VendCustID 
		  Left Join Bas_Personnel p On m.CompanyID = p.CompanyID and m.Chooser = p.PersonnelID
		 left JOIN dbo.vwSD_MaterialSize sm ON ps.CompanyID = sm.CompanyID AND ps.MaterialID = sm.MaterialID and  ps.SizeID = sm.SizeID 
		  --left join SD_Mat_Color c on c.ColorID = od.ColorID
		  --Left Join SD_Mat_Size ms On ms.SizeID = ps.SizeID
		  --Left Join SD_Mat_MaterialSize  Bar On ps.SizeID = Bar.SizeID and pd.MaterialID = Bar.MaterialID
		  Left Join Bas_Stock sk On sk.CompanyID = om.CompanyID and sk.StockID = om.StockID   
		  left join Sys_State ss on ss.StateFixFlag='PickStatus' and ss.StateType =m.PickStatus 
		  --left join vwSD_Pos_SaleMaster posinfo on posinfo.CompanyID = om.CompanyID and  posinfo.BCSourceBillNo = om.BillNo and posinfo.CompanyID=@CompanyID
		  --outer apply(
				--  select top 1 pm.BillDate from vwSD_Pos_SaleMaster  pm  
				--  where pm.CompanyID = om.CompanyID and  pm.BCSourceBillNo = om.BillNo 
		  --) posinfo
		 --where om.CompanyID = @CompanyID 
		 --and om.BillTypeID = 'BC_NetSalOrder'	
		 --and m.Chooser in (Select PersonnelID From #PersonnelStr)      
		 --and (
		 --om.ShopID in (Select ShopID From #ShopStr))      
		 --and (om.StockID in (Select StockID From #StockStr))      
		 --and (m.PickDate between @BegDate and @EndDate)
		 --and m.PickStatus in(select PickStatus from #PickStatusStr)
	end
	else
	BEGIN
    	INSERT  INTO #result(seq,BillNo,MaterialID,MaterialCode,MaterialShortName,ShopID,ShopName,ShopCode,PickDate,
		 BCBillNo ,ZipCode,Province,City,Address,Area,ConsigneeName,OutBillNo
		 ,Sequence,PickStatus ,ShopBillNo,SubOrderNo,ColorID,ColorCode,ColorName,
		  ExpressName,ExpressCost, ExpressBillNo,OnlineType,Chooser,PersonnelName,SizeID,BillQty, PickQty,SizeName,PayAmount,ExpressAmount
		 ,StockID,StockName,Barcode,CardName,KindName,omBillNo,pssequence,pssizeid)
	       select ROW_NUMBER()OVER(ORDER BY m.BillNo) seq,
	      m.BillNo,pd.MaterialID,pd.MaterialCode,pd.MaterialShortName,s.ShopID,s.ShopName,s.ShopCode,m.PickDate,
		  om.BillNo as BCBillNo ,om.ZipCode,om.Province,om.City,om.Address,om.Area,om.ConsigneeName,od.OutBillNo
		  ,pd.Sequence,ss.CNStateName as PickStatus,CASE ISNULL( od.ShopBillNo,'') WHEN '' THEN om.ShopBillNo ELSE od.ShopBillNo END  AS ShopBillNo ,od.SubOrderNo,od.ColorID,sm.ColorCode,sm.ColorName,
		  ic.ShortName ExpressName,om.ExpressCost, m.ExpressBillNo,s.OnlineType,m.Chooser,p.PersonnelName,ps.SizeID,ps.BillQty,convert(int,isnull( ps.Qty,0))as PickQty,sm.SizeName,od.PayAmount,om.ExpressAmount
		  ,m.StockID,sk.StockName,sm.Barcode,sm.CardName,sm.KindName,om.BillNo omBillNo,od.sequence pssequence, ps.sizeid pssizeid
		  from #temp_SD_Inv_PickUpMaster m 
		  inner join SD_Inv_PickUpDetail pd  
		  on m.CompanyID = pd.CompanyID and m.BillNo = pd.BillNo
		  inner join SD_Inv_PickUpSize ps on ps.CompanyID = pd.CompanyID and ps.BillNo = pd.BillNo and ps.Sequence = pd.Sequence
		  inner join #temp_BC_Sal_OrderMaster om
		  on om.CompanyID = m.CompanyID and om.BillNo = pd.SourceBillNo
		  inner join BC_Sal_OrderDetail od on od.CompanyID = om.CompanyID and od.BillNo= om.BillNo
		  and pd.SourceBillNo = od.BillNo and pd.SourceBillSequence= od.Sequence
		  left join Bas_Shop s
		  on s.CompanyID= om.CompanyID and s.ShopID = om.ShopID
		  left join Bas_InterCompany ic on ic.VendCustID= om.VendCustID 
		  Left Join Bas_Personnel p On m.CompanyID = p.CompanyID and m.Chooser = p.PersonnelID
		  left JOIN dbo.vwSD_MaterialSize sm ON ps.CompanyID = sm.CompanyID AND ps.MaterialID = sm.MaterialID and  ps.SizeID = sm.SizeID 
		  --left join SD_Mat_Color c on c.ColorID = od.ColorID
		  --Left Join SD_Mat_Size ms On ms.SizeID = ps.SizeID
		  --Left Join SD_Mat_MaterialSize  Bar On ps.SizeID = Bar.SizeID and pd.MaterialID = Bar.MaterialID
		  Left Join Bas_Stock sk On sk.CompanyID = om.CompanyID and sk.StockID = om.StockID  
		  left join Sys_State ss on ss.StateFixFlag='PickStatus' and ss.StateType =m.PickStatus 
		  --left join vwSD_Pos_SaleMaster posinfo on posinfo.CompanyID = om.CompanyID and  posinfo.BCSourceBillNo = om.BillNo and posinfo.CompanyID=@CompanyID
		  --outer apply(
				--  select top 1 pm.BillDate from vwSD_Pos_SaleMaster  pm  
				--  where pm.CompanyID = om.CompanyID and  pm.BCSourceBillNo = om.BillNo 
		  --) posinfo
		--Where om.CompanyID = @CompanyID  
		--and om.BillTypeID = 'BC_NetSalOrder'	
		--and m.Chooser in (Select PersonnelID From #PersonnelStr)      
		--and (
		--om.ShopID in (Select ShopID From #ShopStr))      
		--and (
		--om.StockID in (Select StockID From #StockStr))      		
		--and (m.PickDate between @BegDate and @EndDate)	
	 --   and m.PickStatus in(select PickStatus from #PickStatusStr)
	END
	SELECT seq,
	(case  when  posinfo.BillDate is null then '' else convert(varchar(100),year(posinfo.BillDate)) end) as [Year],
	      (case  when  posinfo.BillDate is null then '' else convert(varchar(100),month(posinfo.BillDate)) end) as [Month],
	      convert(varchar(10),posinfo.BillDate,120) as[BillDate]
		  ,a.BillNo,a.MaterialID,a.MaterialCode,a.MaterialShortName,a.ShopID,ShopName,ShopCode,PickDate,
		 BCBillNo ,ZipCode,Province,City,Address,Area,ConsigneeName,OutBillNo
		 ,a.Sequence,PickStatus ,ShopBillNo,SubOrderNo,ColorID,ColorCode,ColorName,
		  ExpressName,ExpressCost, ExpressBillNo,OnlineType,Chooser,PersonnelName,a.SizeID,BillQty, PickQty,SizeName,a.PayAmount,ExpressAmount
		 ,a.StockID,StockName,a.Barcode,CardName,KindName 
	FROM 
	#result a
	left join dbo.vwSD_Pos_SaleDetail posinfo1 on posinfo1.CompanyID = @CompanyID and  posinfo1.BCSourceBillNo = a.omBillNo 
		  AND  posinfo1.BCSourceBillSequence =a.pssequence AND posinfo1.sizeid = a.pssizeid
	left join vwSD_Pos_SaleMaster posinfo on posinfo.CompanyID = @CompanyID and  posinfo.BillNo = posinfo1.BillNo and posinfo.CompanyID=@CompanyID
	if object_id('tempdb..#Material') is not null
	begin
	drop table #Material
	end
	if object_id('tempdb..#ShopStr') is not null
	begin
	drop table #ShopStr
	end
	if object_id('tempdb..#StockStr') is not null
	begin
	drop table #StockStr
	end
	if object_id('tempdb..#PersonnelStr') is not null
	begin
	drop table #PersonnelStr
	end
	if object_id('tempdb..#PersonnelStr2') is  not null
	drop table #PersonnelStr2
	 if object_id('tempdb..#PickStatusStr') is  not null
	drop table #PickStatusStr
END