
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spBC_SetSalOrderStockIDByAreaForCheckInv]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spBC_SetSalOrderStockIDByAreaForCheckInv]
GO



-- =============================================
-- Author:		����Ӫ
-- Create date: <Create Date,,>
-- Description:	Ĭ�Ϸ�������Ϣ����
-- =============================================
CREATE PROCEDURE [dbo].[spBC_SetSalOrderStockIDByAreaForCheckInv]
    @CompanyID T_ID ,
    @sourceInv VARCHAR(10)--�жϵ�����Դ��audit:�Զ����ǰ����,stockrule:�Զ��ֲ�ǰ���á�Ŀǰû��ʲô���ã�������ݿ�������ͨ������Ĳ�������ĳЩ���ܡ�
AS 
    BEGIN
	 
        SET NOCOUNT ON;

        DECLARE @v VARCHAR(10)

        DECLARE @PaymentDateBegin DATETIME
        DECLARE @PaymentDateEnd DATETIME
        DECLARE @span INT = 3 --Ĭ�ϴ�����15���ڵĶ�����
	--declare @CompanyID T_ID='hk'
        SET @PaymentDateBegin = DATEADD(DAY, -@span, GETDATE()) 
        SET @PaymentDateEnd = GETDATE()
	--select @PaymentDateBegin,@PaymentDateEnd
        CREATE TABLE #editbillno
            (
              companyid VARCHAR(10) ,
              billno VARCHAR(40) ,
              StockID VARCHAR(20) ,--�������õĲֿ⡣2
              OldStockID VARCHAR(20) ,--�����û��޸�ǰ�Ĳֿ⡣0
              BillStockID VARCHAR(20) ,--���ݲֿ⡣1
              flag BIT DEFAULT ( 0 ) ,
              msg NVARCHAR(MAX) ,
              RuleID VARCHAR(20) ,
              rowindex INT PRIMARY KEY
                           IDENTITY(1, 1) ,
              Sequence VARCHAR(5), --������ϸ��ţ��жϲֿ��ʱ��
			  SourceType varchar(20),--������Դ
			  OnlineType INT
            )
 
  --�ж��Ƿ�������Ĭ�Ϸ����ֹ���
        IF EXISTS ( SELECT  1
                    FROM    BC_Bas_StockRuleSetting d WITH ( NOLOCK )
                    WHERE   d.companyid = @CompanyID
                            AND d.allowused = 1
                            AND checkstate = 1 ) 
            BEGIN
                PRINT ( 'setstockrule' )
			--ruletype 1����ʡ��2������
			--��ѯ�Ѿ����úõĹ���
                SELECT  d.companyid ,
                        d.ruleid ,
                        d.Sequence ,
                        d.ruletype ,
                        d.VALUE ,
                        d.value2 AS StockID ,
                        s.shopid ,
                        areainfo.*
                INTO    #defaultarea
                FROM    BC_Bas_StockRuleSetting s WITH ( NOLOCK )
                        INNER JOIN BC_Bas_StockRuleSettingDetail d WITH ( NOLOCK ) ON s.companyid = d.companyid
                                                              AND s.ruleid = d.ruleid
                        OUTER APPLY ( SELECT    p.AreaCode ,
                                                p.AreaName ,
                                                p.ParentID ,
                                                p.AreaID ,
                                                para.AreaName AS ParentAreaName
                                      FROM      [dbo].[fnSplitStr](d.valuecode,
                                                              ';') f
                                                INNER JOIN BC_Bas_Area p WITH ( NOLOCK ) ON p.areacode = f.colname --��ǰʡ��
                                                INNER JOIN dbo.BC_Bas_Area para
                                                WITH ( NOLOCK ) ON para.AreaID = p.ParentID --��ǰʡ�еĸ�����
--����
                                      
                                    ) areainfo
                WHERE   s.companyid = @CompanyID
                        AND s.allowused = 1
                        AND s.CheckState = 1
                        AND d.allowused = 1

                DECLARE @IsBillNoWheret BIT= 1;--�Ƿ�����ʱ���ĵ����жϡ�
--SELECT ''AS test,* FROM #defaultarea
--�ж��Ƿ��ô����Ķ������ݽ����ж�
                IF ( OBJECT_ID('tempdb.dbo.#BillNoFilter') IS   NULL ) 
                    BEGIN
                        SET @IsBillNoWheret = 0;
                        CREATE TABLE #BillNoFilter
                            (
                              companyid VARCHAR(20) ,
                              billno VARCHAR(40)
                            );
                    END
--��ʱ����������߲�ѯ���ܡ�
                CREATE NONCLUSTERED INDEX ix_BillNoFilter_index ON #BillNoFilter(CompanyID,billno)

                IF ( @IsBillNoWheret = 1 ) 
                    BEGIN
	--������ʡ�ġ�ֱ���ö����Ź���.
            --UPDATE  m
            --SET     m.StockID = x.StockID
                        INSERT  INTO #editbillno
                                ( companyid ,
                                  billno ,
                                  StockID ,
                                  OldStockID ,
                                  RuleID ,
                                  BillStockID ,
                                  Sequence,
								  SourceType,
								  OnlineType  
                                )
                                SELECT  m.CompanyID ,
                                        m.BillNo ,
                                        x.StockID ,
                                        m.oldStockID ,
                                        x.RuleID ,
                                        m.StockID ,
                                        x.Sequence,
										m.SourceType,
										p.OnlineType
                                FROM    BC_Sal_OrderMaster m WITH ( NOLOCK )
                                        INNER JOIN #BillNoFilter filter ON m.CompanyID = filter.companyid
                                                              AND m.BillNo = filter.billno
                                        INNER JOIN dbo.Bas_Shop p WITH ( NOLOCK ) ON m.CompanyID = p.CompanyID
                                                              AND m.ShopID = p.ShopID
                                        INNER JOIN #defaultarea x ON m.CompanyID = x.companyid
                                                              AND m.shopid = x.shopid
                                                              AND m.BillStatus IN (
                                                              0, 3 )
                                                              AND m.IsHide = 0
                                                              AND x.ruletype = 1
                                                 --AND ISNULL(m.StockID, '') <> ISNULL(x.StockID, '')
                                                              AND x.AreaName LIKE m.Province
                                                              + '%'
                                WHERE   m.CompanyID = @CompanyID
                                        AND m.BillStatus IN ( 0, 3 )
                                        AND m.IsHide = 0
                                --AND ISNULL(m.oldStockID, '') = ''--û���޸Ĺ��ֿ�ģ�����Ӧ�ù��� ������޸Ĺ��Ͳ�Ӧ�ù���
                                        AND p.Lan = 0
                                        AND ISNULL(m.IsSetStocked, 0) = 0--û�зֲִ������Ķ�����
                                        AND ISNULL(m.RefundChangeType, '') IN (
                                        '1', '' )--�˻�����Ϊ��������Ĭ�����صĶ�����Ҳ����˵�����˵Ķ�����
		--�����е�
            --UPDATE  m
            --SET     m.StockID = x.StockID
                        INSERT  INTO #editbillno
                                ( companyid ,
                                  billno ,
                                  StockID ,
                                  OldStockID ,
                                  RuleID ,
                                  BillStockID ,
                                  Sequence,
								 SourceType,
								 OnlineType  
                                )
                                SELECT  m.CompanyID ,
                                        m.BillNo ,
                                        x.StockID ,
                                        m.oldStockID ,
                                        x.RuleID ,
                                        m.StockID ,
                                        x.Sequence,
										m.SourceType,
										p.OnlineType
                                FROM    BC_Sal_OrderMaster m WITH ( NOLOCK )
                                        INNER JOIN #BillNoFilter filter ON m.CompanyID = filter.companyid
                                                              AND m.BillNo = filter.billno
                                        INNER JOIN dbo.Bas_Shop p WITH ( NOLOCK ) ON m.CompanyID = p.CompanyID
                                                              AND m.ShopID = p.ShopID
                                        INNER JOIN #defaultarea x ON m.CompanyID = x.companyid
                                                              AND m.shopid = x.shopid
                                                              AND m.BillStatus IN (
                                                              0, 3 )
                                                              AND m.IsHide = 0
                                                              AND x.ruletype = 2
                                                 --AND ISNULL(m.StockID, '') <> ISNULL(x.StockID, '') 
                                                              AND x.ParentAreaName LIKE m.Province
                                                              + '%' --������еģ��������ʡ��Ϊ�жϵ�������
                                                              AND x.AreaName LIKE m.City
                                                              + '%'
                                WHERE   m.CompanyID = @CompanyID
                                        AND m.BillStatus IN ( 0, 3 )
                                        AND m.IsHide = 0
                                --AND ISNULL(m.oldStockID, '') = ''--û���޸Ĺ��ֿ�ģ�����Ӧ�ù��� ������޸Ĺ��Ͳ�Ӧ�ù���
                                        AND p.Lan = 0
                                        AND ISNULL(m.IsSetStocked, 0) = 0--û�зֲִ������Ķ�����
                                        AND ISNULL(m.RefundChangeType, '') IN (
                                        '1', '' )--�˻�����Ϊ��������Ĭ�����صĶ�����Ҳ����˵�����˵Ķ�����

                    END
                ELSE 
                    BEGIN

--������ʡ�ġ���ʱ��ֱ�Ӵ��������۶����в��� .
            --UPDATE  m
            --SET     m.StockID = x.StockID
                        INSERT  INTO #editbillno
                                ( companyid ,
                                  billno ,
                                  StockID ,
                                  OldStockID ,
                                  RuleID ,
                                  BillStockID ,
                                  Sequence,
								  SourceType,
								  OnlineType 
                                )
                                SELECT  m.CompanyID ,
                                        m.BillNo ,
                                        x.StockID ,
                                        m.oldStockID ,
                                        x.RuleID ,
                                        m.StockID ,
                                        x.Sequence,
										m.SourceType,
										p.OnlineType
                                FROM    BC_Sal_OrderMaster m WITH ( NOLOCK )
                                        INNER JOIN dbo.Bas_Shop p WITH ( NOLOCK ) ON m.CompanyID = p.CompanyID
                                                              AND m.ShopID = p.ShopID
                                        INNER JOIN #defaultarea x ON m.CompanyID = x.companyid
                                                              AND m.shopid = x.shopid
                                                              AND m.BillStatus IN (
                                                              0, 3 )
                                                              AND m.IsHide = 0
                                                              AND x.ruletype = 1
                                                 --AND ISNULL(m.StockID, '') <> ISNULL(x.StockID, '')
                                                              AND x.AreaName LIKE m.Province
                                                              + '%'
                                WHERE   m.CompanyID = @CompanyID
                                        AND m.BillDate BETWEEN @PaymentDateBegin
                                                       AND    @PaymentDateEnd
                                        AND m.BillStatus IN ( 0, 3 )
                                        AND m.IsHide = 0
                                --AND ISNULL(m.oldStockID, '') = ''--û���޸Ĺ��ֿ�ģ�����Ӧ�ù��� ������޸Ĺ��Ͳ�Ӧ�ù���
                                        AND p.Lan = 0
                                        AND ISNULL(m.IsSetStocked, 0) = 0--û�зֲִ������Ķ�����
                                        AND ISNULL(m.RefundChangeType, '') IN (
                                        '1', '' )--�˻�����Ϊ��������Ĭ�����صĶ�����Ҳ����˵�����˵Ķ�����
		--�����е�
            --UPDATE  m
            --SET     m.StockID = x.StockID
                        INSERT  INTO #editbillno
                                ( companyid ,
                                  billno ,
                                  StockID ,
                                  OldStockID ,
                                  RuleID ,
                                  BillStockID ,
                                  Sequence,
								  SourceType,
								  OnlineType   
                                )
                                SELECT  m.CompanyID ,
                                        m.BillNo ,
                                        x.StockID ,
                                        m.oldStockID ,
                                        x.RuleID ,
                                        m.StockID ,
                                        x.Sequence,
										m.SourceType,
										p.OnlineType
                                FROM    BC_Sal_OrderMaster m WITH ( NOLOCK )
                                        INNER JOIN dbo.Bas_Shop p WITH ( NOLOCK ) ON m.CompanyID = p.CompanyID
                                                              AND m.ShopID = p.ShopID
                                        INNER JOIN #defaultarea x ON m.CompanyID = x.companyid
                                                              AND m.shopid = x.shopid
                                                              AND m.BillStatus IN (
                                                              0, 3 )
                                                              AND m.IsHide = 0
                                                              AND x.ruletype = 2
                                                 --AND ISNULL(m.StockID, '') <> ISNULL(x.StockID, '') 
                                                              AND x.ParentAreaName LIKE m.Province
                                                              + '%' --������еģ��������ʡ��Ϊ�жϵ�������
                                                              AND x.AreaName LIKE m.City
                                                              + '%'
                                WHERE   m.CompanyID = @CompanyID
                                        AND m.BillDate BETWEEN @PaymentDateBegin
                                                       AND    @PaymentDateEnd
                                        AND m.BillStatus IN ( 0, 3 )
                                        AND m.IsHide = 0
                                --AND ISNULL(m.oldStockID, '') = ''--û���޸Ĺ��ֿ�ģ�����Ӧ�ù��� ������޸Ĺ��Ͳ�Ӧ�ù���
                                        AND p.Lan = 0
                                        AND ISNULL(m.IsSetStocked, 0) = 0--û�зֲִ������Ķ�����
                                        AND ISNULL(m.RefundChangeType, '') IN (
                                        '1', '' )--�˻�����Ϊ��������Ĭ�����صĶ�����Ҳ����˵�����˵Ķ�����
           
                    END	   
		   --����ʡ���ж��ܲ��ҵ��Ķ�����Ӧ�ñ����еġ�������滹������Ӧ�������ġ�������ģ����Խ��Ӧ�ñ������Խ��ġ�
		   --Ŀǰ���������룬Ӧ�������� ��
                SELECT  e.companyid ,
                        e.billno ,
                        MAX(e.rowindex) AS rowindex
                INTO    #deletetable
                FROM    #editbillno e
                GROUP BY e.companyid ,
                        e.billno
                HAVING  COUNT(1) > 1
		   --��ʼɾ���ظ��Ķ������ݡ� 
                DELETE  d
                FROM    #deletetable m
                        INNER JOIN #editbillno d ON m.companyid = d.companyid
                                                    AND m.billno = d.billno
                                                    AND d.rowindex < m.rowindex
		   --������ʱ�����ݡ�
                DROP TABLE #deletetable

                DECLARE @no UNIQUEIDENTIFIER = NEWID()
		 
            --�ж��Ѿ��޸Ĺ��ֿ�Ķ�������д����Ѿ��ֲִ�������ɾ���Ѿ��������Ľ����
                IF ( EXISTS ( SELECT    1
                              FROM      #editbillno t
                              WHERE     ISNULL(t.oldStockID, '') > '' ) ) 
                    BEGIN
                        PRINT ( 'userEditStock' );
                        UPDATE  m
                        SET     m.IsSetStocked = 1
                        FROM    #editbillno t
                                INNER JOIN dbo.BC_Sal_OrderMaster m ON t.companyid = m.CompanyID
                                                              AND t.billno = m.BillNo
                        WHERE   ISNULL(t.oldStockID, '') > ''

                       
						--��ʼд��־��
                      
                        INSERT  INTO [BC_Log_SetStockIDMaster]
                                ( [NO] ,
                                  [CompanyID] ,
                                  [BillNo] ,
                                  [StockID] ,
                                  [OldStockID] ,
                                  [IsError] ,
                                  [Msg] ,
                                  [RuleID] ,
                                  [AddDTM]
                                )
                                SELECT  @no AS [no] ,
                                        e.companyid ,
                                        e.billno ,
                                        e.stockid ,
                                        e.oldstockid ,
                                        0 AS IsError ,
                                        N'��Ϊ�û��޸Ĺ��ֿ�Ķ�������������жϣ����ݲֿⲻ������' AS msg ,
                                        e.ruleid ,
                                        GETDATE()
                                FROM    #editbillno e
                                WHERE   e.oldStockID > ''
 

                        DELETE  t
                        FROM    #editbillno t
                        WHERE   ISNULL(t.oldStockID, '') > ''

                    END
		    --��ӡ��Ҫ�޸Ĳֿ�Ķ�����
                SELECT  companyid ,
                        billno ,
                        StockID , --�Ż��жϿ��Ĳֿ⡣
                        OldStockID ,
                        BillStockID ,
                        flag ,
                        msg ,
                        RuleID ,
                        t.Sequence,
						t.sourcetype,
						t.OnlineType
                FROM    #editbillno t
		 --��ѯ��Ҫ�жϿ��Ĳֿ��б� ��
                SELECT  s.*
                FROM    BC_Bas_StockRuleSettingStock s
                        INNER JOIN ( SELECT DISTINCT
                                            d.companyid ,
                                            d.ruleid ,
                                            d.sequence
                                     FROM   #editbillno d
                                   ) a ON a.companyid = s.companyid
                                          AND a.ruleid = s.ruleid
                                          AND a.sequence = s.sequence
                WHERE   s.AllowUsed = 1
                ORDER BY s.ruleid ,
                        s.SortIndex ASC

                DROP TABLE #defaultarea
                DROP TABLE #editbillno
                DROP TABLE #BillNoFilter
            END


    END



GO


