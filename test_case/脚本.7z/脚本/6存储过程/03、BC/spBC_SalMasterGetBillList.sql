 IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spBC_SalMasterGetBillList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spBC_SalMasterGetBillList]
GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	�������۶����б���ѯ
-- =============================================
CREATE PROCEDURE [dbo].[spBC_SalMasterGetBillList]
	 @sqlList NVARCHAR(MAX),
	 @PageIndex INT,   --��ǰҳ����
	 @PageSize INT     --ÿҳҪ��ʾ������
AS
BEGIN
	 
	 DECLARE @sql NVARCHAR(max)='
SELECT  EdiOrderType,companyid,billno,BillStatus,BillStatusName,ShopCode,ShopName,OnlineType,StockCode,StockName, 
VendCustCode,ShortName,PersonnelCode,PersonnelName,OperatorName,CheckerName,CancelContact_Name , 
Contact_Name,CancelShopAddress,ShopAddress,ColorValue ,OrderCustomerName ,O2OShopCode ,WorkPropertyName, 
O2OShopName ,ReturnStockCode ,ReturnStockName,ProjectNo,IsPrintExpress,ReturnsFreBillNo,OpResultStatusName,IsPrintSendBill, 
WorkPropertyID,IsSetStocked,IsInvoiceSend,PersonnelShopID,PersonnelShopCode,PersonnelShopName,RecReturnDate,LabelName,IsPresentGood, CompanyBalanceAmount, CompanyMemberCode  
INTO    #m1 FROM    ( 
SELECT    a.EdiOrderType,a.CompanyID , 
0 AS Flag , 
a.BillNo , 
a.BannerState , 
m.StateName AS BillStatusName , 
a.BillTypeID , 
a.BillDate , 
a.BillStatus , 
a.CheckDate , 
a.ShopID , 
g.ShopCode AS ShopCode , 
g.ShopName AS ShopName , 
g.OnlineType AS OnlineType , 
d1.StockCode AS StockCode , 
a.StockID , 
d1.StockName AS StockName, 
a.ShopBillNo , 
a.AlipayBillNo , 
a.BuyerAlipayNo , 
a.TurnoverDate , 
a.PaymentDate , 
a.SaleType , 
a.ExceptionStatus , 
a.OperStatus , 
a.TranState , 
a.TranType , 
a.ExpressType , 
a.VendCustID , 
r.VendCustCode AS VendCustCode , 
r.ShortName AS ShortName , 
a.ExpressBillNo , 
a.OutBillNo , 
a.WMS_OrderID , 
a.ConsignmentDate , 
a.PickStatus , 
a.SourceType , 
a.SourceRemark , 
a.OrderType , 
a.MergeSplitType , 
a.MergeSourceBillNo , 
a.IsPrintExpressBill , 
a.IsPrintDistBill , 
a.BuyerCode , 
a.BuyerMobileTel , 
a.BuyerTel , 
a.BuyerRemark , 
a.ConsigneeName , 
a.Province , 
a.City , 
a.Area , 
a.ZipCode , 
a.Address , 
a.SellRemark , 
a.SellCode , 
a.ExceptionNode , 
a.PersonnelID , 
q.PersonnelCode AS PersonnelCode , 
q.PersonnelName AS PersonnelName , 
a.Operator , 
e.UserName AS OperatorName , 
a.Checker , 
f.UserName AS CheckerName , 
a.ModifyDTM , 
a.Paymenttype , 
a.CodCharges , 
a.Qty , 
a.PayAmount , 
a.ExpressAmount , 
a.ExpressCost , 
a.TotalBarginPrice , 
a.ZRAmount , 
a.IsInvoice , 
a.invoice_name , 
a.PreRemark , 
a.Weight , 
a.ParcelWeight , 
a.PackageCost , 
a.BuyerGetBonus , 
a.BuyerUseBonus , 
a.DischargeIntegral , 
a.DischargeIntegralAmount , 
a.ExchangeIntegral , 
a.BuyerRealUseBonus , 
a.CancelContact_ID , 
a.SendContact_ID , 
s2.Contact_Name AS CancelContact_Name , 
s1.Contact_Name AS Contact_Name , 
s2.ShopAddress AS CancelShopAddress , 
s1.ShopAddress AS ShopAddress , 
a.BuyerID , 
a.CardCode , 
a.Remark , 
a.WorkPropertyName , 
a.Signature , 
a.IsHide , 
a.RecStatus , 
a.IsLock , 
a.OldOperator , 
a.ProjectNo , 
a.IsPrintExpress , 
a.IsPrintSendBill , 
a.ManualBillNo , 
a.PromZRAmount , 
a.PayAmountBakUp , 
a.OrderCustomerID , 
g2.ColorValue AS ColorValue , 
g2.OrderCustomerName AS OrderCustomerName , 
a.IsAutoMerge , 
a.IsReturnOrder , 
a.IsConsultingOrder , 
a.RefundType , 
a.ReturnsFreBillNo , 
a.O2OShopID , 
vOs.shopcode AS O2OShopCode , 
vOs.shopname AS O2OShopName , 
a.O2OCompanyID , 
a.OpResultStatusName , 
a.WorkPropertyID , 
a.RefundChangeType , 
a.CardAmount , 
a.CardsNo , 
a.RptAmount , 
a.IsBCVirOrder , 
a.PdAmount , 
a.ReturnItemStatus , 
a.IsSendToEDI , 
a.ReturnStockID , 
bs2.StockCode AS ReturnStockCode , 
bs2.StockName AS ReturnStockName, 
a.IsSetStocked, 
a.IsInvoiceSend, 
a.PersonnelShopID, 
pg.ShopCode as PersonnelShopCode, 
pg.ShopName AS PersonnelShopName, 
a.RecReturnDate, 
a.LabelName,
a.IsPresentGood,
a.CompanyBalanceAmount,
a.CompanyMemberCode 
/*FROM      vwBC_Sal_OrderMaster a */

From (SELECT   
				case 
				when saletype=0 then 1 --��������
				when RefundChangeType=0 then 3 --�˻���
				when RefundChangeType= 1 and ReturnItemStatus=1 then 3 --������δ�˻�
				when RefundChangeType= 1 and ReturnItemStatus in (2,3) then 2 --���������˻���
				end as EdiOrderType,
				m.[CompanyID], m.[BillNo], m.[BillTypeID], m.[BillDate], m.[BillStatus], m.[CheckDate], m.[Checker], m.[Operator], 
                m.[Signature], m.[Remark], m.[ModifyDTM], m.[ShopID], m.[StockID], m.[ShopBillNo], m.[AlipayBillNo], m.[TurnoverDate], 
                m.[BannerState], m.[OperStatus], m.[TranState], m.[TranType], m.[VendCustID], m.[OutBillNo], m.[ExpressBillNo], 
                m.[ConsignmentDate], m.[Qty], m.[PayAmount], m.[ExpressAmount], m.[ZRAmount], m.[ExpressCost], m.[IsInvoice], 
                m.[PreRemark], m.[SaleType], m.[Weight], m.[ParcelWeight], m.[PackageCost], m.[SourceType], m.[SourceRemark], 
                m.[OrderType], m.[MergeSplitType], m.[MergeSourceBillNo], m.[IsPrintExpressBill], m.[IsPrintDistBill], m.[BuyerCode], 
                m.[BuyerMobileTel], m.[BuyerTel], m.[BuyerRemark], m.[ConsigneeName], m.[Province], m.[City], m.[Area], m.[ZipCode], 
                m.[Address], m.[SellRemark], m.[SellCode], m.[ExceptionStatus], m.[ExceptionNode], m.[PaymentDate], m.[IsHide], 
                m.[PickStatus], m.[Paymenttype], m.[CodCharges], m.[ManualBillNo], m.[RecStatus], m.[OldOperator], m.[ExpressType], 
                m.[invoice_name], m.[BuyerGetBonus], m.[BuyerUseBonus], m.[BuyerRealUseBonus], m.[PersonnelID], 
                m.[SendContact_ID], m.[CancelContact_ID], m.[PromZRAmount], m.[PayAmountBakUp], 
                (CASE m.OrderCustomerID WHEN '''' THEN ''-1'' ELSE ISNULL(m.[OrderCustomerID], ''-1'') END) AS OrderCustomerID, 
                m.[IsAutoMerge], m.[IsReturnOrder], m.TotalBarginPrice, ISNULL(p.IsPrintExpress, 0) AS IsPrintExpress, 
                ISNULL(p.IsPrintSendBill, 0) AS IsPrintSendBill, p.PickBillNo, p.PickStatusName, p.ProjectNo, 
                ISNULL(m.IsConsultingOrder, 0) AS IsConsultingOrder, r.ReturnsFreBillNo, m.BuyerAlipayNo, ISNULL(m.IsLock, 0) 
                AS IsLock, m.O2OShopID, m.O2OCompanyID, m.OldO2OShopID, m.DischargeIntegral, m.DischargeIntegralAmount, 
                m.ExchangeIntegral, m.CardCode, m.BuyerID, edi.OpResultStatus, ISNULL(edi.OpResultStatusName, '''') 
                AS OpResultStatusName, m.RefundType, m.WMS_OrderID, s.WorkPropertyID, i.InfoName AS WorkPropertyName, 
                m.RefundChangeType, m.CardAmount, m.CardsNo, m.RptAmount, ISNULL(m.IsBCVirOrder, 0) AS IsBCVirOrder, 
                ISNULL(m.PdAmount, 0) AS PdAmount, m.ReturnItemStatus, m.IsSendToEDI, m.ReturnStockID, ISNULL(m.IsSetStocked, 
                0) AS IsSetStocked, m.IsInvoiceSend, m.InvoiceNo, m.NotAuditReason, m.InvoiceHeader, m.InvoiceType, m.TaxNO, 
                m.Bank, m.BankAccount, m.InvoiceContent, m.InvoiceMedium, m.PersonnelShopID, r.RecReturnDate, m.LabelName, 
                ISNULL(m.SendEdiLock, 0) SendEdiLock, m.IsPresentGood, m.CompanyBalanceAmount, m.CompanyMemberCode
FROM      BC_Sal_OrderMaster m OUTER APPLY
                    (SELECT   TOP 1 pm.ProjectNo, pm.BillNo AS [PickBillNo], ISNULL(pd.IsPrintExpress, 0) AS IsPrintExpress, 
                                     ISNULL(pd.IsPrintSendBill, 0) AS IsPrintSendBill, 
                                     se.CNStateName AS [PickStatusName]
                     /*pm.PickStatus as SDPickStatus*/ FROM SD_Inv_PickUpMaster pm INNER JOIN
                                     SD_Inv_PickUpDetail pd ON pm.CompanyID = pd.CompanyID AND pm.BillNo = pd.BillNo LEFT JOIN
                                     Sys_State se ON se.StateFixFlag = ''PickStatus'' AND se.StateType = pm.PickStatus
                     WHERE   pd.SourceBillNo = m.BillNo AND pd.CompanyID = m.CompanyID
                     ORDER BY pm.ModifyDTM DESC) p LEFT JOIN
                BC_Sal_Returninfo r ON m.CompanyID = r.CompanyID AND m.BillNo = r.BillNo OUTER APPLY
                    (SELECT   TOP 1 g.OpResultStatus, g.OpResultStatusName
                     FROM      (SELECT   TOP 1 t .OpResultStatus, c.StateName AS OpResultStatusName
                                      FROM      HK_EDI_JobOrderTrace t JOIN
                                                      dbo.SD_EDI_Stock b ON b.OSStockID = t .OSStockID JOIN
                                                      dbo.HK_EDI_OrderState c ON c.CooperationSys = b.CooperationSys AND 
                                                      t .OpResultStatus = c.StateType
                                      WHERE   t .BillTypeID = ''BC_NetSalOrder'' AND t .CompanyID = m.CompanyID AND 
                                                      t .NoticeBillNo = m.BillNo
                                      ORDER BY t .CreateDate DESC) g) edi LEFT JOIN
                dbo.Bas_Shop s ON s.CompanyID = m.CompanyID AND s.ShopID = m.ShopID AND s.Lan = 0 LEFT JOIN
                SD_Bas_ShopAndCustBaseInfo i ON /*AND*/ s.WorkPropertyID = i.InfoID AND i.Lan = 0) a

LEFT JOIN ( SELECT  StateId , 
StateType , 
CNStateName AS StateName 
FROM    Sys_State 
WHERE   StateFixFlag = ''BillState'' 
) AS m ON a.BillStatus = m.StateType 
LEFT JOIN Bas_Shop AS g ON g.Lan = 0 
AND a.ShopID = g.ShopID 
LEFT JOIN Bas_Stock AS d1 ON d1.Lan = 0
AND a.StockID = d1.StockID 
LEFT JOIN Bas_InterCompany AS r ON r.Lan = 0 
AND a.VendCustID = r.VendCustID 

/*LEFT JOIN vwBC_Personnel AS q ON q.Lan = 0 */
left join (SELECT DISTINCT CompanyID, PersonnelID, PersonnelCode, PersonnelName, Email, Lan
FROM      dbo.Bas_Personnel) as q on q.Lan=0

AND a.PersonnelID = q.PersonnelID 
AND a.CompanyID = q.CompanyID 
LEFT JOIN Sys_User AS e ON a.Operator = e.UserID 
LEFT JOIN Sys_User AS f ON a.Checker = f.UserID 

/*LEFT JOIN vwBC_Bas_ShopAddr AS s2 ON a.CancelContact_ID = s2.ShopAddrID */
/*LEFT JOIN vwBC_Bas_ShopAddr AS s1 ON a.SendContact_ID = s1.ShopAddrID  */
left join (SELECT   CompanyID, ShopID, ShopID + Contact_ID AS ShopAddrID, Contact_ID, Contact_Name, Province, City, Country, Address, 
                ZipCode, TelPhone, MobilePhone, Seller_Company, Area_ID, IsDefaultSend, IsDefaultGet, IsDefaultCancel, Remark, 
                ModifyDTM, Province + '' '' + City + '' '' + Country + '' '' + Address AS ShopAddress, AllowUsed
FROM      dbo.BC_Bas_ShopAddr) as s2 on a.CancelContact_ID=s2.ShopAddrID
left join (SELECT   CompanyID, ShopID, ShopID + Contact_ID AS ShopAddrID, Contact_ID, Contact_Name, Province, City, Country, Address, 
                ZipCode, TelPhone, MobilePhone, Seller_Company, Area_ID, IsDefaultSend, IsDefaultGet, IsDefaultCancel, Remark, 
                ModifyDTM, Province + '' '' + City + '' '' + Country + '' '' + Address AS ShopAddress, AllowUsed
FROM      dbo.BC_Bas_ShopAddr) as s1 on a.SendContact_ID=s1.ShopAddrID

LEFT JOIN BC_Bas_OrderCustomerFlg AS g2 ON a.OrderCustomerID = g2.OrderCustomerID
 
/*LEFT JOIN vwBC_O2OShop AS vOs ON a.O2OShopID = vOs.shopID */
left join (SELECT   a.CompanyID, a.ShopID, a.ShopCode, a.ShopName, CASE WHEN b.ShopID IS NULL THEN 0 ELSE 1 END AS IsO2OShop, 
                a.AllowUsed
FROM      dbo.Bas_Shop AS a LEFT OUTER JOIN
                dbo.BC_Bas_O2O_Shop AS b ON a.ShopID = b.ShopID AND b.CompanyID = a.CompanyID) AS vOs ON a.O2OShopID = vOs.shopID 
				/*********************************��ͼ�滻���**********/


LEFT JOIN Bas_Stock AS bs2 ON bs2.Lan = 0 
AND a.ReturnStockID = bs2.StockID 
LEFT JOIN Bas_Shop AS pg ON pg.Lan = 0 
AND a.PersonnelShopID = pg.ShopID 
) a  where 
	 '
	 
	  declare @end nvarchar(max)=N'
	  CREATE NONCLUSTERED INDEX noindex_companyid_billno  ON  #m1(companyid,billno)
SELECT  
					a1.CompanyID ,
                    0 AS Flag ,
                    a1.BillNo ,
                    a1.BannerState ,
                    a1.BillStatusName ,
                    a1.BillTypeID ,
                    a1.BillDate ,
                    a1.BillStatus ,
                    a1.CheckDate ,
                    a1.ShopID ,
                    a1.ShopCode ,
                    a1.ShopName ,
                    a1.OnlineType ,
                    a1.StockCode ,
                    a1.StockID ,
                    a1.StockName ,
                    a1.ShopBillNo ,
                    a1.AlipayBillNo ,
                    a1.BuyerAlipayNo ,
                    a1.TurnoverDate ,
                    a1.PaymentDate ,
                    a1.SaleType ,
                    a1.ExceptionStatus ,
                    a1.OperStatus ,
                    a1.TranState ,
                    a1.TranType ,
                    a1.ExpressType ,
                    a1.VendCustID ,
                    a1.VendCustCode ,
                    a1.ShortName ,
                    a1.ExpressBillNo ,
                    a1.OutBillNo ,
                    a1.WMS_OrderID ,
                    a1.ConsignmentDate ,
                    a1.PickStatus ,
                    a1.SourceType ,
                    a1.SourceRemark ,
                    a1.OrderType ,
                    a1.MergeSplitType ,
                    a1.MergeSourceBillNo ,
                    ISNULL(a1.IsPrintExpressBill,0) IsPrintExpressBill ,
                    ISNULL(a1.IsPrintDistBill,0) IsPrintDistBill ,
                    a1.BuyerCode ,
                    a1.BuyerMobileTel ,
                    a1.BuyerTel ,
                    a1.BuyerRemark ,
                    a1.ConsigneeName ,
                    a1.Province ,
                    a1.City ,
                    a1.Area ,
                    a1.ZipCode ,
                    a1.Address ,
                    a1.SellRemark ,
                    a1.SellCode ,
                    a1.ExceptionNode ,
                    a1.PersonnelID ,
                    a1.PersonnelCode ,
                    a1.PersonnelName ,
                    a1.Operator ,
                    a1.OperatorName ,
                    a1.Checker ,
                    a1.CheckerName ,
                    a1.ModifyDTM ,
                    a1.Paymenttype ,
                    a1.CodCharges ,
                    a1.Qty ,
                    a1.PayAmount ,
                    a1.ExpressAmount ,
                    a1.ExpressCost ,
                    a1.TotalBarginPrice ,
                    a1.ZRAmount ,
                    a1.IsInvoice ,
                    a1.invoice_name ,
                    a1.PreRemark ,
                    a1.Weight ,
                    a1.ParcelWeight ,
                    a1.PackageCost ,
                    a1.BuyerGetBonus ,
                    a1.BuyerUseBonus ,
                    a1.DischargeIntegral ,
                    a1.DischargeIntegralAmount ,
                    a1.ExchangeIntegral ,
                    a1.BuyerRealUseBonus ,
                    a1.CancelContact_ID ,
                    a1.SendContact_ID ,
                    a1.CancelContact_Name ,
                    a1.Contact_Name ,
                    a1.CancelShopAddress ,
                    a1.ShopAddress ,
                    a1.BuyerID ,
                    a1.CardCode ,
                    a1.Remark ,
                    a1.WorkPropertyName ,
                    a1.Signature ,
                    a1.IsHide ,
                    a1.RecStatus ,
                    ISNULL(a1.IsLock,0) IsLock ,
                    a1.OldOperator ,
                    a1.ProjectNo ,
                    a1.IsPrintExpress ,
                    a1.IsPrintSendBill ,
                    a1.ManualBillNo ,
                    a1.PromZRAmount ,
                    a1.PayAmountBakUp ,
                    a1.OrderCustomerID ,
                    a1.ColorValue ,
                    a1.OrderCustomerName ,
                    a1.IsAutoMerge ,
                    a1.IsReturnOrder ,
                    ISNULL(a1.IsConsultingOrder,0) IsConsultingOrder ,
                    a1.RefundType ,
                    a1.ReturnsFreBillNo ,
                    a1.O2OShopID ,
                    a1.O2OShopCode ,
                    a1.O2OShopName ,
                    a1.O2OCompanyID ,
                    a1.OpResultStatusName ,
                    a1.WorkPropertyID ,
                    a1.RefundChangeType ,
                    a1.CardAmount ,
                    a1.CardsNo ,
                    a1.RptAmount ,
                    ISNULL(a1.IsBCVirOrder,0)IsBCVirOrder ,
                    ISNULL(a1.PdAmount,0)PdAmount ,
                    a1.ReturnItemStatus ,
                    ISNULL(a1.IsSendToEDI,0)IsSendToEDI ,
                    a1.ReturnStockID ,
                    a1.ReturnStockCode ,
                    a1.ReturnStockName,
					a1.IsSetStocked,
					a1.NotAuditReason,
					a1.InvoiceHeader,
					a1.InvoiceType,
					a1.TaxNO,
					a1.Bank,
					a1.BankAccount,
					a1.InvoiceContent,
					a1.InvoiceMedium,
					a1.PersonnelShopID,
					a1.PersonnelShopCode,
					a1.PersonnelShopName,
					a1.RecReturnDate,
					a1.LabelName,
					a1.IsPresentGood,
					a1.CompanyBalanceAmount,
					a1.CompanyMemberCode
from (select 
					a.CompanyID ,
                    0 AS Flag ,
                    a.BillNo ,
                    a.BannerState ,
                    #m1.BillStatusName ,
                    a.BillTypeID ,
                    a.BillDate ,
                    a.BillStatus ,
                    a.CheckDate ,
                    a.ShopID ,
                    #m1.ShopCode ,
                    #m1.ShopName ,
                    #m1.OnlineType ,
                    #m1.StockCode ,
                    a.StockID ,
                    #m1.StockName ,
                    a.ShopBillNo ,
                    a.AlipayBillNo ,
                    a.BuyerAlipayNo ,
                    a.TurnoverDate ,
                    a.PaymentDate ,
                    a.SaleType ,
                    a.ExceptionStatus ,
                    a.OperStatus ,
                    a.TranState ,
                    a.TranType ,
                    a.ExpressType ,
                    a.VendCustID ,
                    #m1.VendCustCode ,
                    #m1.ShortName ,
                    a.ExpressBillNo ,
                    a.OutBillNo ,
                    a.WMS_OrderID ,
                    a.ConsignmentDate ,
                    a.PickStatus ,
                    a.SourceType ,
                    a.SourceRemark ,
                    a.OrderType ,
                    a.MergeSplitType ,
                    a.MergeSourceBillNo ,
                    ISNULL(a.IsPrintExpressBill,0) IsPrintExpressBill ,
                    ISNULL(a.IsPrintDistBill,0) IsPrintDistBill ,
                    a.BuyerCode ,
                    a.BuyerMobileTel ,
                    a.BuyerTel ,
                    a.BuyerRemark ,
                    a.ConsigneeName ,
                    a.Province ,
                    a.City ,
                    a.Area ,
                    a.ZipCode ,
                    a.Address ,
                    a.SellRemark ,
                    a.SellCode ,
                    a.ExceptionNode ,
                    a.PersonnelID ,
                    #m1.PersonnelCode ,
                    #m1.PersonnelName ,
                    a.Operator ,
                    #m1.OperatorName ,
                    a.Checker ,
                    #m1.CheckerName ,
                    a.ModifyDTM ,
                    a.Paymenttype ,
                    a.CodCharges ,
                    a.Qty ,
                    a.PayAmount ,
                    a.ExpressAmount ,
                    a.ExpressCost ,
                    a.TotalBarginPrice ,
                    a.ZRAmount ,
                    a.IsInvoice ,
                    a.invoice_name ,
                    a.PreRemark ,
                    a.Weight ,
                    a.ParcelWeight ,
                    a.PackageCost ,
                    a.BuyerGetBonus ,
                    a.BuyerUseBonus ,
                    a.DischargeIntegral ,
                    a.DischargeIntegralAmount ,
                    a.ExchangeIntegral ,
                    a.BuyerRealUseBonus ,
                    a.CancelContact_ID ,
                    a.SendContact_ID ,
                    #m1.CancelContact_Name ,
                    #m1.Contact_Name ,
                    #m1.CancelShopAddress ,
                    #m1.ShopAddress ,
                    a.BuyerID ,
                    a.CardCode ,
                    a.Remark ,
                    #m1.WorkPropertyName ,
                    a.Signature ,
                    a.IsHide ,
                    a.RecStatus ,
                    ISNULL(a.IsLock,0) IsLock ,
                    a.OldOperator ,
                    #m1.ProjectNo ,
                    #m1.IsPrintExpress ,
                    #m1.IsPrintSendBill ,
                    a.ManualBillNo ,
                    a.PromZRAmount ,
                    a.PayAmountBakUp ,
                    a.OrderCustomerID ,
                    #m1.ColorValue ,
                    #m1.OrderCustomerName ,
                    a.IsAutoMerge ,
                    a.IsReturnOrder ,
                    ISNULL(a.IsConsultingOrder,0) IsConsultingOrder ,
                    a.RefundType ,
                    #m1.ReturnsFreBillNo ,
                    a.O2OShopID ,
                    #m1.O2OShopCode ,
                    #m1.O2OShopName ,
                    a.O2OCompanyID ,
                    #m1.OpResultStatusName ,
                    #m1.WorkPropertyID ,
                    a.RefundChangeType ,
                    a.CardAmount ,
                    a.CardsNo ,
                    a.RptAmount ,
                    ISNULL(a.IsBCVirOrder,0)IsBCVirOrder ,
                    ISNULL(a.PdAmount,0)PdAmount ,
                    a.ReturnItemStatus ,
                    ISNULL(a.IsSendToEDI,0)IsSendToEDI ,
                    a.ReturnStockID ,
                    #m1.ReturnStockCode ,
                    #m1.ReturnStockName,
					a.IsSetStocked,
					a.NotAuditReason,
					a.InvoiceHeader,
					a.InvoiceType,
					a.TaxNO,
					a.Bank,
					a.BankAccount,
					a.InvoiceContent,
					a.InvoiceMedium,
					a.PersonnelShopID,
					#m1.PersonnelShopCode,
					#m1.PersonnelShopName,
					#m1.RecReturnDate,
					#m1.LabelName,
					#m1.IsPresentGood,
					#m1.CompanyBalanceAmount,
					#m1.CompanyMemberCode,
ROW_NUMBER() over (order by a.BillNo asc) as RID from BC_Sal_OrderMaster a INNER JOIN   #m1   ON a.CompanyID= #m1.companyid AND a.billno = #m1.billno
OUTER APPLY ( SELECT TOP 1 
                                    g.OpResultStatus , 
                                    g.OpResultStatusName 
                          FROM      ( SELECT TOP 1 
                                                t.OpResultStatus , 
                                                c.StateName AS OpResultStatusName 
                                      FROM      HK_EDI_JobOrderTrace t 
                                                JOIN dbo.SD_EDI_Stock b ON b.OSStockID = t.OSStockID 
                                                JOIN dbo.HK_EDI_OrderState c ON c.CooperationSys = b.CooperationSys 
                                                              AND t.OpResultStatus = c.StateType 
                                      WHERE     t.BillTypeID = ''BC_NetSalOrder''
                                                AND t.CompanyID = #m1.CompanyID 
                                                AND t.NoticeBillNo = #m1.BillNo 
												and t.ordertype=#m1.EdiOrderType
												ORDER BY t.CreateDate desc 
                                    ) g 
                        ) edi 
 ) as a1 --and a.ordertype=#m1.EdiOrderType
where RID>'+str(@PageIndex*@pageSize)+' and RID<='+str(@pageSize*(@pageIndex+1))+' 

EXECUTE spBC_TotalOrderInfo  
DROP TABLE #m1'

	 set @sql=@sql+@sqlList+@end;
	 
	--select @sql
	execute (@sql)
END


GO
