-- =============================================
-- Author:		������
-- Create date: 2017-11-6
-- Description:	�������
-- =============================================
CREATE PROCEDURE [dbo].[spBC_ImportGoodsNumber]
@companyid VARCHAR(10),
	 @Lan VARCHAR(10)
AS
BEGIN
	select t.*, m.MaterialID,m.MaterialShortName,md.CardName,kd.KindName,m.YearNo,se.SeasonName,rp.RetailPrice 
	from SD_Mat_Material m
	INNER JOIN #mat t ON m.MaterialCode = t.MaterialCode
	left join sd_mat_card md on md.cardid=m.cardid 
	left join SD_Mat_Kind kd on kd.kindid=m.kindid
	left join SD_Mat_Season se on se.seasonid=m.seasonid
	left join SD_Mat_MaterialCurRetailPrice rp on rp.materialid=m.materialid
	INNER JOIN dbo.Bas_Shop sp ON sp.CompanyID=@companyid 
	  --AND sp.ShopCode= t.ShopCode
END