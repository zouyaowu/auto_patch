IF  EXISTS (SELECT 1 FROM sys.objects 
			WHERE object_id = OBJECT_ID(N'[dbo].[fnSys_WebSaleQty_CNoCheck]') 
			AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[fnSys_WebSaleQty_CNoCheck]
Go
 

/*
����˵����������������(�������۶���δ����POS��),����һ��Table
�� �� ��: Thaichee.Su  
*/
CREATE FUNCTION [dbo].[fnSys_WebSaleQty_CNoCheck]
(
	@CompanyID VARCHAR(20),   --��˾ID
	@StockID VARCHAR(20),     --�ֿ�ID
	@IDTable  IDTable READONLY, --��ƷID���б�(�ֶ�ֵ����','��ʾ���б�����Ҫ�ָ�)
	@OpType       INT = 0,    --�������� 0 ��ѯ 1-���� 
	@BillNo       VARCHAR(40) = '',     --����
	@SourceGUID   VARCHAR(50) = ''
)
RETURNS @temp TABLE(CompanyID VARCHAR(20), MaterialID VARCHAR(20), SizeID VARCHAR(20), Qty FLOAT) --����һ��Table
AS 
BEGIN
DECLARE @beginTime DATETIME
DECLARE @SysParaValue T_FullCode_L
--��ѯ�������ã��Ƿ����ð���ǰ��������ʱ��Ϊ�����ѯռ�ÿ�档
SELECT  @SysParaValue = p.SysParaValue
FROM    dbo.Sys_ParameterDetail p
WHERE   p.CompanyID = @CompanyID
        AND p.SysParaCode = 'BC040'
IF ( @SysParaValue IS NULL )
    BEGIN
        SET @SysParaValue = '0'
    END
IF ( @SysParaValue = '1' )
    BEGIN
        SELECT  @beginTime = m.PaymentDate
        FROM    dbo.BC_Sal_OrderMaster m
        WHERE   m.CompanyID = @CompanyID
                AND m.BillNo = @BillNo
    END
	IF @OpType = 0
	BEGIN
		INSERT INTO @temp(CompanyID, MaterialID, SizeID, Qty)
		SELECT b.CompanyID, b.MaterialID, b.SizeID, SUM(ISNULL(b.Qty,0)) AS Qty
		FROM BC_Sal_OrderMaster AS A 
		INNER JOIN BC_Sal_OrderDetail AS C ON A.CompanyID = C.CompanyID AND A.BillNo = C.BillNo
		INNER JOIN BC_Sal_OrderSize b ON C.CompanyID = b.CompanyID AND C.BillNo = b.BillNo AND C.Sequence = B.Sequence
		INNER JOIN @IDTable AS D ON  b.MaterialID = D.KeyValue 
		WHERE a.CompanyID = @CompanyID AND a.StockID = @StockID 
		            AND A.IsHide = 0 --AND C.RefundStatus IN ('','NO_REFUND','CLOSED') 
					AND ISNULL(c.OutBillNo, '') = '' --�첽����pos���ܻ�д0
					--c.outbillno IS null
					--AND ISNULL(C.TranState,'') IN ('','WAIT_BUYER_PAY','WAIT_SELLER_SEND_GOODS')
					AND b.Qty>0 
					AND  ISNULL(c.TranState,'') NOT IN ('TRADE_CLOSED','TRADE_CLOSED_BY_TAOBAO')
					AND A.BillNo <> @BillNo

		    AND 			
			(

				(
					a.BillStatus < 4 --AND OperStatus IN (0,2,3) 		
					--AND (@SysParaValue='0' OR (@beginTime IS NULL) OR a.PaymentDate IS NULL OR ( @SysParaValue='1' AND a.PaymentDate<=@beginTime))
					AND (  @beginTime IS NULL OR a.PaymentDate IS NULL OR (a.PaymentDate<=@beginTime))
				)

			OR 
			    (BillStatus = 4)
			
			)
		GROUP BY b.CompanyID, b.MaterialID, b.SizeID	
    END
    ELSE
    BEGIN
		;WITH BillMat(MaterialID, SizeID)
		AS (
			SELECT MaterialID, SizeID 
			FROM Sys_CalcProjectData
			WHERE CompanyID = @CompanyID AND CurGUID = @SourceGUID AND BillNo = @BillNo
			GROUP BY MaterialID, SizeID )
		INSERT INTO @temp(CompanyID, MaterialID, SizeID, Qty)
		SELECT @CompanyID, B.MaterialID, B.SizeID, SUM(ISNULL(B.Qty,0)) AS Qty
		FROM BC_Sal_OrderMaster a 
		INNER JOIN BC_Sal_OrderDetail AS C ON A.CompanyID = C.CompanyID AND A.BillNo = C.BillNo
		INNER JOIN BC_Sal_OrderSize b ON C.CompanyID = b.CompanyID AND C.BillNo = b.BillNo AND C.Sequence = B.Sequence
		INNER JOIN BillMat AS s_c ON b.MaterialID = s_c.MaterialID AND b.SizeID = s_c.SizeID
		WHERE a.CompanyID = @CompanyID AND a.StockID = @StockID 
		            AND A.IsHide = 0 --AND C.RefundStatus IN ('','NO_REFUND','CLOSED') 
					AND ISNULL(c.OutBillNo, '') = '' --�첽����pos���ܻ�д0
					--c.outbillno IS null
					--AND ISNULL(C.TranState,'') IN ('','WAIT_BUYER_PAY','WAIT_SELLER_SEND_GOODS')
					AND b.Qty>0 
					AND  ISNULL(c.TranState,'') NOT IN ('TRADE_CLOSED','TRADE_CLOSED_BY_TAOBAO')
					AND A.BillNo <> @BillNo

		    AND 			
			(

				(
					a.BillStatus < 4 --AND OperStatus IN (0,2,3) 		
					--AND (@SysParaValue='0' OR (@beginTime IS NULL) OR a.PaymentDate IS NULL OR ( @SysParaValue='1' AND a.PaymentDate<=@beginTime))
					AND (  @beginTime IS NULL OR a.PaymentDate IS NULL OR (a.PaymentDate<=@beginTime))
				)

			OR 
			    (BillStatus = 4)
			
			)
		GROUP BY B.MaterialID, B.SizeID	
    END
	RETURN 
END
GO


