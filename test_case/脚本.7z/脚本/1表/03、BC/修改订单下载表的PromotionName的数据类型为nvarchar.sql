if COL_LENGTH('BC_Sal_OrderDetail_Downd','PromotionName') is not null
begin
 
 
Alter Table BC_Sal_OrderDetail_Downd Alter column  PromotionName nvarchar(500) NULL
 
end
go